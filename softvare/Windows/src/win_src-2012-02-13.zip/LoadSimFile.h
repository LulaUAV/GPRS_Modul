#ifndef LOADSIM_H
#define LOADSIM_H

#include <vcl.h>


//---------------------------------------------------------------------------
class LoadSIM
{
private:
    void ListClear();
public:
    TList* m_atlist1;
    TList* m_atlist2;
    char m_gprs_data[48];
    int m_gprs_len;
public:
    LoadSIM();
    ~LoadSIM();
    bool Load();
    bool print();
};

#endif