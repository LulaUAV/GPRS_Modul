//---------------------------------------------------------------------------

#ifndef walarmH
#define walarmH
//---------------------------------------------------------------------------
#include <Classes.hpp>
#include <Controls.hpp>
#include <StdCtrls.hpp>
#include <Forms.hpp>
#include "SerialCom.h"
#include <ExtCtrls.hpp>
#include "CSPIN.h"
#include <Buttons.hpp>

//#define DEMO_SIM900     1
//---------------------------------------------------------------------------
class TWalarmForm : public TForm
{
__published:	// IDE-managed Components
    TMemo *Info;
    TButton *ExitBtn;
    TGroupBox *GroupBox3;
    TComboBox *CmdCBox;
    TCSpinEdit *AlarmCmdEdit;
    TLabel *AlarmLabel;
    TBitBtn *SendCmdBtn;
    TGroupBox *CIDGbox;
    TEdit *CIDEdit;
    TGroupBox *INITGbox;
    TEdit *INITEdit1;
    TEdit *INITEdit2;
    TGroupBox *ALARMGbox;
    TEdit *ALARMEdit1;
    TEdit *ALARMEdit2;
    TEdit *ALARMEdit3;
    TEdit *ALARMEdit4;
    TEdit *ALARMEdit5;
    TLabel *Label1;
    TLabel *ALRMChsLabel;
    TButton *GprsGsmBtn;
    TButton *ALsend1Btn;
    TButton *ALsend2Btn;
    TButton *SlisBtn;
    TButton *HandskaeBtn;
    TButton *KisoffBtn;
    TButton *HaltBtn;
    TButton *ResetBtn;
    TCheckBox *DebugCbx;
    TComboBox *ModeCBox;
    void __fastcall FormCreate(TObject *Sender);
    void __fastcall FormClose(TObject *Sender, TCloseAction &Action);
   // void __fastcall LoadBtnClick(TObject *Sender);
    void __fastcall ExitBtnClick(TObject *Sender);
    void __fastcall InfoDblClick(TObject *Sender);
    void __fastcall CmdCBoxChange(TObject *Sender);
    void __fastcall SendCmdBtnClick(TObject *Sender);
    void __fastcall GprsGsmBtnClick(TObject *Sender);
    void __fastcall ALsend1BtnClick(TObject *Sender);
    void __fastcall ALsend2BtnClick(TObject *Sender);
    void __fastcall SlisBtnClick(TObject *Sender);
    void __fastcall HandskaeBtnClick(TObject *Sender);
    void __fastcall KisoffBtnClick(TObject *Sender);
    void __fastcall HaltBtnClick(TObject *Sender);
    void __fastcall ResetBtnClick(TObject *Sender);
    void __fastcall DebugCbxClick(TObject *Sender);
    void __fastcall ModeCBoxChange(TObject *Sender);
private:	// User declarations

private:
    
    void __fastcall sendItem_atlist1();
    void __fastcall sendItem_atlist2();
public:		// User declarations
    __fastcall TWalarmForm(TComponent* Owner);
    void __fastcall Exit();
    void __fastcall SOpen();
};
//---------------------------------------------------------------------------
extern PACKAGE TWalarmForm *WalarmForm;
//---------------------------------------------------------------------------
#endif
