//---------------------------------------------------------------------------

#ifndef WilAlarmMainH
#define WilAlarmMainH
//---------------------------------------------------------------------------
#include <Classes.hpp>
#include <Controls.hpp>
#include <StdCtrls.hpp>
#include <Forms.hpp>
#include <ExtCtrls.hpp>
#include <jpeg.hpp>

typedef struct
{
    bool isSerial;
} INI;

//---------------------------------------------------------------------------
class TWilAlarmM : public TForm
{
__published:	// IDE-managed Components
    TImage *Image1;
    TImage *Image2;
    TPanel *Panel1;
    TButton *ExitBtn;
    TButton *SettingBtn;
    TButton *TestBtn;
    TTimer *Timer1;
    TButton *Button1;
    void __fastcall TestBtnClick(TObject *Sender);
    void __fastcall ExitBtnClick(TObject *Sender);
    void __fastcall SettingBtnClick(TObject *Sender);
    void __fastcall FormCreate(TObject *Sender);
    void __fastcall FormShow(TObject *Sender);
    void __fastcall Timer1Timer(TObject *Sender);
private:	// User declarations

public:		// User declarations
    __fastcall TWilAlarmM(TComponent* Owner);
     void __fastcall rAlive();
     bool m_alive_counter;
     void __fastcall setEnable(bool en);
};
//---------------------------------------------------------------------------
extern PACKAGE TWilAlarmM *WilAlarmM;
//---------------------------------------------------------------------------
#endif
