#include "stdarg.h"
#include "utils.h"


char sdata[64];

void mysprintf(unsigned char* buffer,const rom char  *format, ...)
{
  unsigned char scratch[32];
  unsigned char format_flag;
  unsigned short base;
  unsigned char *ptr;
  unsigned char issigned=0;
  char temp;
  va_list ap;

#ifdef USE_LONG
  unsigned char islong=0;
  unsigned long u_val=0;
  long s_val=0;
#else
  unsigned int u_val=0;
  int s_val=0;
#endif

  unsigned char fill;
  unsigned char width;

  va_start (ap, format);
  for (;;){
    while ((format_flag = *(format++)) != '%'){      // Until '%' or '\0'
      if (!format_flag){va_end (ap);*buffer=0; return;}
      *buffer++=format_flag;
    }

    issigned=0; //default unsigned
    base = 10;

    format_flag = *format++; //get char after '%'

#ifdef PADDING
    width=0; //no formatting
    fill=0;  //no formatting
    if(format_flag=='0' || format_flag==' ') //SPACE or ZERO padding  ?
     {
      fill=format_flag;
      format_flag = *format++; //get char after padding char
      if(format_flag>='0' && format_flag<='9')
       {
        width=format_flag-'0';
        format_flag = *format++; //get char after width char
       }
      if(format_flag>='0' && format_flag<='9')
       {
        width=width*10+format_flag-'0';
        format_flag = *format++; //get char after width char
       }
     }
#endif

#ifdef USE_LONG
    islong=0; //default int value
#ifdef USE_UPPER
    if(format_flag=='l' || format_flag=='L') //Long value 
#else
    if(format_flag=='l') //Long value 
#endif
     {
      islong=1;
      format_flag = *format++; //get char after 'l' or 'L'
     }
#endif

    switch (format_flag)
    {
#ifdef USE_CHAR
    case 'c':
#ifdef USE_UPPER
    case 'C':
#endif
      format_flag = va_arg(ap,int);
      // no break -> run into default
#endif

    default:
      *buffer++=format_flag;
      continue;

#ifdef USE_STRING
#ifdef USE_UPPER
    case 'S':
#endif
    case 's':
      ptr = (unsigned char*)va_arg(ap,char *);
      while(*ptr) { *buffer++=*ptr++; }
      continue;
#endif

#ifdef USE_INTEGER //don't use %i, is same as %d
    case 'i':
#ifdef USE_UPPER
    case 'I':
#endif
#endif
    case 'd':
#ifdef USE_UPPER
    case 'D':
#endif
      issigned=1;
      // no break -> run into next case
    case 'u':
#ifdef USE_UPPER
    case 'U':
#endif

//don't insert some case below this if USE_HEX is undefined !
//or put       goto CONVERSION_LOOP;  before next case.
#ifdef USE_HEX
      goto CONVERSION_LOOP;
    case 'x':
#ifdef USE_UPPER
    case 'X':
#endif
      base = 16;
#endif

    CONVERSION_LOOP:

      if(issigned) //Signed types
       {
#ifdef USE_LONG
        if(islong) { s_val = va_arg(ap,long); }
        else { s_val = va_arg(ap,int); }
#else
        s_val = va_arg(ap,int);
#endif

        if(s_val < 0) //Value negativ ?
         {
          s_val = - s_val; //Make it positiv
          *buffer++='-';    //Output sign
         }

        u_val = (unsigned long)s_val;
       }
      else //Unsigned types
       {
#ifdef USE_LONG
        if(islong) 
		{
			u_val = va_arg(ap,unsigned long); 
		}
        else 
		{ 
			u_val = va_arg(ap,unsigned int); 
		}
#else
        u_val = va_arg(ap,unsigned int);
#endif
       }
/*
		temp = ((char*)&u_val)[1];
	   ((char*)&u_val)[1] = ((char*)&u_val)[0];
	   ((char*)&u_val)[0] = temp;	*/
    
      ptr = scratch + SCRATCH;
      *--ptr = 0;
      do
       {
        char ch = u_val % base + '0';
#ifdef USE_HEX
        if (ch > '9')
         {
          ch += 'a' - '9' - 1;
#ifdef USE_UPPERHEX
          ch-=0x20;
#endif
         }
#endif
        *--ptr = ch;
        u_val /= base;

#ifdef PADDING
        if(width) width--; //calculate number of padding chars
#endif
      } while (u_val);

#ifdef PADDING
     while(width--) *--ptr = fill; //insert padding chars		      
#endif

      while(*ptr) *buffer++=*ptr++;
    }
  }
}


//------------------------------------------------------
/** 1 byte hexadecim�lis form�ban ki�r
 *  res[3] kell legyen! 
 */
void hex1toa(char t, char* res)
{
  char c;
  c=(t>>4) & 0x0F;
  if (c>9) 
	c+=7;
  *res = c+'0';
  c=t & 0x0F;
  if (c>9) 
	c+=7;
  res++;
  *res = c+'0';
  res++;
 *res = 0;
}
//------------------------------------------------------
char *myStrcpy_r ( char *s1, const rom char *s2 ) 
{
    
    while ( ( *s1++ = *s2++ ) != '\0' )
      ;
	return s1;
}
//------------------------------------------------------
char *myStrcpy ( char *s1, const char *s2 ) 
{
    
    while ( ( *s1++ = *s2++ ) != '\0' )
      ;
	return s1;
}
//------------------------------------------------------
void mStrcat(char *s, const char *t, int max_num)
{
	int ii;
    if (s == 0 || t == 0) 
        return;
    while (*s != 0)
       s++;
    
	for (ii=0; ii<max_num && *t; ii++, s++, t++)
	{
		*s = *t;
	}
   return;
} 

//------------------------------------------------------
char *myStrcat_r(char *s, const rom char *t)
{
    char *p = s;
    if (s == 0 || t == 0) 
        return s;
    while (*s != 0)
       s++;
    while (*s++ = *t++);
   return p;
} 

//------------------------------------------------------
int myStrlen_rom(const rom char* msg)
{
	int res = 0;
	while (*msg++)
	{
		res++;
	}
	return res;
}

//------------------------------------------------------
int myStrlen_ram(const char* msg)
{
	int res = 0;
	while (*msg++)
	{
		res++;
	}
	return res;
}

//------------------------------------------------------
int myStrCmp(char* msg, const rom char* cmp)
{
	char in = 0;
	while (*msg)
	{
		if (*cmp == *msg)
		{
			in = 1;
			if (*(cmp+1) == '\0')
				return 0;
			cmp++;
		}
		else
		if (in)
			return 1;
		msg++;	
	}
	return 1;
}