//---------------------------------------------------------------------------

/*
Be�ll�tottam:
1. A szoftver/PC folderben a TeamViewert fel kell telep�teni. Partner ID: 638621840 pass: hazmester  (user:Administrator)
2. Etherealt feltelepitettem.
- Capture/interfaces/Intel->Prepare
- Update list of packets in real time, Automatic scrolling bekapcsolni
- Capture filter: udp port 53500
- Start
A k�ld�skor megj�n a csomag, k�vetkez� sor a visszav�lasz lesz, pl.84

Ezzel gyorsan kider�l a turpiss�g. 

IP c�m egy�bk�nt 81.182.171.152, de naponta v�ltozik  �s nem kell a TeamViewerhez.

Figyelj az IMEI sz�mra, ha a MasterClientben n�zed, a n�lad l�v� modul sz�ma nincs felv�ve, viszont van egy m�sik a
3. sz. �gyf�lsz�mon. xxxx101 a v�ge a sz�m�nak.

ATE0
at+ifc=2,2
at+ceng=1,0
at+cpin?
at+cgsn
at+cgmi
at+moring=1
at+cgmr
at+csmins?
at+cgatt=0
at+creg=2
at+cgdcont=1,"IP","internet"
at+ciphead=0
at+clport="UDP","1998"
at+creg?
at+creg?
at+creg?
at+creg?
at+creg?
at+creg?
at+csclk=1
at+clip=1
at+cmgf=0
at+csca?
at+cgatt=1
at+cipudpmode=1
at+cstt="internet"
at+ciicr
at+cipstatus
at+cifsr
at+cipstatus
at+cipstart="UDP","canbus.myftp.org","1998"
at+cpms?
at+cpms?
at+cipsend=30
*/
#include <vcl.h>
#include <stdio.h>
#include <io.h>
#include <fcntl.h>
#pragma hdrstop

//#include "LoadSimFile.h"
#include "walarm.h"
#include "WilGsmGprsTeszt.h"
#include "WilSLICTeszt.h"
#include "WilAlarmMain.h"
#include "SerialCom.h"

//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma link "CSPIN"
#pragma resource "*.dfm"
TWalarmForm *WalarmForm;

bool bDeve;
CSerialPort* serial_st;
extern INI ini_st;

//---------------------------------------------------------------------------
void initConsole()
{
    if (AllocConsole()) 
    {
        HANDLE hin = GetStdHandle(STD_INPUT_HANDLE);
        stdin->fd = _open_osfhandle((INT_PTR)hin, _O_RDONLY|_O_TEXT);
        HANDLE hout = GetStdHandle(STD_OUTPUT_HANDLE);
        stdout->fd = _open_osfhandle((INT_PTR)hout, _O_APPEND|_O_TEXT);
        HANDLE herr = GetStdHandle(STD_ERROR_HANDLE);
        stderr->fd = _open_osfhandle((INT_PTR)herr, _O_APPEND|_O_TEXT);
     //   GlobalAlloc( GMEM_FIXED,10000000);
    }
};

//---------------------------------------------------------------------------
DWORD Send(char* msg, int len, VIEW callback)
{
   // dump("send",(void*)msg,len,NULL);
   serial_st->m_callback = callback;
    return serial_st->WriteCom(msg,len);
}//Send(..)

//---------------------------------------------------------------------------
void clear_callback()
{
   // dump("send",(void*)msg,len,NULL);
   serial_st->m_callback = NULL;

}//Send(..)

/**********************************************************************
 * Error Message:
 **********************************************************************/
 void Error_Message(char* msg)
 {
    Application->MessageBox(msg , "Error",0);
 }// void Error_Message(const char* msg)

/**********************************************************************
 * Warning Message:
 **********************************************************************/
 void Warning_Message(char* msg)
 {
    Application->MessageBox(msg , "Warning",0);
 }// void Warning_Message(const char* msg)

//<------------------------------
void uint4CopyTouchar(unsigned int* source, unsigned char* dest)
{
	dest[3] = (unsigned char)(*source);
	dest[2] = (unsigned char)(*source >> 8);
	dest[1] = (unsigned char)(*source >> 16);
	dest[0] = (unsigned char)(*source >> 24);
}

//<------------------------------
void uint3CopyTouchar(unsigned int* source, unsigned char* dest)
{
	dest[2] = (unsigned char)(*source);
	dest[1] = (unsigned char)(*source >> 8);
	dest[0] = (unsigned char)(*source >> 16);
}

//<------------------------------
void uint2CopyTouchar(unsigned int* source, unsigned char* dest)
{
	dest[1] = (unsigned char)(*source);
	dest[0] = (unsigned char)(*source >> 8);
}


//---------------------------------------------------------------------------
__fastcall TWalarmForm::TWalarmForm(TComponent* Owner)
    : TForm(Owner)
{
}
//---------------------------------------------------------------------------
void __fastcall TWalarmForm::FormCreate(TObject *Sender)
{
    bDeve=false;
    for (int i=1;i<=ParamCount();i++)
    {
        if (LowerCase(ParamStr(i)) == "-deve")
        {
            bDeve=true;
        }
    }
    initConsole();

    serial_st = new CSerialPort();
#ifdef DEMO_SIM900
    if (serial_st->Open(1, 9600/*57600*/) == FALSE)
#else
    if (serial_st->Open(1, 9600/*57600*/) == FALSE)
#endif
    {
        printf("Serial Open error\n");
    }
    else
        ini_st.isSerial = true;

   
    if (bDeve)
    {
        GprsGsmBtn->Visible    = true;
    }
}


//---------------------------------------------------------------------------
void __fastcall TWalarmForm::SOpen()
{
     if (!ini_st.isSerial)
     {
         if (serial_st->Open(1, 9600/*57600*/) == FALSE)
        {
            printf("Serial Open error\n");
        }
        else
            ini_st.isSerial = true;
     }
}


//---------------------------------------------------------------------------
void __fastcall TWalarmForm::Exit()
{
    delete serial_st;
}

//---------------------------------------------------------------------------
void __fastcall TWalarmForm::FormClose(TObject *Sender,
      TCloseAction &Action)
{
   
   // delete serial_st;
}

//---------------------------------------------------------------------------
void __fastcall TWalarmForm::ExitBtnClick(TObject *Sender)
{
    Close();
}

//---------------------------------------------------------------------------
void __fastcall TWalarmForm::InfoDblClick(TObject *Sender)
{
    Info->Clear();    
}

//---------------------------------------------------------------------------
void __fastcall TWalarmForm::CmdCBoxChange(TObject *Sender)
{
//
    switch (CmdCBox->ItemIndex)
    {
        case 0:  //NONE
            CIDGbox->Visible = false;
            INITGbox->Visible = false;
            ALARMGbox->Visible = false;
            AlarmCmdEdit->Visible = false;
            AlarmLabel->Visible = false;
            SendCmdBtn->Enabled = false;
            break;
        case 1: //ALARM
            CIDGbox->Visible = false;
            INITGbox->Visible = false;
            ALARMGbox->Visible = true;
            AlarmCmdEdit->Visible = true;
            AlarmLabel->Visible = true;
            SendCmdBtn->Enabled = true;
            break;
        case 2: //CID
            CIDGbox->Visible = true;
            INITGbox->Visible = false;
            ALARMGbox->Visible = false;
            AlarmCmdEdit->Visible = false;
            AlarmLabel->Visible = false;
            SendCmdBtn->Enabled = true;
            break;
        case 3:  //INIT
            CIDGbox->Visible = false;
            INITGbox->Visible = true;
            ALARMGbox->Visible = false;
            AlarmCmdEdit->Visible = false;
            AlarmLabel->Visible = false;
            SendCmdBtn->Enabled = true;
            break;
        case 4: //ALIVE
            CIDGbox->Visible = false;
            INITGbox->Visible = false;
            ALARMGbox->Visible = false;
            AlarmCmdEdit->Visible = false;
            AlarmLabel->Visible = false;
            SendCmdBtn->Enabled = true;
            break;
    }
}
//---------------------------------------------------------------------------

void __fastcall TWalarmForm::SendCmdBtnClick(TObject *Sender)
{
    char msg[64];
    int len = 0;
    int ii;
    msg[0] = 'M';

    if (ModeCBox->ItemIndex == 2)
    {  //SMS
        int  cidkod;
        unsigned int temp;
       msg[1] = ('S');
       if ((CIDEdit->Text.Length() > 4)  ||  (CIDEdit->Text.Length() == 0))
       {
            Warning_Message("CID hi�nyos!");
            return;
       }
       try
       {
            cidkod = CIDEdit->Text.ToInt();
       }
       catch(...)
       {
            Error_Message("CID k�d nem sz�m");
            return;
       }

       temp = cidkod / 1000;
       if (temp == 0)
            temp += 10;
       msg[2] = (char)(temp + 0x30);

       temp = (cidkod % 1000) /100;
       if (temp == 0)
            temp += 10;
       msg[3] = (char)(temp + 0x30);

       temp = (cidkod % 100) /10;
       if (temp == 0)
            temp += 10;
       msg[4] = (char)(temp + 0x30);

        temp = (cidkod % 10);
       if (temp == 0)
            temp += 10;
       msg[5] = (char)(temp + 0x30);
       len = 6;

    }
    else
    if (ModeCBox->ItemIndex == 1)
    { //GPRS

    msg[1] = (char)CmdCBox->ItemIndex;
    switch (CmdCBox->ItemIndex)
    {
        case 0://NONE
            return;
        case 1: //ALARM

            if ((ALARMEdit1->Text.Length() > 4)  ||  (ALARMEdit1->Text.Length() == 0) ||
                (ALARMEdit2->Text.Length() > 2)  ||  (ALARMEdit2->Text.Length() == 0) ||
                (ALARMEdit3->Text.Length() > 4)  ||  (ALARMEdit3->Text.Length() == 0) ||
                (ALARMEdit4->Text.Length() > 2)  ||  (ALARMEdit4->Text.Length() == 0) ||
                (ALARMEdit5->Text.Length() > 3)  ||  (ALARMEdit5->Text.Length() == 0))

            {
               Warning_Message("ALARM hi�nyos!");
               return;
            }
            unsigned int ukod,utip,event,group,zone,chs,chs1,chs2,chs3,chs4,chs5,ii, temp, temp1;
             chs  = 0;
             chs1 = 0;
             chs2 = 0;
             chs3 = 0;
             chs4 = 0;
             chs5 = 0;
             try
             {
                 ukod = ALARMEdit1->Text.ToInt();
             }
             catch(...)
             {
                 Error_Message("�gyf�l k�d nem sz�m");
                 return;
             }

             temp = ukod / 1000;
             temp1 =  ukod;
             if (temp)
             {
                chs1 += temp;
             }
             else
                chs1 += 10;
             msg[4] = (char)(temp + 0x30);
             temp1 = ukod - temp*1000;


             temp = temp1/100;
             if (temp)
             {
                chs1 += temp;
             }
             else
                chs1 += 10;
             msg[5] = (char)(temp + 0x30);
             temp1 -= temp*100;


             temp = temp1 / 10;
             if (temp)
             {
                chs1 += temp;

             }
             else
                chs1 += 10;
             msg[6] = (char)(temp + 0x30);
             temp1 -= temp*10;

             temp = temp1 % 10;
             if (temp)
             {
                chs1 += temp;
             }
             else
                chs1 += 10;
             msg[7] = (char)(temp + 0x30);
             printf("chs1:%d\n",chs1);

             try
             {
                 utip = ALARMEdit2->Text.ToInt();
             }
             catch(...)
             {
                 Error_Message("�zenet tipus nem sz�m");
                 return;
             }

             temp = utip / 10;
             temp1 = utip;
             if (temp)
             {
                chs2 += temp;
             }
             else
                chs2 += 10;
             msg[8] = (char)(temp + 0x30);
             temp1 -= temp*10;

             temp = temp1 % 10;
             if (temp)
             {
                chs2 += temp;
             }
             else
                chs2 += 10;
             msg[9] = (char)(temp + 0x30);
             printf("chs2:%d\n",chs2);

             try
             {
                 event = ALARMEdit3->Text.ToInt();
             }
             catch(...)
             {
                 Error_Message("Esem�ny nem sz�m");
                 return;
             }

             temp = event / 1000;
             temp1 =  event;
             if (temp)
             {
                chs3 += temp;
             }
             else
                chs3 += 10;
             msg[10] = (char)(temp + 0x30);
             temp1 -= temp*1000;


             temp = temp1/100;
             if (temp)
             {
                chs3 += temp;
             }
             else
                chs3 += 10;
             msg[11] = (char)(temp + 0x30);
             temp1 -= temp*100;

             temp = temp1 / 10;
             if (temp)
             {
                chs3 += temp;

             }
             else
                chs3 += 10;
             msg[12] = (char)(temp + 0x30);
             temp1 -= temp*10;

             temp = temp1 % 10;
             if (temp)
             {
                chs3 += temp;
             }
             else
                chs3 += 10;
             msg[13] = (char)(temp + 0x30);
             printf("chs3:%d\n",chs3);

             try
             {
                 group = ALARMEdit4->Text.ToInt();
             }
             catch(...)
             {
                 Error_Message("Csoport nem sz�m");
                 return;
             }

             temp = group / 10;
             temp1 = group;
             if (temp)
             {
                chs4 += temp;
             }
             else
                chs4 += 10;
             msg[14] = (char)(temp + 0x30);
             temp1 -= temp*10;

             temp = temp1 % 10;
             if (temp)
             {
                chs4 += temp;
             }
             else
                chs4 += 10;
             msg[15] = (char)(temp + 0x30);
             printf("chs4:%d\n",chs4);

             try
             {
                 zone = ALARMEdit5->Text.ToInt();
             }
             catch(...)
             {
                 Error_Message("Z�na nem sz�m");
                 return;
             }
             temp = zone/100;
             temp1 = zone;
             if (temp)
             {
                chs5 += temp;
             }
             else
                chs5 += 10;
             msg[16] = (char)(temp + 0x30);
             temp1 -= temp*100;

             temp = temp1 / 10;
             if (temp)
             {
                chs5 += temp;

             }
             else
                chs5 += 10;
             msg[17] = (char)(temp + 0x30);
             temp1 -= temp*10;

             temp = temp1 % 10;
             if (temp)
             {
                chs5 += temp;
             }
             else
                chs5 += 10;
             msg[18] = (char)(temp + 0x30);
             printf("chs5:%d\n",chs5);

             chs = chs1 + chs2 + chs3 + chs4 + chs5;
             printf("chs:%d\n",chs);

             chs = 15 - (chs % 15 );
             ALRMChsLabel->Caption = chs;
             
             msg[2] = (char)AlarmCmdEdit->Value;
             msg[3] = 16;

             /*uint4CopyTouchar(&ukod, &msg[4]);
             uint2CopyTouchar(&utip, &msg[8]);
             uint4CopyTouchar(&event, &msg[10]);
             uint2CopyTouchar(&group, &msg[14]);
             uint3CopyTouchar(&zone, &msg[16]); */
             msg[19] = (char)(chs + 0x30);
             len = 20;
            break;
        case 2: //CID

            if  (CIDEdit->Text.Length() != 4)
            {
               Warning_Message("CID hossza 4 karakter!");
               return;
            }
             try
             {
                 int cid = CIDEdit->Text.ToInt();
             }
             catch(...)
             {
                 Error_Message("CID nem sz�m");
                 return;
             }
            for (ii=0;ii<4; ii++)
                msg[ii+2]  = CIDEdit->Text.c_str()[ii];
            
            len = 6;            
            break;
        case 3: //INIT
             unsigned int sver,hver;
             if  ((INITEdit1->Text.Length() == 0) || (INITEdit2->Text.Length() == 0))
             {
                Warning_Message("INIT softver, hardver verzi�b�l az egyik �res!");
                return;
             }
             try
             {
                 sver = INITEdit1->Text.ToInt();
             }
             catch(...)
             {
                 Error_Message("Szofver verzi� nem sz�m");
                 return;
             }
             try
             {
                 hver = INITEdit2->Text.ToInt();
             }
             catch(...)
             {
                 Error_Message("Hardver verzi� nem sz�m");
                 return;
             }
             uint4CopyTouchar(&sver, &msg[ii+2]);
             uint4CopyTouchar(&hver, &msg[ii+6]);
            /* for (ii=0;ii<8; ii++)
                msg[ii+2]  = DataEdit1->Text.c_str()[ii];*/
             len = 10;
            break;
        case 4: //ALIVE
            len = 2;
            break;
    }
    }
     if (Send(msg, len, NULL) == 0) 
        printf("serial sending error\n");
}


//---------------------------------------------------------------------------

void __fastcall TWalarmForm::GprsGsmBtnClick(TObject *Sender)
{
    FormSIM300->Show();
}
//---------------------------------------------------------------------------


void __fastcall TWalarmForm::ALsend1BtnClick(TObject *Sender)
{
// 0555 18 16A2 A1 AAA+Chk    (szumma:  94) chs = 15 - (94%15) = 11
 char msg[64];
    int len = 20;
    int ii;
    msg[0] = 'M';
    msg[1] = (char)CmdCBox->ItemIndex;
    msg[2] = (char)AlarmCmdEdit->Value;
    msg[3] = 16;

    msg[4] = ':';
    msg[5] = '5';
    msg[6] = '5';
    msg[7] = '5';

    msg[8] = '1';
    msg[9] = '8';

    msg[10] = '1';
    msg[11] = '6';
    msg[12] = '?';
    msg[13] = '2';

    msg[14] = '?';
    msg[15] = '1';

    msg[16] = '?';
    msg[17] = '?';
    msg[18] = '?';

    msg[19] = '>';

    if (Send(msg, len, NULL) == 0)
        printf("serial sending error\n");
}
//---------------------------------------------------------------------------

void __fastcall TWalarmForm::ALsend2BtnClick(TObject *Sender)
{
   // 0555 18 1131 01 015+Chk  chs = 8  
    char msg[64];
    int len = 20;
    int ii;
    msg[0] = 'M';
    msg[1] = (char)CmdCBox->ItemIndex;
    msg[2] = (char)AlarmCmdEdit->Value;
    msg[3] = 16;

    msg[4] = ':';
    msg[5] = '5';
    msg[6] = '5';
    msg[7] = '5';

    msg[8] = '1';
    msg[9] = '8';

    msg[10] = '1';
    msg[11] = '1';
    msg[12] = '3';
    msg[13] = '1';

    msg[14] = ':';
    msg[15] = '1';

    msg[16] = ':';
    msg[17] = '1';
    msg[18] = '5';

    msg[19] = '8';

    if (Send(msg, len, NULL) == 0)
        printf("serial sending error\n");
}
//---------------------------------------------------------------------------

void __fastcall TWalarmForm::SlisBtnClick(TObject *Sender)
{
    FormSLIC->Show();
}

void __fastcall TWalarmForm::HandskaeBtnClick(TObject *Sender)
{
    char msg[5];
    msg[0] = 'S';
    msg[1] = 'H';
    Send(msg, 2, NULL);
}

//---------------------------------------------------------------------------
void __fastcall TWalarmForm::KisoffBtnClick(TObject *Sender)
{   //kisoff
    char msg[5];
    msg[0] = 'S';
    msg[1] = 'K';
    Send(msg, 2, NULL);
}

//---------------------------------------------------------------------------
void __fastcall TWalarmForm::HaltBtnClick(TObject *Sender)
{ //halt
    char msg[5];
    msg[0] = 'T';
    msg[1] = 'H';
    Send(msg, 2, NULL);
}


//---------------------------------------------------------------------------
void __fastcall TWalarmForm::ResetBtnClick(TObject *Sender)
{   //reset
    char msg[5];
    msg[0] = 'T';
    msg[1] = 'R';
    Send(msg, 2, NULL);
}


//---------------------------------------------------------------------------
void __fastcall TWalarmForm::DebugCbxClick(TObject *Sender)
{
    char msg[5];
    msg[0] = 'T';
    msg[1] = 'D';
    if (DebugCbx->State == cbUnchecked)
    {
        msg[2] = 0;
    }
    else
    {
        msg[2] = 1;
    }

    Send(msg, 3, NULL);
}

//---------------------------------------------------------------------------
void __fastcall TWalarmForm::ModeCBoxChange(TObject *Sender)
{
    switch (ModeCBox->ItemIndex)
    {
        case 0:  //NONE
            CIDGbox->Visible = false;
            INITGbox->Visible = false;
            ALARMGbox->Visible = false;
            AlarmCmdEdit->Visible = false;
            AlarmLabel->Visible = false;
            SendCmdBtn->Enabled = false;
            CmdCBox->Enabled = false;
            break;
        case 1: //GPRS
            CIDGbox->Visible = false;
            INITGbox->Visible = false;
            ALARMGbox->Visible = false;
            AlarmCmdEdit->Visible = false;
            AlarmLabel->Visible = false;
            SendCmdBtn->Enabled = false;
            CmdCBox->Enabled = true;
            CmdCBox->ItemIndex = 0;
            break;
        case 2: //SMS
            CIDGbox->Visible = true;
            INITGbox->Visible = false;
            ALARMGbox->Visible = false;
            AlarmCmdEdit->Visible = false;
            AlarmLabel->Visible = false;
            SendCmdBtn->Enabled = true;
            CmdCBox->Enabled = false;
            SendCmdBtn->Enabled = true;
            CmdCBox->Enabled = false;
            break;
        }
 
}
//---------------------------------------------------------------------------

