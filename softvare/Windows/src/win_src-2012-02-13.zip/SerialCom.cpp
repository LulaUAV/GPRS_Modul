#include <windows.h>
#include <stdio.h>
#include <conio.h>
#include "SerialCom.h"

/**************************************************************************
 *		Com class part start
 Bom �cian     (Bombolya L�szl� "Bombi")
Tiborc utca 3.
 *************************************************************************/
HANDLE		CSerialPort::m_hPort_s = NULL;
char        CSerialPort::m_error[100];
char        CSerialPort::m_port_name[20];
COM_SET     CSerialPort::m_com;
DCB			CSerialPort::m_dDCB;
OVERLAPPED  CSerialPort::m_osRead;
OVERLAPPED  CSerialPort::m_osWrite;
VIEW*        CSerialPort::m_callback = NULL;


 /**********************************************************************
 * Debug Message:
 **********************************************************************/
 void Printf(const char* sText)
 {

    printf("SOROS: %s\n", sText);
   /* if (!DkLcdForm->View->Tag)
    {
        if ( 100 < DkLcdForm->View->Lines->Count)
            DkLcdForm->View->Clear();
        DkLcdForm->View->Lines->Add(sText);
        DkLcdForm->View->Refresh();
        Application->ProcessMessages();
    }  */
 }//XTPrintf(..)

 //-------------------------------------------------------------------------
 HINSTANCE hioLib; //Inst�ncia para a DLL inpout32.dll.
 PtrInp inportb;     //Inst�ncia para a fun�a~o Imp32().
 PtrOut outportb;  //Inst�ncia para a fun�a~o Out32().

 void in_out_port_init()
 {
    hioLib = LoadLibrary("inpout32.dll");

   if(hioLib == NULL) //Verifica se houve erro.
   {
      printf("Erro. O arquivo inpout32.dll na~o foi encontrado.\n");

      return;
   }

   //Obt�m o endere�o da fun�a~o Inp32 contida na DLL.
   inportb = (PtrInp) GetProcAddress(hioLib, "Inp32");

   if(inportb == NULL) //Verifica se houve erro.
   {
      printf("Erro. A fun�a~o Inp32 na~o foi encontrada.\n");
      return;
   }

   //Obt�m o endere�o da fun�a~o Out32 contida na DLL.
   outportb = (PtrOut) GetProcAddress(hioLib, "Out32");

   if(outportb == NULL) //Verifica se houve erro.
   {
       printf("Erro. A fun�a~o Out32 na~o foi encontrada.\n");
       return;
   }
 }

  void in_out_port_end()
 {
    FreeLibrary(hioLib);
 }



 //-------------------------------------------------------------------------
CSerialPort::CSerialPort() :
m_st_num(0)
{


    return;
}


//-------------------------------------------------------------------------
void CSerialPort::UsDelay(unsigned long ulTimeInUs)
{

    if (ulTimeInUs >= 1000)
        ::Sleep(ulTimeInUs/1000);
    return;

	LARGE_INTEGER liStartCount;
	LARGE_INTEGER liCount;

	QueryPerformanceCounter(&liStartCount);
	double dTime = (double)liStartCount.QuadPart/m_dTakteProUS;
	double dEndTime = dTime + ulTimeInUs;

	for(;dTime < dEndTime;)
	{
		QueryPerformanceCounter(&liCount);
		dTime = (double)liCount.QuadPart/m_dTakteProUS;
	}
}


//-------------------------------------------------------------------------
bool CSerialPort::Init(COM_SET com, int& error )
{
    COMMTIMEOUTS  CommTimeOuts ;
 //   char m_error[100];

    if (!com.Enable)
    {
        error = 1;
        return false;
    }

    memcpy(&m_com, &com, sizeof(COM_SET));
    sprintf(m_port_name,"COM%d:",com.Port);

    m_hPort_s = CreateFile (TEXT(m_port_name), // Port Name (Unicode compatible)
                    GENERIC_READ|GENERIC_WRITE,  // Open for Read-Write
                    0,             // COM port cannot be shared
                    NULL,          // Always NULL for Windows CE
                    OPEN_EXISTING, // For communication resource
                    FILE_FLAG_OVERLAPPED,// Non-overlapped operation only
                    NULL);         // Always NULL for Windows CE
  	if (m_hPort_s == INVALID_HANDLE_VALUE)
    {
        error = 2;
        sprintf(m_error, "%s not open !", m_port_name);
        //XTPrintf(buff);
        printf(m_error);
        return false;
	}
    else
    {
        sprintf(m_error, "%s open !!", m_port_name);
        printf(m_error);
         //   XTPrintf(buff);
    }

    if (!GetCommState(m_hPort_s,&m_dDCB))
    {
        CloseHandle(m_hPort_s);
        error = 3;
        sprintf(m_error, "%s open,but GetCommState() error was !", m_port_name);
        printf(m_error);
        //XTPrintf(buff);
        return false;
    }

    m_dDCB.BaudRate = com.Baudrate;
    m_dDCB.ByteSize = com.ByteSize;
    m_dDCB.Parity   = com.Parity;
    m_dDCB.StopBits = com.StopBits;
    m_dDCB.fBinary  = TRUE ;
    m_dDCB.fParity  = FALSE ;
   // m_dDCB.fAbortOnError = TRUE;
  //  m_dDCB.fRtsControl = RTS_CONTROL_ENABLE;
  //	m_dDCB.fDtrControl = DTR_CONTROL_ENABLE;		//DTR Ausgang high


// 	dDCB.Flags 	  = 5;;

    if (!SetCommState( m_hPort_s,&m_dDCB ))
    {
        CloseHandle(m_hPort_s);
        error = 4;
        sprintf(m_error, "%s open,but SetCommState() error was:%d! \n", m_port_name, GetLastError());
        printf(m_error);
        //XTPrintf(buff);
        return false;
    }
    SetupComm( m_hPort_s, RXQUEUE, TXQUEUE ) ;
    PurgeComm( m_hPort_s, PURGE_TXCLEAR|PURGE_RXCLEAR );

 //      SetDCB(FBAUDRATE,FBYTESIZE,FPARITY,FSTOPBIT);

    memset( &m_osRead,  0, sizeof( OVERLAPPED ) ) ;
    memset( &m_osWrite, 0, sizeof( OVERLAPPED ) ) ;
      // set up for overlapped I/O
    m_osRead.hEvent = CreateEvent(NULL,// LPSECURITY_ATTRIBUTES lpsa
			    TRUE, // BOOL fManualReset
			    FALSE, // BOOL fInitialState
			    NULL); // LPTSTR lpszEventName
    if(m_osRead.hEvent == INVALID_HANDLE_VALUE)
    {
        CloseHandle(m_hPort_s);
        error = 5;
        sprintf(m_error, "%s open,but Set event error was !!", m_hPort_s);
        printf(m_error);
            //XTPrintf(buff);
        return false;
    }

       // Initialize the rest of the OVERLAPPED structure to zero.
 /*   m_osRead.Internal = 0;
    m_osRead.InternalHigh = 0;
    m_osRead.Offset = 0;
    m_osRead.OffsetHigh = 0; */

    m_osWrite.hEvent = CreateEvent(NULL,// LPSECURITY_ATTRIBUTES lpsa
			    TRUE, // BOOL fManualReset
			    FALSE, // BOOL fInitialState
			    NULL); // LPTSTR lpszEventName
    if(m_osWrite.hEvent == INVALID_HANDLE_VALUE)
    {
        CloseHandle(m_hPort_s);
        error = 6;
        sprintf(m_error, "%s open,but Set event error was !!", m_hPort_s);
        printf(m_error);
        //XTPrintf(buff);
        return false;
    }

    //9600
    CommTimeOuts.ReadIntervalTimeout = 10;
    CommTimeOuts.ReadTotalTimeoutMultiplier = 2;
    CommTimeOuts.ReadTotalTimeoutConstant = 0 ;

   /* CommTimeOuts.ReadIntervalTimeout = 0;
    CommTimeOuts.ReadTotalTimeoutMultiplier = 0 ;
    CommTimeOuts.ReadTotalTimeoutConstant = 0 ;*/

    CommTimeOuts.WriteTotalTimeoutMultiplier = 2 + (2*CBR_19200/com.Baudrate) ;
  // CommTimeOuts.WriteTotalTimeoutMultiplier =  4;
    CommTimeOuts.WriteTotalTimeoutConstant = 0 ;
    if (!SetCommTimeouts(m_hPort_s, &CommTimeOuts ))
    {
        CloseHandle(m_hPort_s);
        error = 7;
        sprintf(m_error, "%s open,but GetCommState() error was !!", m_hPort_s);
        printf(m_error);
        //XTPrintf(buff);
        return false;
    }
    error = 0;


    //Thread
     DWORD dwThreadId;


    
    m_hThread = CreateThread( NULL,
                                 0,
                                 CSerialPort::execute,
                                 this,
                                 CREATE_SUSPENDED,
                                 &dwThreadId);

    if (m_hThread == NULL)
    {
        return false;
    }

    if (!CreateEventA( NULL,FALSE,FALSE,"SERIALRECEIVER" ))
    {
        return false;
    }

    m_hEvent = OpenEventA( EVENT_ALL_ACCESS,TRUE,"SERIALRECEIVER");
    if(!m_hEvent)
    {
        return false;
    }
    ResumeThread(m_hThread);

                        
    Printf(m_port_name);
    m_bOpened =  true;
    return true;
}/* com(...) */

//-------------------------------------------------------------------------
CSerialPort::~CSerialPort(void)
{
    Close();


}/* ~com(void) */


//-------------------------------------------------------------------------
BOOL CSerialPort::Open(int com_num, int baud )
{
   COM_SET com;

   com.Port  = com_num;
   com.Baudrate = baud;
   com.ByteSize = 8;
   com.Parity = NOPARITY;
   com.StopBits =  ONESTOPBIT;// TWOSTOPBITS;// ONESTOPBIT;
   int error;
   bool res = Init(com, error );
   BOOL bRes = (res)? TRUE: FALSE;
   return res;
}

//--------------------------------------------------------------------------
bool CSerialPort::Close( void )
{
	if( !m_bOpened || m_hPort_s == NULL )
        return false;

    m_terminated = true;
	if( m_osRead.hEvent != NULL )
        CloseHandle( m_osRead.hEvent );
	if( m_osWrite.hEvent != NULL )
        CloseHandle( m_osWrite.hEvent );
	CloseHandle( m_hPort_s );
	m_bOpened = false;
	m_hPort_s = NULL;

	return true;

}

//--------------------------------------------------------------------------
int CSerialPort::ReadDataWaiting( void )
{

	if( !m_bOpened || m_hPort_s == NULL )
        return( 0 );

   	DWORD dwErrorFlags;
	COMSTAT ComStat;

	ClearCommError( m_hPort_s, &dwErrorFlags, &ComStat );

//###########################################################################
	// eingefuegt HR
	// wenn nur ein Zeichen abgefragt wird und dabei ein Break erkannt wurde
	if(dwErrorFlags & CE_BREAK)
		m_bBreakErkannt = TRUE;
//###########################################################################

	return( (int) ComStat.cbInQue );

}

//----------------------------------------------------
int CSerialPort::ReadData( void *buffer, int limit )
{

	if( !m_bOpened || m_hPort_s == NULL )
        return( 0 );

	BOOL bReadStatus;
	DWORD dwBytesRead, dwErrorFlags;
  //	COMSTAT ComStat;

  /* 	ClearCommError( m_hPort_s, &dwErrorFlags, &ComStat );
	if( !ComStat.cbInQue )
        return( 0 );

	dwBytesRead = (DWORD) ComStat.cbInQue;
   	if( limit < (int) dwBytesRead )  */
        dwBytesRead = (DWORD) limit;

	bReadStatus = ReadFile( m_hPort_s, buffer, dwBytesRead, &dwBytesRead, &m_osRead);

	if( !bReadStatus )
    {
		if( GetLastError() == ERROR_IO_PENDING )
        {
			WaitForSingleObject( m_osRead.hEvent, 2000 );
			return( (int) dwBytesRead );
        }
		return( 0 );
    }
	return( (int) dwBytesRead );
}

//--------------------------------------------------------------------------
DWORD CSerialPort::ReadCom(LPSTR lpszBlock, int nMaxLength )
{
   DWORD iBytesReadThisTime=0;
   DWORD iBytesRead=0;
   BOOL       fReadStat ;
   COMSTAT    ComStat ;
   DWORD      dwErrorFlags;
   DWORD     dwError,dwTr;
   DWORD       dwLength;

   dwTr = nMaxLength;

   if (dwTr <= 0)
    return 0;

   while(dwTr)
   {
        fReadStat = ReadFile( m_hPort_s, &lpszBlock[iBytesRead], dwTr, &iBytesReadThisTime, &m_osRead ) ;
        if (!fReadStat && (GetLastError() == ERROR_IO_PENDING))
        {
                if(!GetOverlappedResult( m_hPort_s,&m_osRead, &dwTr, TRUE ))
                {
                    dwError = GetLastError();
                    if(dwError == ERROR_IO_INCOMPLETE)
                        continue;
                    else
                    {
                        ClearCommError( m_hPort_s, &dwErrorFlags, &ComStat) ;
                        dwLength=0;
                        return 0;
                    }
                }
                iBytesRead+=dwTr;
        }
        else
        {
                ClearCommError( m_hPort_s, &dwErrorFlags, &ComStat ) ;
                iBytesRead+=iBytesReadThisTime;
                break;
        }
    }
   ClearCommError( m_hPort_s, &dwErrorFlags, &ComStat) ;
   dwLength = iBytesRead;

//  if (dwLength)
//       dump(  lpszBlock, dwLength);
   return dwLength;
}/*  DWORD __fastcall  Tcom::ReadCommBlock(..)*/


//--------------------------------------------------------------------------
DWORD  CSerialPort::WriteCom(char* buf,int len)
{
    DWORD write;
//	DWORD dwBytesSent=0;
	DWORD dwErrorFlags;
   	COMSTAT     ComStat;
  

	if (len <= 0)
		return -1;

    if(!WriteFile(m_hPort_s,buf,len,&write,&m_osWrite))
 	{
		if(GetLastError() == ERROR_IO_PENDING)
		{
         	while(GetOverlappedResult( m_hPort_s, &m_osWrite, &write, TRUE ))
         	{
           		if (GetLastError() == ERROR_IO_INCOMPLETE)
            	{
               		continue;
            	}
            	else
            	{
               		ClearCommError( m_hPort_s, &dwErrorFlags, &ComStat ) ;
               		break;
            	}
			}
		}
		else
		{
            ClearCommError( m_hPort_s, &dwErrorFlags, &ComStat ) ;
		}
    }
   // dump(  "Send: ", buf, write, NULL );
    return write;
}


//--------------------------------------------------------------------------
BOOL CSerialPort::WriteCommByte( unsigned char ucByte )
{
	BOOL bWriteStat;
	DWORD dwBytesWritten;

	bWriteStat = WriteFile( m_hPort_s, (LPSTR) &ucByte, 1, &dwBytesWritten, &m_osWrite);
	if( !bWriteStat && ( GetLastError() == ERROR_IO_PENDING ) )
    {

       // printf("W\n");
		if( WaitForSingleObject( m_osWrite.hEvent, 10 ) )
            dwBytesWritten = 0;
		else
        {
			GetOverlappedResult( m_hPort_s, &m_osWrite, &dwBytesWritten, FALSE );
			m_osWrite.Offset += dwBytesWritten;
        }
    }
    if ( dwBytesWritten == 0)
       return false;
	return( TRUE );

}

//-----------------------------------------------------
int CSerialPort::SendData( char *buffer, int size )
{
	if( !m_bOpened || m_hPort_s == NULL )
        return( 0 );

  /*	DWORD dwBytesWritten = 0;
	int i;
	for( i=0; i<size; i++ )
    {
		if (WriteCommByte( buffer[i] ) == 0)
            return 0;
		dwBytesWritten++;
    }

	return( (int) dwBytesWritten );  */

    return (BOOL)WriteCom(buffer,size);

}


//-----------------------------------------------------
void CSerialPort ::SetRTSEnable()
{
    if (m_hPort_s == NULL)
        return;

    GetCommState(m_hPort_s,&m_dDCB);
    if (m_dDCB.fRtsControl == RTS_CONTROL_ENABLE)
        return;
    else
    {
//Set the RTS enable.
        m_dDCB.fRtsControl = RTS_CONTROL_ENABLE;
        SetCommState(m_hPort_s,&m_dDCB);
    }
}

//-----------------------------------------------------
void CSerialPort::SetRTSDisable()
{
    if (m_hPort_s == NULL)
        return;
        GetCommState(m_hPort_s,&m_dDCB);
    if (m_dDCB.fRtsControl == RTS_CONTROL_DISABLE)
        return;
    else
    {
    //Set the RTS enable.
        m_dDCB.fRtsControl =RTS_CONTROL_DISABLE;
        SetCommState(m_hPort_s,&m_dDCB);
    }
}

//-----------------------------------------------------
int CSerialPort::SetBreak()
{
	
	if( !m_bOpened || m_hPort_s == NULL )
        return( 0 );

	return SetCommBreak(m_hPort_s) ;
}

//-----------------------------------------------------
int CSerialPort::ClearBreak()
{
	
	if( !m_bOpened || m_hPort_s == NULL )
        return( 0 );

	return ClearCommBreak(m_hPort_s) ;
}

//-----------------------------------------------------
int CSerialPort::ClearInputBuffer()
{
	
	if( !m_bOpened || m_hPort_s == NULL )
        return( 0 );

	return PurgeComm(m_hPort_s, 
									PURGE_RXABORT|

									PURGE_RXCLEAR);
}


//---------------------------------------------------------------------
DWORD WINAPI CSerialPort::execute( void* thread )
{
    int res;
    try
    {
      res = ((CSerialPort*)thread)->run();
    }
    catch(...)
    {
        //char msg[100];
        //sprintf(msg,"PokExecutor: run execute ,error_code:%d",GetLastError());
      //  assert(0);
    }
    return res;
}

//---------------------------------------------------------------------
void __fastcall  CSerialPort::CompleteRequest()
{
   // int ii;
  //  char *p;

    if (((m_recbuff[0] == ':') || (m_recbuff[0] == '!')) && (m_callback))
        (*m_callback)(&m_recbuff[1]);
    else
   /* {
        p = strtok(recbuff_m, "\n");
        while (p)
        {
             Printf(p) ;
             p = strtok(NULL, "\n");
        }
    }  */
      printf("%s\n", m_recbuff);
}

//---------------------------------------------------------------------
// Main Thread function.
int CSerialPort::run()
{
    COMSTAT     ComStat ;
    DWORD       dwEvtMask;
    DWORD       dwErrorFlags;

    m_terminated = 0;

     if (!SetCommMask( m_hPort_s, EV_RXCHAR|EV_ERR|EV_TXEMPTY|EV_BREAK ))
     {
        printf("ComSerial error -- SetCommMask: %d\n",GetLastError());
        return 0;
     }
 printf("start serial thread\n");

    while(!m_terminated)
    {
        dwEvtMask = 0 ;

        if (WaitCommEvent(m_hPort_s, &dwEvtMask, NULL/*&m_osRead*/))
        {
            if (m_terminated)
                break;
            //printf("commevent \n");
            switch (dwEvtMask & 0xFBFF)
            {
                case EV_ERR :
                     printf("ERec \n");
                    ClearCommError( m_hPort_s, &dwErrorFlags, &ComStat) ;
                    break;
                case EV_RXCHAR:
               // case 1025:

              //   printf("Rec \n");
                    if ((m_rec_length = ReadCom/*ReadData*/( m_recbuff,128)) == 0)
                    {
                   //     printf("Rec Error\n");
                        ClearCommError( m_hPort_s, &dwErrorFlags, &ComStat) ;
                        break;
                    }
                    m_rec_length = (m_rec_length > RXQUEUE) ? (RXQUEUE - 1) : m_rec_length ;
                    m_recbuff[m_rec_length] = 0;
                    CompleteRequest();

                //    printf("%s\n", m_recbuff);
                  // dump(  "R:", m_recbuff, m_rec_length,NULL );
                /*    dwErrorFlags = m_parent->CompleteRequest(m_recbuff,m_rec_length,m_callback);
                    if (dwErrorFlags)
                    {
                        printf("Rec-ERROR:CompleteRequest: %d\n",dwErrorFlags);
                        dump(  "rec_error", m_recbuff, m_rec_length,NULL );
                    }  */
                    break;
                case EV_TXEMPTY:
                {
                   //     printf("EV_TXEMPTY \n");
                    break;
                }
                 case EV_BREAK:
                {
                        printf("EV_BREAK \n");
                    break;
                }
                default:
               //     printf("default :%x\n",dwEvtMask);
                    break;
            }
        }
        else
        {
            DWORD dwRet = GetLastError();
            if( ERROR_IO_PENDING == dwRet)
            {
                printf("I/O is pending...\n");

            // To do.
            }
            else
              //  printf("Wait failed with error %d.\n", GetLastError());
                printf("ComSerial error -- WaitCommEvent: %d\n",GetLastError());
             ClearCommError( m_hPort_s, &dwErrorFlags, &ComStat) ;
            //m_terminated = 1;
        }
      
    }
    m_terminated = 0;
    printf("SerialPort Thread Exit\n");
     return 1;
}





/***************************************************************************/
/*  FUNCTION-NAME  :  dump                                                 */
/*  DESCRIPTION    :  dumps a buffer                                       */
/*  PARAMETERS     :  - buffer to be dumped                                */
/*                    - lenght of buffer                                   */
/*  RETURN-VALUE   :  - TRUE if OK.                                        */
/*                    - FALSE otherwise                                    */
/*  EXTERNAL REFERENCES : none                                             */
/*  MODIFIED EXTERNALS  : none                                             */
/***************************************************************************/
BOOL dump(  const char* mess, void *buf, unsigned long len, VIEW func )
{
#define DUMP_LINE_LEN 16
#define min(a,b)  ((a) < (b) ? (a) : (b) )
        unsigned short line, incr;
        unsigned char *p;
        unsigned short i,c;
        unsigned char  left[DUMP_LINE_LEN*3+2], right[DUMP_LINE_LEN+1];
        char	sRes[100];
        // invalid pointer ?
	if (!buf)
           return FALSE;
        for (p = (unsigned char*)buf, line = 0; len; p += incr, len -= incr, line++)
        {
            incr = (unsigned short)min( len, DUMP_LINE_LEN);
	        memset(right, 0, sizeof(right));
	        for (i = 0; i < incr; i++ )
		    {
                sprintf((char*)&left[i*3], "%02X ", c = (unsigned short)p[i]);
                right[i] = (unsigned char)(isprint(c) ? c:'.');
            }
            if (mess)
                sprintf(sRes,"%s:%04X: %-48s [%-16s]\n",mess,line*DUMP_LINE_LEN, left, right);
            else
                sprintf(sRes,"%04X: %-48s [%-16s]\n", line*DUMP_LINE_LEN, left, right);
     //        XTPrintf(sRes);
            if (func)
                (*func)(sRes);
            else
             printf(sRes);

        }
 //       XTPrintf(sRes);
	return TRUE;
} // dump

