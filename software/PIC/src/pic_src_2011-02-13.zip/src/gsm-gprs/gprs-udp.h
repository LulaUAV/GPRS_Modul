//**********************************
//	Tiszai Istvan,  2011.04
//**********************************
#ifndef _GPRS_UDP

#define UDP_SYNC1	0xC4
#define UDP_SYNC2	0xD7
//#define UDP_MANF_ID	0x00	//Villbau saj�t kommunik�tor
#define UDP_MANFID		0x10	//Wilarm GPRS kommunik�tor
#define UDP_SERNUM		0x00    //Egyedi esem�nyazonos�t� (fut� sz�ml�l�):0x00-0xFF
#define UDP_FORMATID1_0 0x31	//Contact ID
#define UDP_FORMATID1_1 0x38	//Contact ID
#define UDP_FORMATID2_0 0x00	//Adatk�ld�s (pl. modul verzi� stb.)
#define UDP_FORMATID2_1 0x00	//Adatk�ld�s (pl. modul verzi� stb.)	
#define UDP_IMEI 		"356895039804003"    //GPRS modul IMEI sz�ma, eepromb�l
#define UDP_TRAIL 		0x00	//0x00 trail a word-alignment megtart�s�ra
#define UDP_INFO_1 		"OK"	//Visszajelz�s (pozit�v/negat�v) nyugta
#define UDP_INFO_2 		"??"	//Visszajelz�s (pozit�v/negat�v) nyugta

//string index-ek.
#define UDP_SYNC1_I 		0
#define UDP_SYNC2_I 		UDP_SYNC1_I + 1
#define UDP_MANF_I 			UDP_SYNC2_I + 1
#define UDP_SERNUM_I 		UDP_MANF_I + 1
#define UDP_ACCOUNT_I 		UDP_SERNUM_I + 1
#define UDP_FORMATID_I 		UDP_ACCOUNT_I + 4
#define UDP_EVENT_I 		UDP_FORMATID_I + 2
#define UDP_GROUP_I 		UDP_EVENT_I + 4
#define UDP_ZONE_USER_I 	UDP_GROUP_I + 2
#define UDP_CHK_I 			UDP_ZONE_USER_I + 3
#define UDP_IMEI_I 			UDP_CHK_I + 1
#define UDP_TRAIL_I 		UDP_IMEI_I + 15
#define UDP_END_I 			UDP_TRAIL_I + 1

typedef enum {
	MESSAGEudp,
	DATEudp
} UDPMODE;

#endif //_GPRS_UDP