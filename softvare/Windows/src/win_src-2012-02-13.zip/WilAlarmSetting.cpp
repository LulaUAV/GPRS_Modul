//---------------------------------------------------------------------------

#include <vcl.h>
#include <stdio.h>
#pragma hdrstop

#include "WilAlarmSetting.h"
#include "WilAlarmMain.h"
#include "SerialCom.h"
//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma resource "*.dfm"
TWASetting *WASetting;

extern void Warning_Message(char* msg);
extern DWORD Send(char* msg, int len, VIEW callback);
extern void clear_callback();

//---------------------------------------------------------------------------
void setting_request(const char* msg)
{
    WASetting->setting_request(msg);
}

//---------------------------------------------------------------------------
__fastcall TWASetting::TWASetting(TComponent* Owner)
    : TForm(Owner)
{
}
//---------------------------------------------------------------------------
void __fastcall TWASetting::ExitBtnClick(TObject *Sender)
{
    Close();    
}
//---------------------------------------------------------------------------
void __fastcall TWASetting::SendAPNBtnClick(TObject *Sender)
{
   if (APNEdit->Text.IsEmpty())
   {
        Warning_Message("APN mez� �res!");
        return;
   }

   if (APNEdit->Text.Length() > 24)
   {
        Warning_Message("APN mez� 24 karaktern�l nem lehet hosszabb");
        return;
   }


   if (Application->MessageBox("Mehet a APN k�ld�se az eszk�zbe?", "Let�lt�sre k�rd�s.",MB_YESNO	) == IDYES  )
   {
         char msg[32];


        msg[0] = 'E';
        msg[1] = 'S';
        msg[2] = 'A';
        msg[3] = APNEdit->Text.Length()+1;


      //  char* strApn = APNEdit->Text.c_str();

        strncpy(&msg[4],APNEdit->Text.c_str(),24);

        msg[4+APNEdit->Text.Length()] = 0;


        Send(msg, APNEdit->Text.Length()+6,::setting_request);
   }
}
//---------------------------------------------------------------------------

void __fastcall TWASetting::SendDomainBtnClick(TObject *Sender)
{
    if (DomainEdit->Text.IsEmpty())
   {
        Warning_Message("Domain mez� �res!");
        return;
   }

   if (DomainEdit->Text.Length() > 24)
   {
        Warning_Message("Domain mez� 24 karaktern�l nem lehet hosszabb");
        return;
   }


   if (Application->MessageBox("Mehet a Domain k�ld�se az eszk�zbe?", "Let�lt�sre k�rd�s.",MB_YESNO	) == IDYES  )
   {
        char msg[32];
        msg[0] = 'E';
        msg[1] = 'S';
        msg[2] = 'D';
        msg[3] = DomainEdit->Text.Length()+1;


       // char* strDomain = DomainEdit->Text.c_str();

        strncpy(&msg[4],DomainEdit->Text.c_str(),24);
        msg[4+DomainEdit->Text.Length()] = 0;

        Send(msg, DomainEdit->Text.Length()+6, ::setting_request);
   }
}


//---------------------------------------------------------------------------
void __fastcall TWASetting::setting_request(const char* msg)
{
    if (msg)
    {
        if (msg[0] == 'E')
        { //EEprom
            if ((msg[1] == 'D') && ((msg[2] > 0) && (msg[2] < 25)) && (msg[3] < 128))
            {   // Domain
                 DomainEdit->Text = AnsiString(&msg[3]);
                 if (m_start)
                     getAPN();
            }
            else
            if ((msg[1] == 'A') && ((msg[2] > 0) && (msg[2] < 25)) && (msg[3] < 128))
            {   // APN
                 APNEdit->Text = AnsiString(&msg[3]);
                 if (m_start)
                     getDNSpri();
            }
            else
            if ((msg[1] == 'p') && (msg[2] > 0))
            {   // DSN
                char buff1[5], buff2[5], buff3[5], buff4[5];
                int ii,ff,ee;
                for (ii=0; ii<5; ii++)
                {
                    buff1[ii] = 0;
                    buff2[ii] = 0;
                    buff3[ii] = 0;
                    buff4[ii] = 0;
                }
                for (ii = 0, ff = 0, ee = 0; (ii<DNS_IP_LEN && msg[3+ii]); ii++, ee++)
                {
                    if (msg[3+ii] == '.')
                    {
                        ff++;
                        ee = -1;
                        continue;
                    }
                    switch (ff)
                    {
                        case 0:
                                buff1[ee] = msg[3+ii];
                            break;
                        case 1:
                                buff2[ee] = msg[3+ii];
                            break;
                        case 2:
                                buff3[ee] = msg[3+ii];
                            break;
                        case 3:
                                buff4[ee] = msg[3+ii];
                            break;
                    }
                }
                buff1[3] = 0;
                buff2[3] = 0;
                buff3[3] = 0;
                buff4[3] = 0;
                DNSPriIP1Edit->Text = AnsiString(buff1);
                DNSPriIP2Edit->Text = AnsiString(buff2);
                DNSPriIP3Edit->Text = AnsiString(buff3);
                DNSPriIP4Edit->Text = AnsiString(buff4);
                if (m_start)
                     getDNSsec();
            }
            else
            if ((msg[1] == 's') && (msg[2] > 0))
            {   // DSN  sec
                char buff1[5], buff2[5], buff3[5], buff4[5];
                int ii,ff,ee;
                for (ii=0; ii<5; ii++)
                {
                    buff1[ii] = 0;
                    buff2[ii] = 0;
                    buff3[ii] = 0;
                    buff4[ii] = 0;
                }

                for (ii = 0, ff = 0, ee = 0; (ii<DNS_IP_LEN && msg[3+ii]); ii++, ee++)
                {
                    if (msg[3+ii] == '.')
                    {
                        ff++;
                        ee = -1;
                        continue;
                    }
                    switch (ff)
                    {
                        case 0:
                                buff1[ee] = msg[3+ii];
                            break;
                        case 1:
                                buff2[ee] = msg[3+ii];
                            break;
                        case 2:
                                buff3[ee] = msg[3+ii];
                            break;
                        case 3:
                                buff4[ee] = msg[3+ii];
                            break;
                    }
                }
                buff1[3] = 0;
                buff2[3] = 0;
                buff3[3] = 0;
                buff4[3] = 0;
                DNSSecIP1Edit->Text = AnsiString(buff1);
                DNSSecIP2Edit->Text = AnsiString(buff2);
                DNSSecIP3Edit->Text = AnsiString(buff3);
                DNSSecIP4Edit->Text = AnsiString(buff4);
                m_start = false;
            }

        }
        else
        if (msg[0] == 'T')
        {   // system
             if (msg[1] == 'A')
             {  //alive
                 WilAlarmM->rAlive();
             }
        }
      /*  else
        if (msg[0] == '!')
        {   // error
            if (msg[1] == 'D')
            {
                printf("Domain Error: %d\n",msg[3]);
                if (m_start)
                    getAPN();
            }
            else
            if (msg[1] == 'A')
            {
                printf("APN Error: %d\n",msg[3]);
                m_start = false;
            }
        }   */

    }
}

//---------------------------------------------------------------------------
void __fastcall TWASetting::FormClose(TObject *Sender,
      TCloseAction &Action)
{
     clear_callback();    
}


//---------------------------------------------------------------------------
void __fastcall TWASetting::getDomain()
{
        char msg[5];
        msg[0] = 'E';
        msg[1] = 'G';
        msg[2] = 'D';
        msg[3] = 0;

        Send(msg, 4, ::setting_request);
}


//---------------------------------------------------------------------------
void __fastcall TWASetting::getAPN()
{
        char msg[5];
        msg[0] = 'E';
        msg[1] = 'G';
        msg[2] = 'A';
        msg[3] = 0;

        Send(msg, 4, ::setting_request);
}

//---------------------------------------------------------------------------
void __fastcall TWASetting::getDNSpri()
{
        char msg[5];
        msg[0] = 'E';
        msg[1] = 'G';
        msg[2] = 'p';
        msg[3] = 0;

        Send(msg, 4, ::setting_request);
}

//---------------------------------------------------------------------------
void __fastcall TWASetting::getDNSsec()
{
        char msg[5];
        msg[0] = 'E';
        msg[1] = 'G';
        msg[2] = 's';
        msg[3] = 0;

        Send(msg, 4, ::setting_request);
}

//---------------------------------------------------------------------------
void __fastcall TWASetting::SAlive()
{
     char msg[5];
     msg[0] = 'T';
     msg[1] = 'A';
     msg[2] = 0;

     Send(msg, 3, ::setting_request);
}

//---------------------------------------------------------------------------
void __fastcall TWASetting::FormShow(TObject *Sender)
{
        APNEdit->Text = "";
        DomainEdit->Text = "";
        getDomain();
        m_start = true;
}
//---------------------------------------------------------------------------

void __fastcall TWASetting::FormCreate(TObject *Sender)
{
     m_start = false;    
}

//---------------------------------------------------------------------------
void __fastcall TWASetting::ResetBtnClick(TObject *Sender)
{
    if (Application->MessageBox("�jraind�thatom az egys�get?", "Rendszer k�rd�s.",MB_YESNO	) == IDYES  )
    {
        char msg[5];
        msg[0] = 'T';
        msg[1] = 'R';
        Send(msg, 2, NULL);
        WilAlarmM->m_alive_counter = 10;
        WilAlarmM->setEnable(false);
        Close();
    }
}
//---------------------------------------------------------------------------

void __fastcall TWASetting::SendPriIPBtnClick(TObject *Sender)
{
    int ii;
    if (DNSPriIP1Edit->Text.IsEmpty())
    {
        Warning_Message("IP 1. c�m �res!");
        return;
    }

    try
    {
         ii = DNSPriIP1Edit->Text.ToInt();
    }
    catch(...)
    {
        Warning_Message("IP 1. c�m nem sz�m!");
        return;
    }

    if (DNSPriIP2Edit->Text.IsEmpty())
    {
        Warning_Message("IP 2. c�m �res!");
        return;
    }

    try
    {
         ii = DNSPriIP2Edit->Text.ToInt();
    }
    catch(...)
    {
        Warning_Message("IP 2. c�m nem sz�m!");
        return;
    }

    if (DNSPriIP3Edit->Text.IsEmpty())
    {
        Warning_Message("IP 3. c�m �res!");
        return;
    }

    try
    {
         ii = DNSPriIP3Edit->Text.ToInt();
    }
    catch(...)
    {
        Warning_Message("IP 3. c�m nem sz�m!");
        return;
    }

    if (DNSPriIP4Edit->Text.IsEmpty())
    {
        Warning_Message("IP 4. c�m �res!");
        return;
    }

    try
    {
         ii = DNSPriIP4Edit->Text.ToInt();
    }
    catch(...)
    {
        Warning_Message("IP 4. c�m nem sz�m!");
        return;
    }

   if (Application->MessageBox("Mehet a primary DNS szerver IP c�m az eszk�zbe?", "Let�lt�sre k�rd�s.",MB_YESNO	) == IDYES  )
   {
        char msg[32];
        for (ii=0; ii<32; ii++)
              msg[ii] = 0;
        msg[0] = 'E';
        msg[1] = 'S';
        msg[2] = 'p';
        msg[3] = DNS_IP_LEN;

        AnsiString IP = DNSPriIP1Edit->Text + "." + DNSPriIP2Edit->Text + "." + DNSPriIP3Edit->Text + "." + DNSPriIP4Edit->Text;

        strcpy(&msg[4],IP.c_str());
       // msg[4+12] = 0;

        Send(msg, DNS_IP_LEN+4, ::setting_request);
   }
}

//---------------------------------------------------------------------------
void __fastcall TWASetting::SendSecIPBtnClick(TObject *Sender)
{
    int ii;
    if (DNSSecIP1Edit->Text.IsEmpty())
    {
        Warning_Message("IP 1. c�m �res!");
        return;
    }

    try
    {
         ii = DNSSecIP1Edit->Text.ToInt();
    }
    catch(...)
    {
        Warning_Message("IP 1. c�m nem sz�m!");
        return;
    }

    if (DNSSecIP2Edit->Text.IsEmpty())
    {
        Warning_Message("IP 2. c�m �res!");
        return;
    }

    try
    {
         ii = DNSSecIP2Edit->Text.ToInt();
    }
    catch(...)
    {
        Warning_Message("IP 2. c�m nem sz�m!");
        return;
    }

    if (DNSSecIP3Edit->Text.IsEmpty())
    {
        Warning_Message("IP 3. c�m �res!");
        return;
    }

    try
    {
         ii = DNSSecIP3Edit->Text.ToInt();
    }
    catch(...)
    {
        Warning_Message("IP 3. c�m nem sz�m!");
        return;
    }

    if (DNSSecIP4Edit->Text.IsEmpty())
    {
        Warning_Message("IP 4. c�m �res!");
        return;
    }

    try
    {
         ii = DNSSecIP4Edit->Text.ToInt();
    }
    catch(...)
    {
        Warning_Message("IP 4. c�m nem sz�m!");
        return;
    }

   if (Application->MessageBox("Mehet a secundary DNS szerver IP c�m az eszk�zbe?", "Let�lt�sre k�rd�s.",MB_YESNO	) == IDYES  )
   {
        char msg[32];
        for (ii=0; ii<32; ii++)
              msg[ii] = 0;
        msg[0] = 'E';
        msg[1] = 'S';
        msg[2] = 's';
        msg[3] = DNS_IP_LEN;

        AnsiString IP = DNSSecIP1Edit->Text + "." + DNSSecIP2Edit->Text + "." + DNSSecIP3Edit->Text + "." + DNSSecIP4Edit->Text;

        strcpy(&msg[4],IP.c_str());
       // msg[4+12] = 0;

        Send(msg, DNS_IP_LEN+4, ::setting_request);
   }
}

//---------------------------------------------------------------------------
void __fastcall TWASetting::DSNFactoryBtnClick(TObject *Sender)
{
    if (Application->MessageBox("Gy�ri DNS szerver IP c�m�t vissza�ll�tsam?", "K�rd�s.",MB_YESNO	) == IDYES  )
    {
        char msg[5];
        msg[0] = 'E';
        msg[1] = 'S';
        msg[2] = 'f';
        msg[3] = 0;

        Send(msg, 4, ::setting_request);
          ::Sleep(1500);
         m_start = true;
         getDNSpri();
    }
}
//---------------------------------------------------------------------------







void __fastcall TWASetting::DNSPriIP1EditKeyUp(TObject *Sender, WORD &Key,
      TShiftState Shift)
{
    if ((Key == VK_ESCAPE) || (Key ==VK_RETURN))
    {
       SelectNext( DNSPriIP1Edit, true, true );
    }
}
//---------------------------------------------------------------------------

void __fastcall TWASetting::DNSPriIP2EditKeyUp(TObject *Sender, WORD &Key,
      TShiftState Shift)
{
    if ((Key == VK_ESCAPE) || (Key ==VK_RETURN))
    {
       SelectNext( DNSPriIP2Edit, true, true );
    }
}
//---------------------------------------------------------------------------



void __fastcall TWASetting::DNSPriIP3EditKeyUp(TObject *Sender, WORD &Key,
      TShiftState Shift)
{
    if ((Key == VK_ESCAPE) || (Key ==VK_RETURN))
    {
       SelectNext( DNSPriIP3Edit, true, true );
    }
}
//---------------------------------------------------------------------------

void __fastcall TWASetting::DNSPriIP4EditKeyUp(TObject *Sender, WORD &Key,
      TShiftState Shift)
{
    if ((Key == VK_ESCAPE) || (Key ==VK_RETURN))
    {
       SelectNext( DNSPriIP4Edit, true, true );
    }
}
//---------------------------------------------------------------------------

void __fastcall TWASetting::DNSSecIP1EditKeyUp(TObject *Sender, WORD &Key,
      TShiftState Shift)
{
    if ((Key == VK_ESCAPE) || (Key ==VK_RETURN))
    {
       SelectNext( DNSSecIP1Edit, true, true );
    }
}
//---------------------------------------------------------------------------

void __fastcall TWASetting::DNSSecIP2EditKeyUp(TObject *Sender, WORD &Key,
      TShiftState Shift)
{
    if ((Key == VK_ESCAPE) || (Key ==VK_RETURN))
    {
       SelectNext( DNSSecIP2Edit, true, true );
    }
}
//---------------------------------------------------------------------------

void __fastcall TWASetting::DNSSecIP3EditKeyUp(TObject *Sender, WORD &Key,
      TShiftState Shift)
{
    if ((Key == VK_ESCAPE) || (Key ==VK_RETURN))
    {
       SelectNext( DNSSecIP3Edit, true, true );
    }
}
//---------------------------------------------------------------------------


void __fastcall TWASetting::DNSSecIP4EditKeyUp(TObject *Sender, WORD &Key,
      TShiftState Shift)
{
    if ((Key == VK_ESCAPE) || (Key ==VK_RETURN))
    {
       SelectNext( DNSSecIP4Edit, true, true );
    }
}
//---------------------------------------------------------------------------

void __fastcall TWASetting::GetAPNDomBtnClick(TObject *Sender)
{
    SAlive();    
}
//---------------------------------------------------------------------------

