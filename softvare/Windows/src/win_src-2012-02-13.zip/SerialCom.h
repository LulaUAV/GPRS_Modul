#ifndef SERIALCOM_H
#define SERIALCOM_H

#include <windows.h>

#define RXQUEUE         	256
#define TXQUEUE         	256

#define	COM1				"COM1:"
#define	COM2				"COM2:"

//Defines f�r internen Timer
#define TIMER0 0x40
#define TCTRL  0x43


typedef void (VIEW)(const char*);
typedef short _stdcall (*PtrInp)(short EndPort);
typedef void _stdcall (*PtrOut)(short EndPort, short value);
typedef enum {SEND=0, RECEIVE, ALL} MODE;

typedef struct
{
    bool Enable;
    unsigned short Port;
    MODE Mode;
   // WORD Baudrate;
    DWORD Baudrate;
    BYTE ByteSize;
    BYTE Parity;
    BYTE StopBits;
} COM_SET;




class CSerialPort
{
private:
    static  char        m_port_name[20];
    static  COM_SET     m_com;
    static  DCB			m_dDCB;
    static  OVERLAPPED  m_osRead;
    static  OVERLAPPED  m_osWrite;
    double              m_dTakteProUS;
    bool                m_bOpened;
    HANDLE      m_hThread;
    HANDLE      m_hEvent;
    int         m_terminated;
    int         m_rec_length;
    char        m_recbuff[RXQUEUE];


   // bool m_bOpened;
private:
protected:
    char        m_st_num;
    bool        m_bBreakErkannt;
protected:

    void UsDelay(unsigned long ulTimeInUs);
    bool Close( void );
    int ReadDataWaiting( void );
    static DWORD WINAPI execute( void*);
    int run();
    void __fastcall  CompleteRequest();
public:
    static  HANDLE		m_hPort_s;
    static char m_error[100];
    static VIEW*    m_callback;
public:
    bool Init(COM_SET com,int& error);
    DWORD  ReadCom(LPSTR lpszBlock, int nMaxLength );
    int ReadData( void *buffer, int limit );
    DWORD  WriteCom(char* buf,int len);
    BOOL   WriteCommByte( unsigned char ucByte );
    int    SendData(  char *buffer, int size );
    void SetRTSEnable();
    void SetRTSDisable();
    int  SetBreak();
    int  ClearBreak();
    int  ClearInputBuffer();
    BOOL Open(int com_num, int baud );
     CSerialPort();
    ~CSerialPort(void);
};

extern BOOL dump(  const char* mess, void *buf, unsigned long len, VIEW func );
#endif
 