//**********************************
//	Tiszai Istvan,  2011.03
//**********************************
#ifndef _PC
#define _PC

extern void	USART2IntTasks(void);
extern void pc_init(uint16 usart_baud);
extern void pc_executor(void);
extern void Tx2_Debug(const char* msg_a);
extern void Tx2_Debug_r(const rom char* msg_a);
extern void hex1toa(char t, char* res);
extern char *myStrcpy_r( char *s1, const rom char *s2 ) ;
extern char *myStrcpy( char *s1, const char *s2 ) ;
extern char *myStrcat(char *s, const char *t);
extern char *myStrcat_r(char *s, const rom char *t);

#endif