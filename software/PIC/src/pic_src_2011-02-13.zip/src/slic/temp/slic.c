//**********************************
//	Tiszai Istvan,  2011.03
//**********************************
#include <p18cxxx.h>
//#include <stdio.h>
//#include <string.h>
#include <p18f6527.h>
#include "defines.h"
#include "slic.h"
#include "spi.h"
#include "../pc/pc.h"
#include "utils.h"

const rom WORD slic_definit_reg[] = { 
		INIT_IR0,  INIT_IR1,  INIT_IR2,  INIT_IR3,  INIT_IR4,  INIT_IR5,  INIT_IR6,  INIT_IR7,  INIT_IR8,  INIT_IR9, INIT_IR10, 
		INIT_IR11, INIT_IR12, INIT_IR13, INIT_IR14, INIT_IR15, INIT_IR16, INIT_IR17, INIT_IR18, INIT_IR19, INIT_IR20, 
		INIT_IR21, INIT_IR22, INIT_IR23, INIT_IR24, INIT_IR25, INIT_IR26, INIT_IR27, INIT_IR28, INIT_IR29, INIT_IR30, 
		INIT_IR31, INIT_IR32, INIT_IR33, INIT_IR34,
		//INIT_IR35, INIT_IR36, INIT_IR37, INIT_IR38, INIT_IR39, 
		INIT_IR35_OP, INIT_IR36_OP, INIT_IR37_OP, INIT_IR38_OP, INIT_IR39_OP, 
		INIT_IR40, INIT_IR41, INIT_IR42, INIT_IR43, 
		INIT_IR99, INIT_IR100,INIT_IR101,INIT_IR102,INIT_IR103,INIT_IR104
};

#define SLIC_MAX_INIT_REG43	43
#define SLIC_MAX_INIT_REG99	99
#define SLIC_MAX_INIT_LEN	105

//static int ii_st;

/*SPI data 3 byte
;+0 = CIM
;+1 = DATA vagy DATA_L (indirect)
;+2 = DATA_H (indirect)
*/
//char 	SPIDAT[3];
char	SIISPI;		//SPI index pointer

BYTE hkdtmf[16];

char DTMF[16];		//16 karakteres telefonsz�m �tad� regiszter �s CID �tad�
char DTMFpnt;		// DTMF indexe

char SLICflag;	//Flag bitek sz�pen kihozva, folyamatosan PULL-oza a rutin.
				//bit0 = Loop Closure (telefon fel/le)
				//bit1 = MATAV kicsenget�s kikapcsol�sa
				//bit2 = 400Hz tarcsahang kiadasa
				//bit3 = Aktualis Status (=bit2-vel ha megt�rt�nt) bels� haszn�latra
				//bit4 = DTMF jel j�tt (Felhaszn�l�nak kell t�r�lnie)
				//bit5 = MATAV kicsenget�s vonal felv�telig... (vonalfelv�telkor ez a bit is t�rl�dik)
				//bit6 = ReINI (megv�ltozott param�terek miatt, vagy csak visza�ll�tjuk a be�ll�tottan (dtmf-n�l el kell �ll�tani a t�rcs�hoz))
				//bit7 = SLIC INI, ha =1, akkor INI ready, wait command

const Si321x_Ring_Cfg Si321x_Ring_Presets[] ={


    /* inputs:  ringtrip ac thresh = 0.036, rt debounce = 0.075*/
    { 0x155, 0x0, 0x0, 0x7EFD, 0x80, 0x3E, 0x0, 0x7D, 0x18, 0xA, 0x320 }
};

/*Si3210 Tone generator (8kHz) */
const Si321x_Tone_Cfg Si321x_Tone_Presets [] = 
{
{{OSC_350HZ_MINUS18DBM_8KHZ,OSC_NOTIME,OSC_NOTIME},{OSC_440HZ_MINUS18DBM_8KHZ,OSC_NOTIME,OSC_NOTIME},OSC_TOPHONE,OSC_TOPHONE}, // nincs
{{OSC_480HZ_MINUS18DBM_8KHZ,OSC_0_5SEC,OSC_0_5SEC},{OSC_620HZ_MINUS18DBM_8KHZ,OSC_0_5SEC,OSC_0_5SEC},OSC_TOPHONE,OSC_TOPHONE}, // foglalt
{{OSC_480HZ_MINUS18DBM_8KHZ,OSC_0_2SEC,OSC_0_3SEC},{OSC_620HZ_MINUS18DBM_8KHZ,OSC_0_2SEC,OSC_0_3SEC},OSC_TOPHONE,OSC_TOPHONE},
{{OSC_480HZ_MINUS18DBM_8KHZ,OSC_2SEC,OSC_4SEC},{OSC_440HZ_MINUS18DBM_8KHZ,OSC_2SEC,OSC_4SEC},OSC_TOPHONE,OSC_TOPHONE},//cs�rg�s
{{OSC_480HZ_MINUS18DBM_8KHZ,OSC_0_3SEC,OSC_0_2SEC},{OSC_620HZ_MINUS18DBM_8KHZ,OSC_0_3SEC,OSC_0_2SEC},OSC_TOPHONE,OSC_TOPHONE}
};

const Si321x_PCM_Cfg Si321x_Pcm_Presets[] =
{

    /* inputs:  u-law narrowband positive  */
    { 0x1, 0x0, 0x0 },
    /* inputs:  16 bit wideband positive  */
    { 0x3, 0x1, 0x0 }
};

#define AUDIOGAIN_0DB	0

const Si321x_audioGain_Cfg Si321x_AudioGain_Presets [] = 
{
	{AUDIOGAIN_0DB,0x4000}
};

const Si321x_FSK_Cfg Si321x_FSK_Presets[] ={

    /* inputs: mark freq=1200.000, space freq2200.000, amp=0.220, baud=1200.000 */
    { 0x1119L, 0x3BE1L, 0x1E0L, 0x100L, 0x35B0L, 0x3CE0L }
};

//----------------------------------
void delay(int d)
{
	while(d--)
	{
	_asm
    	nop
  	_endasm
	}
}

//----------------------------------
void slic_wait(int ms)
{
	timersDec[SLICtdindex] = ms;
	while (timersDec[SLICtdindex]);
}
//----------------------------------
void slic_power_on_reset(void)
{
//Power ON / RESET vonalszimulator
	CS3210 = 1;			//Chip select off
	//mov#	D3210,05		//500msec wait
	slic_wait(500);
	PORTCbits.RC3	= 1;		//SCK magasan tart...
	T_RESET = 0;			//Reset aktiv
}

//----------------------------------
int slic_set_indirectreg_init(void)
{
	BYTE ii=0;
	BYTE kk=0;
	BYTE ee=0;
	WORD temp;	
	while (ii != SLIC_MAX_INIT_LEN)
	{
		if ((ii > SLIC_MAX_INIT_REG43) && (ii < SLIC_MAX_INIT_REG99))
		{
			ii++;
			continue;
		}
	/*	else
		if  (ii == SLIC_MAX_INIT_REG99)
		{
			ee++;
		}*/
		for (kk=0;kk<3;kk++)
		{
			if (WriteProSLICIndirectRegister (ii, slic_definit_reg[ee]) == 0)
				break;			
		}
		if (kk == 3)
			return 1;
		for (kk=0;kk<3;kk++)
		{
			temp = ReadProSLICIndirectRegister (ii);
			if (temp == slic_definit_reg[ee])
				break;			
		}
		if (kk == 3)
			return 2;
		ee++;
		ii++;
	}
	return 0;
}

//-------------------------------------------------------
void slic_RingSetup (int preset)
{

	WriteProSLICIndirectRegister(RING_X,Si321x_Ring_Presets[preset].rngx);/* Ringing Oscillator Amplitude */
	WriteProSLICIndirectRegister(RING_Y,Si321x_Ring_Presets[preset].rngy);/*Ringing Oscillator Initial Phase */
	WriteProSLICIndirectRegister(RING_V_OFF,Si321x_Ring_Presets[preset].roff);/*Ringing Oscillator DC Offset */
	WriteProSLICIndirectRegister(RING_OSC_COEF,Si321x_Ring_Presets[preset].rco); /* Ringing Oscillator Frequency */
	
	/* Active Timer */
	WriteProSLICDirectRegister(RING_ON_HI,(Si321x_Ring_Presets[preset].tahi));
	WriteProSLICDirectRegister(RING_ON__LO,(Si321x_Ring_Presets[preset].talo));

	/*  Inactive Timer */
	WriteProSLICDirectRegister(RING_OFF_HI,(Si321x_Ring_Presets[preset].tihi));
	WriteProSLICDirectRegister(RING_OFF_LO,(Si321x_Ring_Presets[preset].tilo));


	WriteProSLICDirectRegister(RING_OSC_CTL,(Si321x_Ring_Presets[preset].ringcon));
	WriteProSLICDirectRegister(RT_DEBOUCE,Si321x_Ring_Presets[preset].rtdi);
	WriteProSLICIndirectRegister(RING_TRIP_FILTER,Si321x_Ring_Presets[preset].nrtp);
}


//----------------------------------
#define SI321X_POWERUP_VOLT_THRESH 0x11


//#define INIT_SI3210M_DR92 0x67  
//#define INIT_SI3210M_DR93 0x16 

//----------------------------------
int slic_powerUp()
{ 
	unsigned char data, data2, i;
	unsigned int vBat, vBatProg, vBatTarget;

	WriteProSLICDirectRegister(92, INIT_SI3210M_DR92);
	WriteProSLICDirectRegister(93, INIT_SI3210M_DR93);

	data = ReadProSLICDirectRegister(80);		/*vtip*/
	data2 = ReadProSLICDirectRegister(81);	/*vring*/
	if ((data > SI321X_POWERUP_VOLT_THRESH) || (data2 > SI321X_POWERUP_VOLT_THRESH))
	{
		DBG_r("SLIC:RC_VBAT_OUT_OF_RANGE:ERROR\r\n");	
		return 1;			
	}
		
	//SI321X_HV
	WriteProSLICDirectRegister (74, 45); // 45*1.5 V = 67.5V
	//WriteProSLICDirectRegister(74, 0x1d);/*vbath */
//	WriteProSLICDirectRegister(75, 0x9);//vbatl
//	WriteProSLICDirectRegister(72, 0x12);//voc 
//	WriteProSLICDirectRegister(73, 0x1);//vcm 

	WriteProSLICDirectRegister(14, 0);/* Enable DC-DC converter */

	/* Wait for measured VBAT to be "close" to desired value.  Always
	 check for a voltage at least 6-10v below programmed level
	 within 200ms */
	
	vBatProg = ReadProSLICDirectRegister(74);
/*	vBatTarget = (vBatProg*15)/10;  //target in volts 
	vBatTarget = ((vBatTarget-6)*200)/75;*/
// SI321X_HV
	vBatTarget = (vBatProg*26)/10; //target in volts
	vBatTarget = ((vBatTarget-6)*156)/100;
	
	vBat=0;
	i=0;
	while ((vBat < vBatTarget) && (i < 2))
	{ 
		vBat = vBatTarget;		
		data = ReadProSLICDirectRegister( 82);
		if (data < vBatTarget)
		{
			vBat = data;
		}		
		if ((i > 2) && (vBat < vBatTarget))
		{
			DBG_r("SLIC:RC_VBAT_UP_TIMEOUT:ERROR\r\n");	
			return 1;			
		}
		slic_wait(100);	
		++i;		
	}
	
	/* Program desired PWM rate and start calibraton */
	
	WriteProSLICDirectRegister(92, INIT_SI3210M_DR92);
	WriteProSLICDirectRegister(93,INIT_SI3210M_DR93);
	slic_wait(30);
	WriteProSLICDirectRegister(93,0x80|INIT_SI3210M_DR93);
		
	do
	{
		data2 = 0;
		data = ReadProSLICDirectRegister( 93);
		data2 |= data;
		if (data&0x80)
		{
			if (i>10)
			{
				DBG_r("SLIC:RC_CAL_TIMEOUT\r\n");	
				return 1;
			}
		}			
		slic_wait(100);
		if (i>10)
			data2 = 0;
		++i;		
	}
	while(0x80&data2);  /* Wait for DC-DC Calibration to complete */
	
	return 0;
}

//----------------------------------

void slic_flushAccumulator()
{
	int i;

	for (i=88;i<212;i++)
	{
		WriteProSLICIndirectRegister (i,0);
	}
}

//----------------------------------
void slic_init(void)
{
	unsigned char temp, i;

	CODEC_m = 1;
	CODEC_p = 1;
	SSP1CON1 = 0;
	slic_power_on_reset();
	slic_wait(500);
	T_RESET	= 1;		//Start VOnalszim
	
//	mov#	D3210,05		//500msec wait

//SPI settings are CPE =1;CKE = 0; and operating in 8-bit mode.
	SSP1STAT = 0x0;
			
	SSP1CON1 = 0b00110010;

	temp = ReadProSLICDirectRegister(0);
	DBG_1form("SLIC_serial:0x%x\n\r",temp);

// AN35.pdf
// STEP 8:
	if (ReadProSLICDirectRegister(8) != 2) 	//Audio Path Loopback Control
		DBG_r("SLIC:not comm.reg 8:ERROR\r\n");
	if (ReadProSLICDirectRegister(11) != 0x33) 	//Audio Path Loopback Control
		DBG_r("SLIC:not comm.reg 11:ERROR\r\n");

//STEP 20: Flush Accumulators
	slic_flushAccumulator();

// STEP 9:
	if (slic_set_indirectreg_init())
	{
		Tx2_Debug_r("INIT ERROR, POWER DOWN\n\r");
		while(1);
	}
	DBG_r("SLIC:indirectReg. WR:OK\r\n");



// STEP 10:
	WriteProSLICDirectRegister (8, 0); 			// no loopback
	WriteProSLICDirectRegister (108, 0x0EB); 	// Enhancement Enable

	if (slic_powerUp())
	{
		Tx2_Debug_r("POWER UP ERROR, POWER DOWN\n\r");
		while(1);
	}
	DBG_r("SLIC:DC-DC OKE\r\n");



	WriteProSLICDirectRegister (64, 0);
		
	WriteProSLICDirectRegister (74, 45); // 45*1.5 V = 67.5V
//	temp = ReadProSLICDirectRegister (74);
//	DBG_1form("SLIC_V:0x%x\n\r",temp);

	
/*	WriteProSLICDirectRegister (92, 67); 		// DC-DC Converter PWM Period
	WriteProSLICDirectRegister (93, 16); 		// DC-DC Converter Switching Delay
	WriteProSLICDirectRegister (14, 0); 		// Power Down Control 1

	temp  = 0;
	while (temp < 80)
	{
		temp = ReadProSLICDirectRegister (82);		// Battery Voltage Sense 1
		slic_wait(20);
	}*/
//	DBG_r("SLIC:DC-DC OKE\r\n");

	// SLIC calibration :
	temp  = 0;
//STEP 12
	while (temp < 7)
	{
		slic_wait(10);
		WriteProSLICDirectRegister (93, 0b1001000); 	// Start CALIBRATION ,DC-DC Converter Switching Delay
		slic_wait(300);									//wait 300msec
		temp = ReadProSLICDirectRegister (93);
	}
//	DBG_1form("CAL1:0x%x\n\r",temp);
//	WriteProSLICDirectRegister (64, 0); 			 	// Linefeed Control
	WriteProSLICDirectRegister(21, 0);					/*Disable all interupts in DR21 */
	WriteProSLICDirectRegister(22, 0);				/*Disable all interupts in DR22 */
	WriteProSLICDirectRegister(23, 0);				/*Disabel all interupts in DR23 */
//STEP 13
	WriteProSLICDirectRegister(64, 0); 				/*OPEN_DR64 = 0 */
//STEP 14
	while (temp)
	{
		WriteProSLICDirectRegister (97, 0x1E); 			// Calibration Control/Status Register 2
		WriteProSLICDirectRegister (96, 0x47); 			// Calibration Control/Status Register 1
		slic_wait(800);	
		temp = ReadProSLICDirectRegister (96);			// Calibration Control/Status Register 1
	}
	
	slic_wait(10);
//STEP 16
	// Manual Calibration:
	WriteProSLICDirectRegister( 99, 0x10);				// Initialize TIP gain cal while RING being calibrated ,(gabore:0x1F),TIP Gain Mismatch Calibration Result
	for(i=0x1f; i>0; i--)
	{
		WriteProSLICDirectRegister( 98, i);
		slic_wait(40);
		temp = ReadProSLICDirectRegister (88);				//Transistor 5 Current Sense
		if (temp == 0)	
			break;
	}
	if (temp == 0)
	{
		DBG_r("SLIC:Manual Cal.OKE\r\n");
	}
	else
	{
		DBG_1form("SLIC:Manual Cal BAD:0x%x\n\r",i);
	}

	// TIP Gain Calibration :si321x_intf.c
	for(i=0x1f; i>0; i--)
	{
		WriteProSLICDirectRegister( 99, i);
		slic_wait(40);
		temp = ReadProSLICDirectRegister (89);				//Transistor 5 Current Sense
		if (temp == 0)	
			break;
	}
	if (temp == 0)
	{
		DBG_r("SLIC:TIP Gain Cal.OKE\r\n");
	}
	else
	{
		DBG_1form("SLIC:Manual Cal BAD:0x%x\n\r",i);
	}


 //  Long Balance Cal
	WriteProSLICDirectRegister(23, (1<<2)); //enable interrupt for the balance Cal.
	WriteProSLICDirectRegister(64, 1); 		//Linefeed Control:Forward active
	slic_wait(250);
	if (ReadProSLICDirectRegister (LOOP_STAT) & 1)
	{ /* offhook */ 
		DBG_r("SLIC:off-hook ERROR\r\n");
	}
	else
		DBG_r("SLIC:Cal.OKE\r\n");

	WriteProSLICDirectRegister(LINE_IMPEDANCE, 0x28);  //Two-Wire Impedance Synthesis Control
	WriteProSLICDirectRegister(PCM_MODE, 0x28);   ////PCM Mode Select:uLOW , PCM Transfer Size.:16-bit

	WriteProSLICDirectRegister(4, 1); //PCM Receive Start Count�Low Byte
	WriteProSLICDirectRegister(5, 0); //PCM Receive Start Count�High Byte

	//Sajat be�ll�t�s (halkabb legyen a GSM telefon, �s hangosab legyen a PSTN telefon)
	WriteProSLICDirectRegister(9, 0b00000110); //Audio Gain Control
	WriteProSLICDirectRegister(34, 0x18); //Ringing Oscillator Control
	WriteProSLICDirectRegister(48, 0x80); //Ringing Oscillator Active Timer�Low Byte
	WriteProSLICDirectRegister(49, 0x3E); //Ringing Oscillator Active Timer�High Byte
	WriteProSLICDirectRegister(51, 0x7D); //Ringing Oscillator Inactive Timer�High Byte
	WriteProSLICDirectRegister(69, 0x0C); //Loop Closure Debounce Interval
	WriteProSLICDirectRegister(97, 0x01); 
	WriteProSLICDirectRegister(24, 0x40); 
	WriteProSLICDirectRegister(96, 0x40); 

	WriteProSLICDirectRegister (65, INIT_DR65);
	WriteProSLICDirectRegister (71, INIT_DR71);

//	slic_print_reg(); // print regiszter

//STEP 21:
		temp = ReadProSLICDirectRegister(INTRPT_STATUS1);
		WriteProSLICDirectRegister (INTRPT_STATUS1, temp);
		temp = ReadProSLICDirectRegister(INTRPT_STATUS2);
		WriteProSLICDirectRegister (INTRPT_STATUS2, temp);
		temp = ReadProSLICDirectRegister(INTRPT_STATUS3);
		WriteProSLICDirectRegister (INTRPT_STATUS3, temp);

//STEP 27
		WriteProSLICIndirectRegister (35	,	INIT_IR35);
		WriteProSLICIndirectRegister (36	,	INIT_IR36);
		WriteProSLICIndirectRegister (37	,	INIT_IR37);
		WriteProSLICIndirectRegister (38	,	INIT_IR38);
		WriteProSLICIndirectRegister (39	,	INIT_IR39);

		WriteProSLICDirectRegister(INTRPT_MASK1,	0xFF);
		WriteProSLICDirectRegister (INTRPT_MASK2,	0xFF);
		WriteProSLICDirectRegister (INTRPT_MASK3,	0xFF);

		WriteProSLICDirectRegister(LINE_STATE,	ACTIVATE_LINE);

		DBG_r("SLIC:Init READY\r\n");	

CS3210 = 0;		
	//PIE1bits.SSPIE = 1;

//	slic_print_reg(); // print regiszter
	slic_RingSetup (0);
	Si321x_ToneGenSetup (4);
	slic_PCMSetup (0);
	slic_PCMTimeSlotSetup (0, 0);
//	slic_TXAudioGainSetup ( 0);
//	slic_RXAudioGainSetup ( 0);
   // slic_RingStart ();

//	hkdtmf = 0;

	timersDec[SLICtdindex] = 1000;
}

//----------------------------------
void ProSLICSPIDelay (void) 
{
    int SPI_delay = 10U;
    while (SPI_delay--);
}

//----------------------------------
void ProSLICWriteByte (BYTE b) 
{
    CS3210 = 0;		// selected
    WriteSPI1(b);
    CS3210 = 1;		// deselected
}

//----------------------------------
BYTE ProSLICReadByte (void) 
{
    BYTE ret;
    CS3210 = 0;		// selected
    ret = ReadSPI1();
    CS3210 = 1;		// deselected
    return ret;
}

//----------------------------------
void WriteProSLICDirectRegister (BYTE reg, BYTE val) {

    ProSLICWriteByte (reg);
    ProSLICSPIDelay ();
    ProSLICWriteByte (val);
}

//----------------------------------
BYTE ReadProSLICDirectRegister (BYTE reg) 
{
    ProSLICWriteByte (0x80 | reg);
    ProSLICSPIDelay ();
    return (ProSLICReadByte ());
}

//----------------------------------
int WaitForIndirectAccess (void) 
{
    int i;
    for (i = 0; i < 1000; i++) {
        if (ReadProSLICDirectRegister (31) == 0) // 0x01 if indir I/O is pending
	    return 0;
    }
    return 1;
}

//----------------------------------
WORD ReadProSLICIndirectRegister (BYTE reg) 
{
    WORD ret = 0;

    if (WaitForIndirectAccess ()) {
        return 0xDead;
    }
    WriteProSLICDirectRegister (30, reg);
    if (WaitForIndirectAccess ()) {
        return 0xBeef;
    }
    ret = ReadProSLICDirectRegister (29);
    ret <<= 8;
    ret |= ReadProSLICDirectRegister (28);
    return ret;
}

//----------------------------------
int WriteProSLICIndirectRegister (BYTE reg, WORD val) 
{
    if (WaitForIndirectAccess ()) 
	{		
        return 1;
    }
    WriteProSLICDirectRegister (28, (BYTE) (val & 0xff));
    WriteProSLICDirectRegister (29, (BYTE) ((val & 0xff00) >> 8));
    WriteProSLICDirectRegister (30, reg);
	return 0;
}

//----------------------------------
void slic_print_reg()
{
	BYTE  d_reg;
	WORD  int_reg;
	int ii;

	DBG_r("SLIC Direct Reg.\r\n");

 	for (ii=0;ii<109;ii++)
	{
		d_reg = ReadProSLICDirectRegister (ii);
		DBG_1form("D%d:",ii);
		DBG_1form("0x%x\r\n",d_reg);
		slic_wait(5);
	}
	DBG_r("SLIC Indirect Reg.\r\n");
	for (ii=0;ii<44;ii++)
	{
		int_reg = ReadProSLICIndirectRegister (ii);
		DBG_1form("I%d:",ii);
		DBG_1form("0x%x\r\n",int_reg);
		slic_wait(5);
	}
	for (ii=99;ii<105;ii++)
	{
		int_reg = ReadProSLICIndirectRegister (ii);
		DBG_1form("I%d:",ii);
		DBG_1form("0x%x\r\n",int_reg);
		slic_wait(5);
	}
}
//----------------------------------
/*
** Function: PROSLIC_ToneGenSetup
**
** Description: 
** configure tone generators
*/
void Si321x_ToneGenSetup (int preset)
{
	Si321x_Tone_Cfg *pTone;

	pTone = Si321x_Tone_Presets;


	WriteProSLICIndirectRegister(OSC1X,pTone[preset].osc1.amp);
	WriteProSLICIndirectRegister(OSC1Y,pTone[preset].osc1.phas);
	WriteProSLICIndirectRegister(OSC1_COEF,pTone[preset].osc1.freq);
	
	WriteProSLICDirectRegister(OSC1_ON_HI,(pTone[preset].osc1.tahi));
	WriteProSLICDirectRegister(OSC1_ON__LO,(pTone[preset].osc1.talo));
	WriteProSLICDirectRegister(OSC1_OFF_HI,(pTone[preset].osc1.tihi));
	WriteProSLICDirectRegister(OSC1_OFF_LO,(pTone[preset].osc1.tilo));
	
	WriteProSLICIndirectRegister(OSC2X,pTone[preset].osc2.amp);
	WriteProSLICIndirectRegister(OSC2Y,pTone[preset].osc2.phas);
	WriteProSLICIndirectRegister(OSC2_COEF,pTone[preset].osc2.freq);
	
	WriteProSLICDirectRegister(OSC2_ON_HI,(pTone[preset].osc2.tahi));
	WriteProSLICDirectRegister(OSC2_ON__LO,(pTone[preset].osc2.talo));
	WriteProSLICDirectRegister(OSC2_OFF_HI,(pTone[preset].osc2.tihi));
	WriteProSLICDirectRegister(OSC2_OFF_LO,(pTone[preset].osc2.tilo));
	
	WriteProSLICDirectRegister(OSC1,(pTone[preset].omode1));
	WriteProSLICDirectRegister(OSC2,(pTone[preset].omode2));
}

//----------------------------------
/*
** Function: PROSLIC_StopTone
**
** Description: 
** Stops tone generators
**
** Input Parameters: 
** pProslic: pointer to Proslic object
**
** Return:
** none
*/
void slic_ToneGenStop ()
{
	uint8 data;

	data = ReadProSLICDirectRegister(OSC1);
	data &= ~(0x1C);
	WriteProSLICDirectRegister(OSC1,data);

	data = ReadProSLICDirectRegister(OSC2);
	data &= ~(0x1C);
	WriteProSLICDirectRegister(OSC2,data);
}

//----------------------------------
/*
** Function: PROSLIC_StartGenericTone
**
** Description: 
** start tone generators
*/
void slic_ToneGenStart (uint8 timerEn)
{
	uint8 data;
	slic_ToneGenStop();
	
	data = ReadProSLICDirectRegister(OSC1);
	data |= 0x4 + (timerEn ? 0x18 : 0);
	WriteProSLICDirectRegister(OSC1,data);

	data = ReadProSLICDirectRegister(OSC2);
	data |= 0x4 + (timerEn ? 0x18 : 0);
	WriteProSLICDirectRegister(OSC2,data);	
}

//---------------------------------------------
/*
** Function: PROSLIC_StartRing
**
** Description: 
** start ring generator
*/
void slic_RingStart ()
{
	WriteProSLICDirectRegister(LINE_STATE,LF_RINGING);
}

//-----------------------------------------------
/*
** Function: PROSLIC_StopRing
**
** Description: 
** Stops ring generator
*/
void slic_RingStop ()
{
	WriteProSLICDirectRegister(LINE_STATE,LF_FWD_ACTIVE);
}

/*
** Function: PROSLIC_PulseMeterStart
**
** Description: 
** start pulse meter tone
*/
void slic_PulseMeterStart ()
{
	WriteProSLICDirectRegister(PULSE_OSC,0xff); /* enable timers and oscillator */	
}

/*
** Function: PROSLIC_PulseMeterStop
**
** Description: 
** stop pulse meter tone
*/
void slic_PulseMeterStop ()
{	
	WriteProSLICDirectRegister(PULSE_OSC,0); /* diasbles timers and oscillator */
}

/*
** Function: PROSLIC_ReadDTMFDigit
**
** Description: 
** Read DTMF digit (would be called after DTMF interrupt to collect digit)
*/
void slic_DTMFReadDigit (uint8 *pDigit)
{
	*pDigit = ReadProSLICDirectRegister(DTMF_DIGIT);
	*pDigit = *pDigit & 0xf;
}

/*
** Function: PROSLIC_PCMSetup
**
** Description: 
** configure pcm
*/


void slic_PCMSetup ( int preset)
{
	uint8 data=0;		
	data |= Si321x_Pcm_Presets [preset].pcmf<<2;
	data |= Si321x_Pcm_Presets [preset].wbe<<6;
	data |= Si321x_Pcm_Presets [preset].tri;
//	WriteProSLICDirectRegister(PCM_MODE, data);
	WriteProSLICDirectRegister(PCM_MODE, 0x28);
}

//----------------------------------
void slic_PCMTimeSlotSetup ( uint16 rxcount, uint16 txcount)
{
/*	WriteProSLICDirectRegister(PCM_XMIT_START_COUNT_LSB,txcount & 0xff);
	WriteProSLICDirectRegister(PCM_XMIT_START_COUNT_MSB,txcount >> 8);

	WriteProSLICDirectRegister(PCM_RCV_START_COUNT_LSB,rxcount & 0xff);
	WriteProSLICDirectRegister(PCM_RCV_START_COUNT_MSB,rxcount >> 8);*/

	WriteProSLICDirectRegister(PCM_XMIT_START_COUNT_LSB,1);
	WriteProSLICDirectRegister(PCM_XMIT_START_COUNT_MSB,0);
	WriteProSLICDirectRegister(PCM_RCV_START_COUNT_LSB,1);
	WriteProSLICDirectRegister(PCM_RCV_START_COUNT_MSB,0);
}

/*
** Function: PROSLIC_AudioGainSetup
**
** Description: 
** configure audio gains
*/

// Si321x_audioGain_Cfg Si321x_AudioGain_Presets [];
void slic_TXAudioGainSetup ( int preset)
{
	uint8 data;
	data = ReadProSLICDirectRegister( AUDIO_GAIN);
	data &= ~(0xC);
	WriteProSLICDirectRegister( AUDIO_GAIN, data|(Si321x_AudioGain_Presets[preset].gain<<2));
	WriteProSLICIndirectRegister( XMIT_DIGITAL_GAIN, Si321x_AudioGain_Presets[preset].digGain);	
}

/*
** Function: PROSLIC_AudioGainSetup
**
** Description: 
** configure audio gains
*/
void slic_RXAudioGainSetup ( int preset)
{
	uint8 data;
	data = ReadProSLICDirectRegister( AUDIO_GAIN);
	data &= ~(0x3);
	WriteProSLICDirectRegister( AUDIO_GAIN, data|Si321x_AudioGain_Presets[preset].gain); /* AUDIO_GAIN == 9 */
	WriteProSLICIndirectRegister( RECV_DIGITAL_GAIN, Si321x_AudioGain_Presets[preset].digGain);
}

/*
** Function: PROSLIC_FSKSetup
**
** Description: 
** configure fsk
*/

//extern Si321x_FSK_Cfg Si321x_FSK_Presets [];
void slic_FSKSetup ( int preset)
{
	WriteProSLICIndirectRegister( FSK_X_0, Si321x_FSK_Presets[preset].fsk0); /*fsk frequency 0 location */
	WriteProSLICIndirectRegister(FSK_COEFF_0, Si321x_FSK_Presets[preset].fsk0x); /* fsk amplitude 0 location */

	WriteProSLICIndirectRegister(FSK_X_1, Si321x_FSK_Presets[preset].fsk1); /* fsk frequency 0 location */
	WriteProSLICIndirectRegister( FSK_COEFF_1, Si321x_FSK_Presets[preset].fsk1x); /* fsk amplitude 1 location */

	WriteProSLICIndirectRegister(FSK_X_01,Si321x_FSK_Presets[preset].fsk01);
	WriteProSLICIndirectRegister( FSK_X_10, Si321x_FSK_Presets[preset].fsk10);

	WriteProSLICDirectRegister( OSC1_ON__LO, 19);

	WriteProSLICDirectRegister( OSC1_ON_HI, 0);
}

//----------------------------------
void slic_executor(void)
{
	BYTE  int_res;
//	char  buff[3];
//	static int  ii = 0;

 	if (!T_INT) 
	{ //INT
	//	DBG_r("I1\r\n");
        // interrupts (should) occur only on hook state changes or DTMF detect
 		int_res = ReadProSLICDirectRegister (INTRPT_STATUS3);
		if (int_res)
		{ // 20
 			WriteProSLICDirectRegister (INTRPT_STATUS3, int_res);      // clears interrupt
 			if (int_res & 0x01) 
			{	// DTMF event
	        	int_res = ReadProSLICDirectRegister (DTMF_DIGIT);	// get DTMF state,24
				if (int_res & 0x10)
				{				
					hkdtmf[0] = (int_res & 0x0f) + 0x30;		// mask into hkdtmf
					hkdtmf[1] = 0;
					DBG_1form("DTMF:%s\r\n",hkdtmf);
				}
	    	}
		//	DBG_r("I20\r\n");
		}
		int_res = ReadProSLICDirectRegister (INTRPT_STATUS1);
		if (int_res)
		{ // 18
 			WriteProSLICDirectRegister (INTRPT_STATUS1, int_res);      // clears interrupt
	//		DBG_1form("int_D18:0x%x\n\r",int_res);
		}
        int_res = ReadProSLICDirectRegister (INTRPT_STATUS2);
		if (int_res)
		{ // 19
 			WriteProSLICDirectRegister (INTRPT_STATUS2, int_res);      // clears interrupt
			DBG_1form("int_D19:0x%x\n\r",int_res);
			int_res = ReadProSLICDirectRegister (LOOP_STAT); //68

                               					// phone is off-hook
				if (int_res & 0x04) 
				{		/*ONHOOK: put down the phone*/  
		    	//	hkdtmf |= 0x80;			// set or clear bit 7
				//	slic_ToneGenStart (1);
					slic_ToneGenStop ();   
					DBG_r("ONHOOK\r\n");
				}
				else 
				{ /* OFFHOOK: the phone is being taken up */  
		    	//	hkdtmf &= 0x7F;	
					Si321x_ToneGenSetup (4);
					slic_ToneGenStart (0);
 					DBG_r("OFFHOOK\r\n");
					//slic_ToneGenStop ();
				   		
				}
             //   DBG_r("I3\r\n");                   // set or clear bit 7				           
		
		}
	}
}

