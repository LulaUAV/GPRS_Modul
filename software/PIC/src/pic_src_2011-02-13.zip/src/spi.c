#include <p18cxxx.h>
#include <spi.h>

/********************************************************************
*     Function Name:    getsSPI1                                    *
*     Return Value:     void                                        *
*     Parameters:       address of read string storage location and *
*                       length of string bytes to read              *
*     Description:      This routine reads a string from the SPI1   *
*                       bus.  The number of bytes to read is deter- *
*                       mined by parameter 'length'.                *
********************************************************************/
void getsSPI1( unsigned char *rdptr, unsigned char length )
{
  while ( length )                // stay in loop until length = 0
  {
    *rdptr++ = getcSPI1();        // read a single byte
    length--;                     // reduce string length count by 1
  }
}

/*********************************************************************
*     Function Name:    putsSPI1                                     *
*     Return Value:     void                                         *
*     Parameters:       address of write string storage location     *
*     Description:      This routine writes a string to the SPI1 bus.*  
*********************************************************************/
void putsSPI1( unsigned char *wrptr )
{
  while ( *wrptr )                 // test for string null character
  {
     SSP1BUF = *wrptr++;           // initiate SPI1 bus cycle
     while( !SSP1STATbits.BF );    // wait until 'BF' bit is set
  }
}


/********************************************************************
*     Function Name:    ReadSPI1                                    *
*     Return Value:     contents of SSP1BUF register                *
*     Parameters:       void                                        *
*     Description:      Read single byte from SPI1 bus.             *
********************************************************************/
unsigned char ReadSPI1( void )
{
  unsigned char TempVar;
  TempVar = SSP1BUF;       //Clear BF
  PIR1bits.SSP1IF = 0;     //Clear interrupt flag
  SSP1BUF = 0x00;          // initiate bus cycle
  //while ( !SSP1STATbits.BF );                // wait until cycle complete
  while(!PIR1bits.SSP1IF); //wait until cycle complete
  return ( SSP1BUF );      // return with byte read 
}

/********************************************************************
*     Function Name:    WriteSPI1                                   *
*     Return Value:     Status byte for WCOL detection.             *
*     Parameters:       Single data byte for SPI1 bus.              *
*     Description:      This routine writes a single byte to the    * 
*                       SPI1 bus.                                   *
********************************************************************/
unsigned char WriteSPI1( unsigned char data_out )
{
  unsigned char TempVar;  
  TempVar = SSP1BUF;           // Clears BF
  PIR1bits.SSP1IF = 0;         // Clear interrupt flag
  SSP1CON1bits.WCOL = 0;			//Clear any previous write collision
  SSP1BUF = data_out;          // write byte to SSP1BUF register
  if ( SSP1CON1 & 0x80 )       // test if write collision occurred
   return ( -1 );              // if WCOL bit is set return negative #
  else
   //while( !SSP1STATbits.BF ); // wait until bus cycle complete 
   while(!PIR1bits.SSP1IF); // wait until bus cycle complete
  return ( 0 );                // if WCOL bit is not set return non-negative#
}


/********************************************************************
*     Function Name:    getsSPI2                                    *
*     Return Value:     void                                        *
*     Parameters:       address of read string storage location and *
*                       length of string bytes to read              *
*     Description:      This routine reads a string from the SPI2   *
*                       bus.  The number of bytes to read is deter- *
*                       mined by parameter 'length'.                *
********************************************************************/	
void getsSPI2( unsigned char *rdptr, unsigned char length )
{
  while ( length )                // stay in loop until length = 0
  {
    *rdptr++ = getcSPI2();        // read a single byte
    length--;                     // reduce string length count by 1
  }
}

/*********************************************************************
*     Function Name:    putsSPI2                                     *
*     Return Value:     void                                         *
*     Parameters:       address of write string storage location     *
*     Description:      This routine writes a string to the SPI2 bus.*  
*********************************************************************/
void putsSPI2( unsigned char *wrptr )
{
  while ( *wrptr )                 // test for string null character
  {
     SSP2BUF = *wrptr++;           // initiate SPI2 bus cycle
     while( !SSP2STATbits.BF );    // wait until 'BF' bit is set
  }
}

/********************************************************************
*     Function Name:    ReadSPI2                                    *
*     Return Value:     contents of SSP2BUF register                *
*     Parameters:       void                                        *
*     Description:      Read single byte from SPI2 bus.             *
********************************************************************/
unsigned char ReadSPI2( void )
{
  unsigned char TempVar;
  TempVar = SSP2BUF;       //Clear BF
  PIR3bits.SSP2IF = 0;     //Clear interrupt flag
  SSP2BUF = 0x00;          // initiate bus cycle
  //while ( !SSP2STATbits.BF );                // wait until cycle complete
  while(!PIR3bits.SSP2IF); //wait until cycle complete
  return ( SSP2BUF );      // return with byte read 
}

/********************************************************************
*     Function Name:    WriteSPI2                                   *
*     Return Value:     Status byte for WCOL detection.             *
*     Parameters:       Single data byte for SPI2 bus.              *
*     Description:      This routine writes a single byte to the    * 
*                       SPI2 bus.                                   *
********************************************************************/
unsigned char WriteSPI2( unsigned char data_out )
{
  unsigned char TempVar;  
  
  TempVar = SSP2BUF;           // Clears BF
  PIR3bits.SSP2IF = 0;         // Clear interrupt flag
  SSP2CON1bits.WCOL = 0;			//Clear any previous write collision
  SSP2BUF = data_out;          // write byte to SSP2BUF register
  if ( SSP2CON1 & 0x80 )       // test if write collision occurred
   return ( -1 );              // if WCOL bit is set return negative #
  else
   // while( !SSP2STATbits.BF ); // wait until bus cycle complete 
   while(!PIR3bits.SSP2IF); //wait until bus cycle complete
  return ( 0 );                // if WCOL bit is not set return non-negative#
}


