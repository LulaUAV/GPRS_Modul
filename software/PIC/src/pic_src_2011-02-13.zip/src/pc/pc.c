//**********************************
//	Tiszai Istvan,  2011.03
// PC TX2-RX2
//**********************************
#include <p18cxxx.h>
#include <p18f6527.h>
#include "defines.h"
#include "pc.h"
#include "utils.h"
#include "../gsm-gprs/gsm-gprs.h"
#include "../slic/slic.h"
#include "eeprom.h"


uint8 usart2char;
int  Rx2Length;
int prev_Rx2Length;
int  Tx2Length;
char debug_flag;


ERROR_CODE rx2_errcode;
volatile char  Rx2_Buffer[RX2_MAX_DATA_NUM+1];
//volatile char* Rx2_BufferPtr;

//int rx2_time_out;
volatile char rx2test;
volatile char  RxTx2State;

char* Rx2_BufferPtr;
char*  Tx2_BufferPtr;


char  Tx2_Buffer[TX2_MAX_DATA_LEN];

char  string[16];

static int ii;

void Rx2_clear(void);
void Tx2_is_ready (void);
void send_to_pc(char cmd0, char cmd1, char* data,unsigned char len);

//----------------------------------
void pc_init(uint16 usart_baud)
{
	char data;
	TXSTA2 = 0;           // Reset USART registers to POR state
  	RCSTA2 = 0;
	BAUDCON2 	= 0; 
 	BAUDCON2bits.BRG16 = 1;
 //	RCSTA2bits.CREN = 1;
  //	TXSTA2bits.BRGH = 1;
  
	RCSTA2		= 0b10010110; //soros port en., vetel eng.
	TXSTA2		= 0b00100110; //8bit, adas eng. aszink.mod
	SPBRG2 = usart_baud;       // Write baudrate to SPBRG1
  	SPBRGH2 = usart_baud >> 8; // For 16-bit baud rate generation
//	SPBRG1 = 255;				//brt oszto	BRT 9600 40000000/16/(259+1)
//	SPBRGH1 = 4;
//	SPBRG2  = 129;				//brt oszto	BRT 19200 40000000/16/(129+1)
//	SPBRGH2 = 0;
//	SPBRG1  =42;				//brt oszto	BRT 57600 40000000/16/(259+1)
//	SPBRGH1 = 0;
	IPR3bits.RC2IP=1;		//veteli priority high.
	IPR3bits.TX2IP=1;		//adas priority high.
	PIE3bits.RC2IE=1;		//veteli IT eng.

	TX2_ON
	ii = RCREG2;

//	rx2_time_out = 0;
	rx2_errcode = 0;
 	
	Rx2_clear();
	for (ii = 0; ii<RX2_MAX_DATA_NUM; ii++)
		Rx2_Buffer[ii] = 0;
	timersDec[DEBUGtdindex] = 1000; 
	debug_flag = 1;
	DBG_r("PC-USART2 init READY!\r\n");
}


/**********************************************************
 * rx2 torles fg.
 **********************************************************/
void Rx2_clear(void)
{
	prev_Rx2Length = 	Rx2Length;
	Rx2Length = 0;
	Rx2_BufferPtr = Rx2_Buffer;
	PIR3bits.RC2IF = 0;
//	to_count = rxtest;
	rx2test = 0;
}

//-------------------------------------------------------------
int check_rec_chs()
{
	return 0;
}

//-------------------------------------------------------------
// vetel kezelese 
static int Rx2_handler(void)
{
	int ii;
	unsigned char temp;
	if (Rx2_Buffer[0] == 'M')
	{ //SIM
		if (Rx2_Buffer[1] == ':')
		{ //AT parancs resz, DEBUG
			for (ii=0;Rx2_Buffer[ii+2];ii++)
			{
				Tx1_Buffer[ii] = Rx2_Buffer[ii+2];
			}
			Tx1_Buffer[ii] = 0;
			SendUART2();
			if (Rx2_Buffer[ii+3] == 0x1a)
			{
				TXREG = 26;	//<CTRL-Z>
				while(BusyUSART());
			}
	//		if (wait_OK(5000))
			{
				flush_buffer();	
				if (wait_respond(5000) == 0)
				{
					DBG_r("SIM--FAILER!\r\n");
					return 1;
				}
				Rx1_Buffer[rx_counter] = 0;
				DBG_m(Rx1_Buffer);
			}
			return;	
		}
		else
		if (Rx2_Buffer[1] == 'S')
		{ //SMS
			next_dtmf_index();
			alarms.dtmf[alarms.wr_index][0] = SMS_ALRM;
			alarms.dtmf[alarms.wr_index][6] = Rx2_Buffer[2];
			alarms.dtmf[alarms.wr_index][7] = Rx2_Buffer[3];
			alarms.dtmf[alarms.wr_index][8] = Rx2_Buffer[4];
			alarms.dtmf[alarms.wr_index][9] = Rx2_Buffer[5];
		}
		else
		if (Rx2_Buffer[1] == 1)
		{ //ALARM
			send_alarm_to_gprs(Rx2_Buffer[2], &Rx2_Buffer[4], Rx2_Buffer[3]);
		}
		else
		if (Rx2_Buffer[1] == 2)
		{ //CID
			send_CID_to_gprs(&Rx2_Buffer[2]);
		}
		else
		if (Rx2_Buffer[1] == 3)
		{ //INIT
			send_INIT_to_gprs(&Rx2_Buffer[2]);
		}
		else
		if (Rx2_Buffer[1] == 4)
		{//ALIVE
			send_alive_to_gprs();
		}
	}
	else
	if (Rx2_Buffer[0] == 'S')
	{//Slic
		if (Rx2_Buffer[1] == 'K')
		{
			alarms.tone_flg = 10;
			slic_kissoff();
		}
		else
		if (Rx2_Buffer[1] == 'H')
		{
			alarms.tone_flg = 1;
			alarms.state = 2;
			slic_handshake();
		}
		else
		if (Rx2_Buffer[1] == 0)
		{
			WriteProSLICDirectRegister(Rx2_Buffer[2], Rx2_Buffer[3]);
			DBG_1form("SLIC:DW:%d, %d\n\r",(int)Rx2_Buffer[2], (int)Rx2_Buffer[3]);
		}
		else
		if (Rx2_Buffer[1] == 1)
		{
			temp = ReadProSLICDirectRegister (Rx2_Buffer[2]);
			DBG_1form("SLIC:DR:%d, %d\n\r",(int)Rx2_Buffer[2],(int)temp);
		}
		else
		if (Rx2_Buffer[1] == 2)
		{
			ii = 0;
			ii =  (int)Rx2_Buffer[3];
			ii +=  ((int)Rx2_Buffer[4])*256;
			
			WriteProSLICIndirectRegister(Rx2_Buffer[2], ii);
			DBG_1form("SLIC:IDW:%d, %d\n\r",(int)Rx2_Buffer[2], ii);
		}
		else
		if (Rx2_Buffer[1] == 3)
		{
			ii =ReadProSLICIndirectRegister(Rx2_Buffer[2]);
			DBG_1form("SLIC:IDR:%d, %d\n\r",(int)Rx2_Buffer[2],ii);
		}
	}
	else
	if (Rx2_Buffer[0] == 'T')
	{ // system
		if (Rx2_Buffer[1] == 'H')
		{ //halt
			while(1);
		}
		else
		if (Rx2_Buffer[1] == 'R')
		{ //reset
			RESET
		_asm
    		goto 0x0 
  		_endasm
			while(1);
		}
		else
		if (Rx2_Buffer[1] == 'D')
		{ //debug
			debug_flag = Rx2_Buffer[2];
		}
		else
		if (Rx2_Buffer[1] == 'A')
		{ //alive
			send_to_pc('T','A', 0,0);
		}
	}
	else
	if (Rx2_Buffer[0] == 'E')
	{ // EEProm r�sz
		if (Rx2_Buffer[1] == 'S')
		{ //set
			if (Rx2_Buffer[2] == 'D')
			{ //szerver IP vagy domain
				if (check_rec_chs() == 0)
				{
					if (Rx2_Buffer[3] <= 24)
					{
						if (EEP_write((unsigned int)EEADDR_SZERVIP, Rx2_Buffer[3], &Rx2_Buffer[4], 1))
						{
							string[0] = '1';
							string[1] = 0;
							send_to_pc('!','D', string,3);
						}
					}
			/*		else
					{
						string[0] = '2';
						string[1] = 0;
						send_to_pc('!','D', string,3);
					}			
				}
				else
				{				
					string[0] = '3';
					string[1] = 0;
					send_to_pc('!','D', string,3);*/
				}
			}
			else
			if (Rx2_Buffer[2] == 'A')
			{ //APN
				if (check_rec_chs() == 0)
				{
					if (Rx2_Buffer[3] <= 24)
					{
						if (EEP_write((unsigned int)EEADDR_APN, Rx2_Buffer[3], &Rx2_Buffer[4], 1))
						{
							string[0] = '1';
							string[1] = 0;
							send_to_pc('!','A', string,3);				
						}
					}
				}
			}
			else
			if (Rx2_Buffer[2] == 'p')
			{ //DSN pri
				if (check_rec_chs() == 0)
				{
					if (Rx2_Buffer[3] <= GPRS_DNS_IP_LEN)
					{
						if (EEP_write((unsigned int)EEADDR_DNS_PRI, GPRS_DNS_IP_LEN, &Rx2_Buffer[4], 1))
						{
							string[0] = '1';
							string[1] = 0;
							send_to_pc('!','p', string,3);				
						}
					}
				}
			}
			else
			if (Rx2_Buffer[2] == 's')
			{ //DSN sec
				if (check_rec_chs() == 0)
				{
					if (Rx2_Buffer[3] <= GPRS_DNS_IP_LEN)
					{
						if (EEP_write((unsigned int)EEADDR_DNS_SEC, GPRS_DNS_IP_LEN, &Rx2_Buffer[4], 1))
						{
							string[0] = '1';
							string[1] = 0;
							send_to_pc('!','s', string,3);				
						}
					}
				}
			}
			else
			if (Rx2_Buffer[2] == 'f')
			{ //DSN factory		
				myStrcpy_r ( dmsg, GPRS_DNS_PRI_IP ); 
				EEP_write((unsigned int)EEADDR_DNS_PRI, GPRS_DNS_IP_LEN, dmsg,1);
				myStrcpy_r ( dmsg, GPRS_DNS_SEC_IP ); 
				EEP_write((unsigned int)EEADDR_DNS_SEC, GPRS_DNS_IP_LEN, dmsg, 1);
			}
		}
		else
		if (Rx2_Buffer[1] == 'G')
		{ //get
			if (Rx2_Buffer[2] == 'D')
			{ //szerver IP vagy domain
				if (EEP_read_null_end(EEADDR_SZERVIP, dmsg, 0) == 0)
				{
					send_to_pc('E','D',dmsg,24);
				}
				else
				{
					string[0] = '4';
					string[1] = 0;
					send_to_pc('!','D', string,3);	
				}
			}
			else
			if (Rx2_Buffer[2] == 'A')
			{ //szerver IP vagy domain
			//	if (EEP_read(EEADDR_APN, 17, dmsg, 1) == 0)
				if (EEP_read_null_end(EEADDR_APN, dmsg, 0) == 0)
				{
					send_to_pc('E','A',dmsg,24);
				}
				else
				{
					string[0] = '4';
					string[1] = 0;
					send_to_pc('!','A', string,3);	
				}
			}
			else
			if (Rx2_Buffer[2] == 'p')
			{ //DNS,pri
				if (EEP_read_null_end(EEADDR_DNS_PRI, dmsg, 0) == 0)
				{
					if ((dmsg[0] >= '0') && (dmsg[0] <= '9'))
						send_to_pc('E','p',dmsg, GPRS_DNS_IP_LEN);
					else
					{
						myStrcpy_r ( dmsg, GPRS_DNS_PRI_IP ); 
						send_to_pc('E','p',dmsg, GPRS_DNS_IP_LEN);	
					}
				}
				else
				{
					string[0] = '4';
					string[1] = 0;
					send_to_pc('!','p', string,3);	
				}
			}
			else
			if (Rx2_Buffer[2] == 's')
			{ //DNS,sec
				if (EEP_read_null_end(EEADDR_DNS_SEC, dmsg, 0) == 0)
				{
					if ((dmsg[0] >= '0') && (dmsg[0] <= '9'))
						send_to_pc('E','s',dmsg,GPRS_DNS_IP_LEN);
					else
					{
						myStrcpy_r ( dmsg, GPRS_DNS_SEC_IP ); 
						send_to_pc('E','s',dmsg, GPRS_DNS_IP_LEN);
					}	
				}
				else
				{
					string[0] = '4';
					string[1] = 0;
					send_to_pc('!','s', string,3);	
				}
			}
		}
	}

	return 0;
}

//-------------------------------------------------------------
// A bejovo uzenet ellenorzese (kezdo karakter, lezaro karakter, 
// hossz, checksum)
char Rx2CheckMsg(int size)
{

	return NOERR_SUCCESS;
	
/*	if(Rx_Buffer[0] != BegCH)
		return ERR_BEGCH;
		
	if(Rx_Buffer[size-1] != EndCH)
		return ERR_ENDCH;

	if(Rx_Buffer[1] != (size - 2))
		return ERR_LEN;

	if(CheckSerialCoCheckSum(size))
		return ERR_CHS;

	return NOERR_SUCCESS;*/
}


/**********************************************************
 *  rx_tx  fg.
 **********************************************************/
void Rx2_Tx2(void)
{
	char data;
	if (CHK_SER2_STATUS(RX_READY))
	{
		RX2_OFF;
		CLR_SER2_STATUS(RX_READY)
		rx2_errcode=Rx2CheckMsg(Rx2Length);
		if(rx2_errcode)
		{
			//SerialAT91_sendError(errcode);
error1:
			SET_SER2_STATUS(RX_ERROR)
		//	Rx2_timeout(1, RX_ERROR_TIMEOUT);
			timersDec[RX2tdindex] = RX_ERROR_TIMEOUT;
			
			Rx2_clear();
			return;
		}
		rx2_errcode = Rx2_handler();
		Rx2_clear();
/*		if (rx2_errcode == NOERR_SUCCESS)
			Tx2_SendAnswer(rx2_errcode);
		else
		if (rx2_errcode < NOERR_NOSETTING)
			goto error1;*/		
		RX2_ON		
		return;
	}
	if (CHK_SER2_STATUS(RX_ERROR))
	{
		RX2_OFF
	//	if (Rx2_timeout(0, 0))
		if (timersDec[RX2tdindex] == 0)
		{
		
			data = RCREG2;
			CLR_SER2_STATUS(RX_ERROR)
			CLR_SER2_STATUS(RX_INT)
			Rx2_clear();	
		//	Tx2_sendError(rx2_errcode);
			rx2_errcode = NOERR_SUCCESS;
		}		
		return;	
	}
	if (CHK_SER2_STATUS(RX_INT))
	{
		//if (Rx2_timeout(0, 0) == 1)
		if (timersDec[RX2tdindex] == 0)
		{
			RX2_OFF
			CLR_SER2_STATUS(RX_INT)
			SET_SER2_STATUS(RX_READY)
		}
	}
}


/**********************************************************
 * adas resz.
 **********************************************************/
//---------------------------------------------------------------
void Tx2_is_ready (void)
{
	unsigned char ki_lep;
	ki_lep=1;
	while(ki_lep)			
	{
	_asm clrwdt _endasm
	 if((PIR3bits.TX2IF) && 1) ki_lep=0;
	}	
	PIR3bits.TX2IF = 0;	
}		

//---------------------------------------------------------------
 void Tx2_send(void)
{
	if (Tx2Length)
	{
		Tx2_BufferPtr = Tx2_Buffer;
		TX2_ON
		while (!TXSTA2bits.TRMT);
	}
/*	int res;
//INTCONbits.GIEH = 0;
	if (Tx2Length)
	{	
		for (res = 0; res < 100; res++)
		{ res = res;}
	//	Tmsec(5);
		Tx2_BufferPtr = Tx2_Buffer;

		RX2_OFF
		while (Tx2Length)
		{
			Tx2_is_ready();
			TXREG2 = *Tx2_BufferPtr++;
			Tx2Length--;
		}
		Tx2_is_ready();
		for (res = 0; res < 100; res++)
		{ res = res;}
	//	Tmsec(5);
		RX2_ON
	}
//	INTCONbits.GIEH = 1;*/
}//void tx_send(void)

/*------------------------------------------------------------------*/
void send_to_pc(char cmd0, char cmd1, char* data,unsigned char len)
{
	unsigned char chk = 0;
	unsigned char ii;

	if (len > TX2_MAX_DATA_LEN-5)
		return ;
	if (cmd0 == '!')
		Tx2_Buffer[0] = '!';
	else	
		Tx2_Buffer[0] = ':';
	chk = Tx2_Buffer[0];
	Tx2_Buffer[1] = cmd0;
	chk += Tx2_Buffer[1];
	Tx2_Buffer[2] = cmd1;
	chk += Tx2_Buffer[2];
	Tx2_Buffer[3] = len;
	chk += Tx2_Buffer[3];
	
	if (len || data)
	{
		for (ii=0; ii<len; ii++)
		{
			Tx2_Buffer[4+ii] = data[ii];
			chk += Tx2_Buffer[4+ii];
		}
	}

	Tx2_Buffer[len + 4]  =  chk;
	Tx2Length = len + 5;
	Tx2_send();
}

//------------------------------------------------------
// Hibauzenet kikuldese a masternek
/*
void Tx2_sendError(char errcode)
{
	int i;
	char data[1];
	if (CHK_SER2_STATUS(TX_INT))
		return;
	send_to_pc(SER2_CMD_ERROR,errcode,0,0);
}	*/


//------------------------------------------------------
// Debug Rom
void Tx2_Debug_r(const rom char* msg_a)
{
	if (debug_flag == 0)
		return;
	
	Tx2Length = myStrlen_rom(msg_a);
	if (Tx2Length)
	{
		for (ii=0;ii<Tx2Length;ii++)
		{
			Tx2_Buffer[ii]  =   msg_a[ii];
		}
		Tx2_send();
	}	
}

//------------------------------------------------------
// Debug Ram
void Tx2_Debug(const char* msg_a)
{
	if (debug_flag == 0)
		return;
	Tx2Length = myStrlen_ram(msg_a);
	if (Tx2Length)
	{
		for (ii=0;ii<Tx2Length;ii++)
		{
			Tx2_Buffer[ii]  =   msg_a[ii];
		}
		Tx2_Buffer[ii]  =  0;
		Tx2_send();
	}	
}



//------------------------------------------------------
// Valasz 
/*
void Tx2_SendAnswer(char data)
{
	send_to_pc(SER2_CMD_DEFAULT,data,0,0);
}*/

/*********************************************************************
*********************************************************************/
void USART2IntTasks(void) 
{
	char data;
	if(PIR3bits.RC2IF)		//serial rx2,PC
	{	
		PIR3bits.RC2IF = 0;
		usart2char = RCREG2;
		if (RCSTA2bits.FERR)
		{
			CLR_SER2_STATUS(RX_INT)
			SET_SER2_STATUS(RX_ERROR)
			RCSTA2 &= 0xef;	
			rx2_errcode = ERR_USART;
		}
		if (RCSTA2bits.OERR)
    	{
      		RCSTA2bits.CREN = 0;  // Clearing CREN clears any Overrun (OERR) errors
      		RCSTA2bits.CREN = 1;  // Re-enable continuous USART receive
			CLR_SER2_STATUS(RX_INT)
			SET_SER2_STATUS(RX_ERROR)
			RCSTA2 &= 0xef;	
			rx2_errcode = ERR_USART;
    	}	
		else
		{
			SET_SER2_STATUS(RX_INT);
			*Rx2_BufferPtr++ = usart2char;
			*(Rx2_BufferPtr+1) = 0;
			++Rx2Length;
			//rxt_timercount 	= 0;
			timersDec[RX2tdindex] = 10;
		//	rx2time_out 		= RX_TIMEOUT;
		}
	}
	else
	if(PIR3bits.TX2IF)		//serial tx2,PC
	{	
		PIR3bits.TX2IF = 0;
		if (Tx2Length && Tx2_BufferPtr)
		{
			TXREG2 = *Tx2_BufferPtr++;
			Tx2Length--;
		}
		else
		{
			TX2_OFF
			Tx2_BufferPtr = 0;
			RX2_ON
		}
	}

} //USARTDeviceTasks()


//----------------------------------
void pc_executor(void)
{

	Rx2_Tx2();
/*	if (timersDec[RX2tdindex] == 0)
	{
	
	//	mysprintf(dmsg,"proba:0x%x,%d, %x, %d\r\n",1024,1024,2048,2048);
	//	Tx2_Debug(dmsg);
	//	timersDec[RX2tdindex] = 1000; 
	}*/
}