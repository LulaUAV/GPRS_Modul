//---------------------------------------------------------------------------

#include <vcl.h>
#pragma hdrstop

#include <stdio.h>



#include "LoadSimFile.h"
#include "WilGsmGprsTeszt.h"
#include "SerialCom.h"


//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma resource "*.dfm"
TFormSIM300 *FormSIM300;

extern DWORD Send(char* msg, int len, VIEW callback);

//---------------------------------------------------------------------------
__fastcall TFormSIM300::TFormSIM300(TComponent* Owner)
    : TForm(Owner)
{
    m_loadsim = NULL;
}



//---------------------------------------------------------------------------
void __fastcall TFormSIM300::FormCreate(TObject *Sender)
{
    if (m_loadsim == NULL)
        m_loadsim = new LoadSIM();
    m_sim1_index = -1;
    m_sim2_index = -1;
}

//---------------------------------------------------------------------------
void __fastcall TFormSIM300::sendItem_atlist1()
{
    if (m_loadsim->m_atlist1->Count <= m_sim1_index)
    {
        Info->Lines->Add("SIM1: END");
        return;
    }
#ifdef DEMO_SIM900
    AnsiString sDSata =/* "M:" + */AnsiString((char*)m_loadsim->m_atlist1->Items[m_sim1_index]);
#else
    AnsiString sDSata = "M:" + AnsiString((char*)m_loadsim->m_atlist1->Items[m_sim1_index]);
#endif

    if (EnterCbx->State == cbChecked)
        sDSata += '\r';
    else
    if (CTRLZCbx->State == cbChecked)
        sDSata += '\z';

  //  sprintf(msg,"M:%s\r",data);
    if (Send(sDSata.c_str(), sDSata.Length(), NULL) == 0)
        printf("serial sending error\n");
    Info->Lines->Add("SIM1: Send: " + sDSata);
}

//---------------------------------------------------------------------------
void __fastcall TFormSIM300::sendItem_atlist2()
{
    if (m_loadsim->m_atlist2->Count <= m_sim2_index)
    {
        Info->Lines->Add("SIM2: END");
        return;
    }
#ifdef DEMO_SIM900
    AnsiString sDSata = /*"M:" + */AnsiString((char*)m_loadsim->m_atlist2->Items[m_sim2_index]);
#else
    AnsiString sDSata = "M:" + AnsiString((char*)m_loadsim->m_atlist2->Items[m_sim2_index]);
#endif

    if (EnterCbx->State == cbChecked)
        sDSata += '\r';
    if (CTRLZCbx->State == cbChecked)
        sDSata += '\z';

  //  sprintf(msg,"M:%s\r",data);
    if (Send(sDSata.c_str(), sDSata.Length(),NULL) == 0)
        printf("serial sending error\n");
    Info->Lines->Add("SIM2: Send: " + sDSata);   
}

//---------------------------------------------------------------------------
void __fastcall TFormSIM300::ExitBtnClick(TObject *Sender)
{
    Close();    
}
//---------------------------------------------------------------------------
void __fastcall TFormSIM300::LoadBtnClick(TObject *Sender)
{
    m_loadsim->Load();
    m_loadsim->print();    
}
//---------------------------------------------------------------------------
void __fastcall TFormSIM300::SendBtnClick(TObject *Sender)
{
    if (CmdEdit->Text.Length() == 0)
        return;
#ifdef DEMO_SIM900
        AnsiString sDSata = /*"M:" + */CmdEdit->Text; //SIM, Mobil
#else
        AnsiString sDSata = "M:" + CmdEdit->Text; //SIM, Mobil
#endif

    if (EnterCbx->State == cbChecked)
        sDSata += '\r';
    if (CTRLZCbx->State == cbChecked)
        sDSata += '\z';

    Send(sDSata.c_str(), sDSata.Length(), NULL);    
}
//---------------------------------------------------------------------------
void __fastcall TFormSIM300::EnterCbxClick(TObject *Sender)
{
//    
}
//---------------------------------------------------------------------------
void __fastcall TFormSIM300::First1BtnClick(TObject *Sender)
{
    m_sim1_index = 0;    
}
//---------------------------------------------------------------------------
void __fastcall TFormSIM300::Next1BtnClick(TObject *Sender)
{
    m_sim1_index++;
    sendItem_atlist1();    
}
//---------------------------------------------------------------------------
void __fastcall TFormSIM300::Curr1BtnClick(TObject *Sender)
{
    sendItem_atlist1();    
}
//---------------------------------------------------------------------------
void __fastcall TFormSIM300::First2BtnClick(TObject *Sender)
{
    m_sim2_index = -1;     
}
//---------------------------------------------------------------------------
void __fastcall TFormSIM300::Next2BtnClick(TObject *Sender)
{
    m_sim2_index++;
    sendItem_atlist2();   
}
//---------------------------------------------------------------------------
void __fastcall TFormSIM300::Curr2BtnClick(TObject *Sender)
{
     sendItem_atlist2();     
}
//---------------------------------------------------------------------------
void __fastcall TFormSIM300::GPSRSendDataClick(TObject *Sender)
{
    char msg[64];
#ifdef DEMO_SIM900
    for (int ii=0;ii<m_loadsim->m_gprs_len; ii++)
           msg[ii]  = m_loadsim->m_gprs_data[ii];

     Info->Lines->Add("SIM2: Send: " + AnsiString(msg));
     if (Send(msg, m_loadsim->m_gprs_len) == 0)
        printf("serial sending error\n");
#else
     msg[0] = 'M';
     msg[1] = ':';
    for (int ii=0;ii<m_loadsim->m_gprs_len; ii++)
           msg[ii+2]  = m_loadsim->m_gprs_data[ii];
    // strcpy(&msg[0],m_loadsim->m_gprs_data);
     //AnsiString sDSata = "M:" +  AnsiString(m_loadsim->m_gprs_data);
     Info->Lines->Add("SIM2: Send: " + AnsiString(msg));
    // strcpy(msg,sDSata.c_str());
   //  msg[sDSata.Length()] = 0x1a;
    // msg[sDSata.Length()+1] = 0;
     if (Send(msg, m_loadsim->m_gprs_len+2,NULL) == 0)
        printf("serial sending error\n");
#endif    
}


//---------------------------------------------------------------------------


