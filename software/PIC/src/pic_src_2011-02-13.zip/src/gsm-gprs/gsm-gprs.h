//**********************************
//	Tiszai Istvan,  2011.03
//**********************************
#ifndef _GSM_GPRS
#define _GSM_GPRS

enum {
	NONE_VOICE,
	CALL_SLIC_VOICE, //ATD jon
	HELD_GSM_VOICE, //held
	DILAING_GSM_VOICE, // dialing
	ALERTING_GSM_VOICE, //alering
	ACTIVE_VOICE,  // beszelgetes folyik
	HOOKON_SLIC_VOICE, //SLIC letette
	HOOKON_GSM_VOICE // GSM letette
};

typedef struct 
{
	char telnum[26];
	int state;
} VOICE_CALL;

#define CLOCK_FREQ		(16384000ul)		// Hz
#define INSTR_FREQ			((CLOCK_FREQ+2ul)/4ul)

/**
AT commands types
*/
#define OK 0x0
#define GSMTEMP 0x01
#define CHFA	0X02
#define SENDSMS 0x03
#define CALL 	0x04
#define COMMEND 0x05
/**
command execution states
*/
#define STATE_IDLE 0x06
#define STATE_WAIT 0x07
#define STATE_TIMEOUT 0x08
#define STATE_PARSE 0x09

//UART constants
#define BAUD_RATE       (9600)		// bps
#define BUTTON_DEAD_TIME 50
#define RTS 	0
#define CTS		1
#define DTR		2
#define DCD 	3	
#define RI 		4
//#define RX_BUFFER_SIZE	48
#define OVR 1
#define FE	2
#define FRAMING_ERROR (1<<FE)
//#define PARITY_ERROR (1<<UPE)
#define DATA_OVERRUN (1<<OVR)

#define putrsUART(a)			putrsUSART((far rom char*)a)
//#define putcUART(a)				WriteUSART(a)
#define getcUART()				ReadUSART_INT()

extern int gsm_gprs_init(uint16 usart_baud);
extern void gsm_gprs_executor(void);
extern void USART1IntTasks(void) ;

extern void InterruptHandlerGSM (void);
extern void  SIM_send_wait();
extern volatile char  Rx1_Buffer[RX1_MAX_DATA_NUM+1];
extern char  Tx1_Buffer[TX1_MAX_DATA_LEN];
extern int rx_counter;
extern int setSIM300();
extern int send_CID_to_gprs(char* cid);
extern int send_alive_to_gprs();
extern int send_alarm_to_gprs(char cmd, char* alarm, int alarm_len);
extern int send_INIT_to_gprs(char* init);
extern char isGSM_GPRS_NET;
extern int send_sms(unsigned  char* number, unsigned char* message, unsigned int timeout);
extern unsigned char send_Alarm_index();
extern VOICE_CALL voice;
#endif