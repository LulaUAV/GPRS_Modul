//**********************************
//	Tiszai Istvan,  2011.03
//**********************************
#include <p18cxxx.h>
//#include <stdio.h>
//#include <string.h>
#include <p18f6527.h>
#include "defines.h"
#include "slic.h"
#include "spi.h"
#include "../pc/pc.h"
#include "../gsm-gprs/gsm-gprs.h"
#include "utils.h"

const rom WORD slic_definit_reg[] = { 
		INIT_IR0,  INIT_IR1,  INIT_IR2,  INIT_IR3,  INIT_IR4,  INIT_IR5,  INIT_IR6,  INIT_IR7,  INIT_IR8,  INIT_IR9, INIT_IR10, 
		INIT_IR11, INIT_IR12, INIT_IR13, INIT_IR14, INIT_IR15, INIT_IR16, INIT_IR17, INIT_IR18, INIT_IR19, INIT_IR20, 
		INIT_IR21, INIT_IR22, INIT_IR23, INIT_IR24, INIT_IR25, INIT_IR26, INIT_IR27, INIT_IR28, INIT_IR29, INIT_IR30, 
		INIT_IR31, INIT_IR32, INIT_IR33, INIT_IR34,
		//INIT_IR35, INIT_IR36, INIT_IR37, INIT_IR38, INIT_IR39, 
		INIT_IR35_OP, INIT_IR36_OP, INIT_IR37_OP, INIT_IR38_OP, INIT_IR39_OP, 
		INIT_IR40, INIT_IR41, INIT_IR42, INIT_IR43, 
		INIT_IR99, INIT_IR100,INIT_IR101,INIT_IR102,INIT_IR103,INIT_IR104
};

#define SLIC_MAX_INIT_REG43	43
#define SLIC_MAX_INIT_REG99	99
#define SLIC_MAX_INIT_LEN	105


//static int ii_st;

/*SPI data 3 byte
;+0 = CIM
;+1 = DATA vagy DATA_L (indirect)
;+2 = DATA_H (indirect)
*/
//char 	SPIDAT[3];
//char	SIISPI;		//SPI index pointer
//int TONE_flg;
//int offhook = 2;
int hkdtmf_num;

BYTE hkdtmf[3];
//char alarm_dtmf[17];

//char DTMF[16];		//16 karakteres telefonsz�m �tad� regiszter �s CID �tad�
ALARMS 		alarms;
ALARMS_TEMP alarms_temp;

//char DTMFpnt;		// DTMF indexe

//char SLICflag;	//Flag bitek sz�pen kihozva, folyamatosan PULL-oza a rutin.
				//bit0 = Loop Closure (telefon fel/le)
				//bit1 = MATAV kicsenget�s kikapcsol�sa
				//bit2 = 400Hz tarcsahang kiadasa
				//bit3 = Aktualis Status (=bit2-vel ha megt�rt�nt) bels� haszn�latra
				//bit4 = DTMF jel j�tt (Felhaszn�l�nak kell t�r�lnie)
				//bit5 = MATAV kicsenget�s vonal felv�telig... (vonalfelv�telkor ez a bit is t�rl�dik)
				//bit6 = ReINI (megv�ltozott param�terek miatt, vagy csak visza�ll�tjuk a be�ll�tottan (dtmf-n�l el kell �ll�tani a t�rcs�hoz))
				//bit7 = SLIC INI, ha =1, akkor INI ready, wait command

const Si321x_Ring_Cfg Si321x_Ring_Presets[] ={


    /* inputs:  ringtrip ac thresh = 0.036, rt debounce = 0.075*/
    { 0x155, 0x0, 0x0, 0x7EFD, 0x80, 0x3E, 0x0, 0x7D, 0x18, 0xA, 0x320 }
};

/*Si3210 Tone generator (8kHz) */
const Si321x_Tone_Cfg Si321x_Tone_Presets [] = 
{
{{0, 0, 0, 0, 0, 0, 0, 0}, 0 }, // off
{{14876, 2510, 0, 32, 3, 32, 3, 2}, 0x3F }, // 1400Hz 100msec 
{{14876, 2510, 0,  0, 25, 0, 0, 1}, 0x37 }, // 1400Hz 750..1000msec hossz�!!! (pl 800msec) kisoff
{{0xE21E, 5196,0, 32, 3, 32, 3, 2}, 0x3F }, // 2300Hz 100msec 
{{OSC_480HZ_MINUS18DBM_8KHZ, OSC_0_3SEC, OSC_0_2SEC, 0},OSC_TOPHONE}
/*{{OSC_350HZ_MINUS18DBM_8KHZ,OSC_NOTIME,OSC_NOTIME},{OSC_440HZ_MINUS18DBM_8KHZ,OSC_NOTIME,OSC_NOTIME},OSC_TOPHONE,OSC_TOPHONE}, // nincs
{{OSC_480HZ_MINUS18DBM_8KHZ,OSC_0_5SEC,OSC_0_5SEC},{OSC_620HZ_MINUS18DBM_8KHZ,OSC_0_5SEC,OSC_0_5SEC},OSC_TOPHONE,OSC_TOPHONE}, // foglalt
{{OSC_480HZ_MINUS18DBM_8KHZ,OSC_0_2SEC,OSC_0_3SEC},{OSC_620HZ_MINUS18DBM_8KHZ,OSC_0_2SEC,OSC_0_3SEC},OSC_TOPHONE,OSC_TOPHONE},
{{OSC_480HZ_MINUS18DBM_8KHZ,OSC_2SEC,OSC_4SEC},{OSC_440HZ_MINUS18DBM_8KHZ,OSC_2SEC,OSC_4SEC},OSC_TOPHONE,OSC_TOPHONE},//cs�rg�s
{{OSC_480HZ_MINUS18DBM_8KHZ,OSC_0_3SEC,OSC_0_2SEC},{OSC_620HZ_MINUS18DBM_8KHZ,OSC_0_3SEC,OSC_0_2SEC},OSC_TOPHONE,OSC_TOPHONE}*/
};


const Si321x_PCM_Cfg Si321x_Pcm_Presets[] =
{

    /* inputs:  u-law narrowband positive  */
    { 0x1, 0x0, 0x0 },
    /* inputs:  16 bit wideband positive  */
    { 0x3, 0x1, 0x0 }
};

#define AUDIOGAIN_0DB	0

const Si321x_audioGain_Cfg Si321x_AudioGain_Presets [] = 
{
	{AUDIOGAIN_0DB,0x4000}
};

const Si321x_FSK_Cfg Si321x_FSK_Presets[] ={

    /* inputs: mark freq=1200.000, space freq2200.000, amp=0.220, baud=1200.000 */
    { 0x1119L, 0x3BE1L, 0x1E0L, 0x100L, 0x35B0L, 0x3CE0L }
};

//----------------------------------
void delay(int d)
{
	while(d--)
	{
	_asm
    	nop
  	_endasm
	}
}

//----------------------------------
void slic_wait(int ms)
{
	timersDec[SLICtdindex] = ms;
	while (timersDec[SLICtdindex]) CLRWDT ;
}
//----------------------------------
void slic_power_on_reset(void)
{
//Power ON / RESET vonalszimulator
	CS3210 = 1;			//Chip select off
	//mov#	D3210,05		//500msec wait
	slic_wait(500);
	PORTCbits.RC3	= 1;		//SCK magasan tart...
	T_RESET = 0;			//Reset aktiv
}


//----------------------------------
int slic_set_indirectreg_init(void)
{
	BYTE ii=0;
	BYTE kk=0;
	BYTE ee=0;
	WORD temp;	
	while (ii != SLIC_MAX_INIT_LEN)
	{
		if ((ii > SLIC_MAX_INIT_REG43) && (ii < SLIC_MAX_INIT_REG99))
		{
			WriteProSLICIndirectRegister (ii, 0);
			ii++;
			continue;
		}
	/*	else
		if  (ii == SLIC_MAX_INIT_REG99)
		{
			ee++;
		}*/
		for (kk=0;kk<3;kk++)
		{
			if (WriteProSLICIndirectRegister (ii, slic_definit_reg[ee]) == 0)
				break;			
		}
		if (kk == 3)
			return 1;
		for (kk=0;kk<3;kk++)
		{
			temp = ReadProSLICIndirectRegister (ii);
			if (temp == slic_definit_reg[ee])
				break;			
		}
		if (kk == 3)
			return 2;
		ee++;
		ii++;
	}
	return 0;
}

//-------------------------------------------------------
void slic_RingSetup (int preset)
{

	WriteProSLICIndirectRegister(RING_X,Si321x_Ring_Presets[preset].rngx);/* Ringing Oscillator Amplitude */
	WriteProSLICIndirectRegister(RING_Y,Si321x_Ring_Presets[preset].rngy);/*Ringing Oscillator Initial Phase */
	WriteProSLICIndirectRegister(RING_V_OFF,Si321x_Ring_Presets[preset].roff);/*Ringing Oscillator DC Offset */
	WriteProSLICIndirectRegister(RING_OSC_COEF,Si321x_Ring_Presets[preset].rco); /* Ringing Oscillator Frequency */
	
	/* Active Timer */
	WriteProSLICDirectRegister(RING_ON_HI,(Si321x_Ring_Presets[preset].tahi));
	WriteProSLICDirectRegister(RING_ON__LO,(Si321x_Ring_Presets[preset].talo));

	/*  Inactive Timer */
	WriteProSLICDirectRegister(RING_OFF_HI,(Si321x_Ring_Presets[preset].tihi));
	WriteProSLICDirectRegister(RING_OFF_LO,(Si321x_Ring_Presets[preset].tilo));


	WriteProSLICDirectRegister(RING_OSC_CTL,(Si321x_Ring_Presets[preset].ringcon));
	WriteProSLICDirectRegister(RT_DEBOUCE,Si321x_Ring_Presets[preset].rtdi);
	WriteProSLICIndirectRegister(RING_TRIP_FILTER,Si321x_Ring_Presets[preset].nrtp);
}


//----------------------------------
#define SI321X_POWERUP_VOLT_THRESH 0x11


//#define INIT_SI3210M_DR92 0x67  
//#define INIT_SI3210M_DR93 0x16 

//----------------------------------
int slic_powerUp()
{ 
	unsigned char data, data2, i;
	unsigned int vBat, vBatProg, vBatTarget;

	WriteProSLICDirectRegister(92, INIT_SI3210M_DR92);
	WriteProSLICDirectRegister(93, INIT_SI3210M_DR93);

	data = ReadProSLICDirectRegister(80);		/*vtip*/
	data2 = ReadProSLICDirectRegister(81);	/*vring*/
	if ((data > SI321X_POWERUP_VOLT_THRESH) || (data2 > SI321X_POWERUP_VOLT_THRESH))
	{
		DBG_r("SLIC:RC_VBAT_OUT_OF_RANGE:ERROR\r\n");	
		return 1;			
	}
		
	//SI321X_HV
	WriteProSLICDirectRegister (74, 45); // 45*1.5 V = 67.5V
	//WriteProSLICDirectRegister(74, 0x1d);/*vbath */
//	WriteProSLICDirectRegister(75, 0x9);//vbatl
//	WriteProSLICDirectRegister(72, 0x12);//voc 
//	WriteProSLICDirectRegister(73, 0x1);//vcm 

	WriteProSLICDirectRegister(14, 0);/* Enable DC-DC converter */

	/* Wait for measured VBAT to be "close" to desired value.  Always
	 check for a voltage at least 6-10v below programmed level
	 within 200ms */
	
	vBatProg = ReadProSLICDirectRegister(74);
/*	vBatTarget = (vBatProg*15)/10;  //target in volts 
	vBatTarget = ((vBatTarget-6)*200)/75;*/
// SI321X_HV
	vBatTarget = (vBatProg*26)/10; //target in volts
	vBatTarget = ((vBatTarget-6)*156)/100;
	
	vBat=0;
	i=0;
	while ((vBat < vBatTarget) && (i < 2))
	{ 
		vBat = vBatTarget;		
		data = ReadProSLICDirectRegister( 82);
		if (data < vBatTarget)
		{
			vBat = data;
		}		
		if ((i > 2) && (vBat < vBatTarget))
		{
			DBG_r("SLIC:RC_VBAT_UP_TIMEOUT:ERROR\r\n");	
			return 1;			
		}
		slic_wait(100);	
		++i;		
	}
	
	/* Program desired PWM rate and start calibraton */
	
	WriteProSLICDirectRegister(92, INIT_SI3210M_DR92);
	WriteProSLICDirectRegister(93,INIT_SI3210M_DR93);
	slic_wait(30);
	WriteProSLICDirectRegister(93,0x80|INIT_SI3210M_DR93);
		
	do
	{
		data2 = 0;
		data = ReadProSLICDirectRegister( 93);
		data2 |= data;
		if (data&0x80)
		{
			if (i>10)
			{
				DBG_r("SLIC:RC_CAL_TIMEOUT\r\n");	
				return 1;
			}
		}			
		slic_wait(100);
		if (i>10)
			data2 = 0;
		++i;		
	}
	while(0x80&data2);  /* Wait for DC-DC Calibration to complete */
	
	return 0;
}

//----------------------------------

void slic_flushAccumulator()
{
	int i;

	for (i=88;i<212;i++)
	{
		WriteProSLICIndirectRegister (i,0);
	}
}

//----------------------------------
int slic_init(void)
{
	unsigned char temp, i;


	CODEC_m = 1;
	CODEC_p = 1;
	SSP1CON1 = 0;
	slic_power_on_reset();
	slic_wait(500);
	T_RESET	= 1;		//Start VOnalszim
	
//	mov#	D3210,05		//500msec wait

//SPI settings are CPE =1;CKE = 0; and operating in 8-bit mode.
	SSP1STAT = 0x0;
			
	SSP1CON1 = 0b00110010;

	temp = ReadProSLICDirectRegister(0);
	DBG_1form("SLIC_serial:0x%x\n\r",temp);

// AN35.pdf
// STEP 8:
	if (ReadProSLICDirectRegister(8) != 2) 	//Audio Path Loopback Control
		DBG_r("SLIC:not comm.reg 8:ERROR\r\n");
	if (ReadProSLICDirectRegister(11) != 0x33) 	
		DBG_r("SLIC:not comm.reg 11:ERROR\r\n");

//STEP 20: Flush Accumulators
	slic_flushAccumulator();

// STEP 9:
	if (slic_set_indirectreg_init())
	{
		Tx2_Debug_r("INIT ERROR, POWER DOWN\n\r");
	//	RESET 
	//	while(1);
		return 1;
	}
	DBG_r("SLIC:indirectReg. WR:OK\r\n");



// STEP 10:
	WriteProSLICDirectRegister (8, 0); 			// no loopback
	WriteProSLICDirectRegister (108, 0x0EB); 	// Enhancement Enable

	if (slic_powerUp())
	{
		Tx2_Debug_r("POWER UP ERROR, POWER DOWN\n\r");
	//	RESET 
	//	while(1);
		return 2;
	}
	DBG_r("SLIC:DC-DC OKE\r\n");



	WriteProSLICDirectRegister (64, 0);
		
	WriteProSLICDirectRegister (74, 45); // 45*1.5 V = 67.5V
//	temp = ReadProSLICDirectRegister (74);
//	DBG_1form("SLIC_V:0x%x\n\r",temp);

	
/*	WriteProSLICDirectRegister (92, 67); 		// DC-DC Converter PWM Period
	WriteProSLICDirectRegister (93, 16); 		// DC-DC Converter Switching Delay
	WriteProSLICDirectRegister (14, 0); 		// Power Down Control 1

	temp  = 0;
	while (temp < 80)
	{
		temp = ReadProSLICDirectRegister (82);		// Battery Voltage Sense 1
		slic_wait(20);
	}*/
//	DBG_r("SLIC:DC-DC OKE\r\n");

	// SLIC calibration :
	temp  = 0;
//STEP 12
	while (temp < 7)
	{
		slic_wait(10);
		WriteProSLICDirectRegister (93, 0b1001000); 	// Start CALIBRATION ,DC-DC Converter Switching Delay
		slic_wait(300);									//wait 300msec
		temp = ReadProSLICDirectRegister (93);
	}
//	DBG_1form("CAL1:0x%x\n\r",temp);
//	WriteProSLICDirectRegister (64, 0); 			 	// Linefeed Control
	WriteProSLICDirectRegister(21, 0);					/*Disable all interupts in DR21 */
	WriteProSLICDirectRegister(22, 0);				/*Disable all interupts in DR22 */
	WriteProSLICDirectRegister(23, 0);				/*Disabel all interupts in DR23 */
//STEP 13
	WriteProSLICDirectRegister(64, 0); 				/*OPEN_DR64 = 0 */
//STEP 14
	while (temp)
	{
		WriteProSLICDirectRegister (97, 0x1E); 			// Calibration Control/Status Register 2
		WriteProSLICDirectRegister (96, 0x47); 			// Calibration Control/Status Register 1
		slic_wait(800);	
		temp = ReadProSLICDirectRegister (96);			// Calibration Control/Status Register 1
	}
	
	slic_wait(10);
//STEP 16
	// Manual Calibration:
	WriteProSLICDirectRegister( 99, 0x10);				// Initialize TIP gain cal while RING being calibrated ,(gabore:0x1F),TIP Gain Mismatch Calibration Result
	for(i=0x1f; i>0; i--)
	{
		WriteProSLICDirectRegister( 98, i);
		slic_wait(40);
		temp = ReadProSLICDirectRegister (88);				//Transistor 5 Current Sense
		if (temp == 0)	
			break;
	}
	if (temp == 0)
	{
		DBG_r("SLIC:Manual Cal.OKE\r\n");
	}
	else
	{
		DBG_1form("SLIC:Manual Cal BAD:0x%x\n\r",i);
	}

	// TIP Gain Calibration :si321x_intf.c
	for(i=0x1f; i>0; i--)
	{
		WriteProSLICDirectRegister( 99, i);
		slic_wait(40);
		temp = ReadProSLICDirectRegister (89);				//Transistor 5 Current Sense
		if (temp == 0)	
			break;
	}
	if (temp == 0)
	{
		DBG_r("SLIC:TIP Gain Cal.OKE\r\n");
	}
	else
	{
		DBG_1form("SLIC:Manual Cal BAD:0x%x\n\r",i);
	}


 //  Long Balance Cal
	WriteProSLICDirectRegister(23, (1<<2)); //enable interrupt for the balance Cal.
	WriteProSLICDirectRegister(64, 1); 		//Linefeed Control:Forward active
	slic_wait(250);
	if (ReadProSLICDirectRegister (LOOP_STAT) & 1)
	{ /* offhook */ 
		DBG_r("SLIC:off-hook ERROR\r\n");
	}
	else
		DBG_r("SLIC:Cal.OKE\r\n");

	WriteProSLICDirectRegister(LINE_IMPEDANCE, 0x28);  //Two-Wire Impedance Synthesis Control
	WriteProSLICDirectRegister(PCM_MODE, 0x28);   ////PCM Mode Select:uLOW , PCM Transfer Size.:16-bit

	WriteProSLICDirectRegister(4, 1); //PCM Receive Start Count�Low Byte
	WriteProSLICDirectRegister(5, 0); //PCM Receive Start Count�High Byte

	//Sajat be�ll�t�s (halkabb legyen a GSM telefon, �s hangosab legyen a PSTN telefon)
	WriteProSLICDirectRegister(9, 0b00000110); //Audio Gain Control
	WriteProSLICDirectRegister(34, 0x18); //Ringing Oscillator Control
	WriteProSLICDirectRegister(48, 0x80); //Ringing Oscillator Active Timer�Low Byte
	WriteProSLICDirectRegister(49, 0x3E); //Ringing Oscillator Active Timer�High Byte
	WriteProSLICDirectRegister(51, 0x7D); //Ringing Oscillator Inactive Timer�High Byte
	WriteProSLICDirectRegister(69, 0x0C); //Loop Closure Debounce Interval
	WriteProSLICDirectRegister(97, 0x01); 
	WriteProSLICDirectRegister(24, 0x40); 
	WriteProSLICDirectRegister(96, 0x40); 

	WriteProSLICDirectRegister (65, INIT_DR65);
	WriteProSLICDirectRegister (71, INIT_DR71);

//	slic_print_reg(); // print regiszter

//STEP 21:
		temp = ReadProSLICDirectRegister(INTRPT_STATUS1);
		WriteProSLICDirectRegister (INTRPT_STATUS1, temp);
		temp = ReadProSLICDirectRegister(INTRPT_STATUS2);
		WriteProSLICDirectRegister (INTRPT_STATUS2, temp);
		temp = ReadProSLICDirectRegister(INTRPT_STATUS3);
		WriteProSLICDirectRegister (INTRPT_STATUS3, temp);

//STEP 27
		WriteProSLICIndirectRegister (35	,	INIT_IR35);
		WriteProSLICIndirectRegister (36	,	INIT_IR36);
		WriteProSLICIndirectRegister (37	,	INIT_IR37);
		WriteProSLICIndirectRegister (38	,	INIT_IR38);
		WriteProSLICIndirectRegister (39	,	INIT_IR39);

		WriteProSLICDirectRegister(INTRPT_MASK1,	0xFF);
		WriteProSLICDirectRegister (INTRPT_MASK2,	0xFF);
		WriteProSLICDirectRegister (INTRPT_MASK3,	0xFF);

		WriteProSLICDirectRegister(LINE_STATE,	ACTIVATE_LINE);
	

	CS3210 = 0;		
	//PIE1bits.SSPIE = 1;

//	slic_print_reg(); // print regiszter
//	slic_RingSetup (0);
//	Si321x_ToneGenSetup (4);
	slic_PCMSetup (0);
	slic_PCMTimeSlotSetup (0, 0);
//	slic_TXAudioGainSetup ( 0);
//	slic_RXAudioGainSetup ( 0);
   // slic_RingStart ();

//	hkdtmf = 0;

	timersDec[SLICtdindex] = 1000;
	timersDec[SLIC_EXEtdindex] = SLIC_EXE;

	hkdtmf_num = 0;;
//	WriteProSLICDirectRegister (8, 4); //LOOP!!ZAJ MAITT!
	WriteProSLICDirectRegister (1, 0x20); //PCM enable 
	for (i=0;i<MAX_ALARM_NUM;i++)
	{
		alarms.dtmf[i][0]  = NONE_ALRM;
		alarms.dtmf[i][1]  = 0;
	//	alarms.dtmf[i][16] = 0;
		alarms.dtmf[i][18] = 0;
 	
	}
	alarms.rd_index = 0;
	alarms.wr_index = 0;
	alarms.tone_flg = 10;
	alarms.state = 0;
	alarms.wr_counter  = 0;
	alarms_temp.dtmf[18] = 0;

	voice.state 	= NONE_VOICE;
	voice.telnum[0] = 0;

	WriteProSLICDirectRegister(AUDIO_GAIN, 6);  

	DBG_r("SLIC:Init READY\r\n");	
	return 0;
}


//----------------------------------
void ProSLICSPIDelay (void) 
{
    int SPI_delay = 10U;
    while (SPI_delay--);
}

//----------------------------------
void ProSLICWriteByte (BYTE b) 
{
    CS3210 = 0;		// selected
    WriteSPI1(b);
    CS3210 = 1;		// deselected
}

//----------------------------------
BYTE ProSLICReadByte (void) 
{
    BYTE ret;
    CS3210 = 0;		// selected
    ret = ReadSPI1();
    CS3210 = 1;		// deselected
    return ret;
}

//----------------------------------
void WriteProSLICDirectRegister (BYTE reg, BYTE val) 
{

    ProSLICWriteByte (reg);
    ProSLICSPIDelay ();
    ProSLICWriteByte (val);
}

//----------------------------------
BYTE ReadProSLICDirectRegister (BYTE reg) 
{
    ProSLICWriteByte (0x80 | reg);
    ProSLICSPIDelay ();
    return (ProSLICReadByte ());
}

//----------------------------------
int WaitForIndirectAccess (void) 
{
    int i;
    for (i = 0; i < 1000; i++) {
        if (ReadProSLICDirectRegister (31) == 0) // 0x01 if indir I/O is pending
	    return 0;
    }
    return 1;
}

//----------------------------------
WORD ReadProSLICIndirectRegister (BYTE reg) 
{
    WORD ret = 0;

    if (WaitForIndirectAccess ()) {
        return 0xDead;
    }
    WriteProSLICDirectRegister (30, reg);
    if (WaitForIndirectAccess ()) {
        return 0xBeef;
    }
    ret = ReadProSLICDirectRegister (29);
    ret <<= 8;
    ret |= ReadProSLICDirectRegister (28);
    return ret;
}

//----------------------------------
int WriteProSLICIndirectRegister (BYTE reg, WORD val) 
{
    if (WaitForIndirectAccess ()) 
	{		
        return 1;
    }
    WriteProSLICDirectRegister (28, (BYTE) (val & 0xff));
    WriteProSLICDirectRegister (29, (BYTE) ((val & 0xff00) >> 8));
    WriteProSLICDirectRegister (30, reg);
	return 0;
}

//----------------------------------
void slic_print_reg()
{
	BYTE  d_reg;
	WORD  int_reg;
	int ii;

	DBG_r("SLIC Direct Reg.\r\n");

 	for (ii=0;ii<109;ii++)
	{
		d_reg = ReadProSLICDirectRegister (ii);
		DBG_1form("D%d:",ii);
		DBG_1form("0x%x\r\n",d_reg);
		slic_wait(5);
	}
	DBG_r("SLIC Indirect Reg.\r\n");
	for (ii=0;ii<44;ii++)
	{
		int_reg = ReadProSLICIndirectRegister (ii);
		DBG_1form("I%d:",ii);
		DBG_1form("0x%x\r\n",int_reg);
		slic_wait(5);
	}
	for (ii=99;ii<105;ii++)
	{
		int_reg = ReadProSLICIndirectRegister (ii);
		DBG_1form("I%d:",ii);
		DBG_1form("0x%x\r\n",int_reg);
		slic_wait(5);
	}
}
//----------------------------------
/*
** Function: PROSLIC_ToneGenSetup
**
** Description: 
** configure tone generators
*/
void Si321x_ToneGenSetup (int preset)
{
	Si321x_Tone_Cfg *pTone;

	pTone = Si321x_Tone_Presets;


	WriteProSLICDirectRegister(OSC1,0);
	WriteProSLICDirectRegister(INTRPT_STATUS1,3);

	WriteProSLICIndirectRegister(OSC1X,pTone[preset].osc1.amp);
	WriteProSLICIndirectRegister(OSC1Y,pTone[preset].osc1.phas);
	WriteProSLICIndirectRegister(OSC1_COEF,pTone[preset].osc1.freq);
	
	WriteProSLICDirectRegister(OSC1_ON_HI,(pTone[preset].osc1.tahi));
	WriteProSLICDirectRegister(OSC1_ON__LO,(pTone[preset].osc1.talo));
	WriteProSLICDirectRegister(OSC1_OFF_HI,(pTone[preset].osc1.tihi));
	WriteProSLICDirectRegister(OSC1_OFF_LO,(pTone[preset].osc1.tilo));
/*	
	WriteProSLICIndirectRegister(OSC2X,pTone[preset].osc2.amp);
	WriteProSLICIndirectRegister(OSC2Y,pTone[preset].osc2.phas);
	WriteProSLICIndirectRegister(OSC2_COEF,pTone[preset].osc2.freq);
	
	WriteProSLICDirectRegister(OSC2_ON_HI,(pTone[preset].osc2.tahi));
	WriteProSLICDirectRegister(OSC2_ON__LO,(pTone[preset].osc2.talo));
	WriteProSLICDirectRegister(OSC2_OFF_HI,(pTone[preset].osc2.tihi));
	WriteProSLICDirectRegister(OSC2_OFF_LO,(pTone[preset].osc2.tilo));*/
	
	WriteProSLICDirectRegister(OSC1,(pTone[preset].omode1));
	WriteProSLICDirectRegister(INTRPT_MASK1,(pTone[preset].osc1.interrupt));
//	WriteProSLICDirectRegister(OSC2,(pTone[preset].omode2));
	WriteProSLICDirectRegister(INTRPT_STATUS1,3);


}

//----------------------------------
/*
** Function: PROSLIC_StopTone
**
** Description: 
** Stops tone generators
**
** Input Parameters: 
** pProslic: pointer to Proslic object
**
** Return:
** none
*/
void slic_ToneGenStop ()
{
	Si321x_ToneGenSetup (0);
/*	uint8 data;

	data = ReadProSLICDirectRegister(OSC1);
	data &= ~(0x1C);
	WriteProSLICDirectRegister(OSC1,data);*/

/*	data = ReadProSLICDirectRegister(OSC2);
	data &= ~(0x1C);
	WriteProSLICDirectRegister(OSC2,data);*/
}

//----------------------------------
/*
** Function: PROSLIC_StartGenericTone
**
** Description: 
** start tone generators
*/
void slic_ToneGenStart (uint8 timerEn)
{
//	Si321x_ToneGenSetup(timerEn);
/*	uint8 data;
	slic_ToneGenStop();
	
	data = ReadProSLICDirectRegister(OSC1);
	data |= 0x4 + (timerEn ? 0x18 : 0);
	WriteProSLICDirectRegister(OSC1,data);*/

/*	data = ReadProSLICDirectRegister(OSC2);
	data |= 0x4 + (timerEn ? 0x18 : 0);
	WriteProSLICDirectRegister(OSC2,data);	*/
}

//---------------------------------------------
/*
** Function: PROSLIC_StartRing
**
** Description: 
** start ring generator
*/
void slic_RingStart ()
{
	WriteProSLICDirectRegister(LINE_STATE,LF_RINGING);
}

//-----------------------------------------------
/*
** Function: PROSLIC_StopRing
**
** Description: 
** Stops ring generator
*/
void slic_RingStop ()
{
	WriteProSLICDirectRegister(LINE_STATE,LF_FWD_ACTIVE);
}

/*
** Function: PROSLIC_PulseMeterStart
**
** Description: 
** start pulse meter tone
*/

void slic_PulseMeterStart ()
{
	WriteProSLICDirectRegister(PULSE_OSC,0xff); /* enable timers and oscillator */	
}

/*
** Function: PROSLIC_PulseMeterStop
**
** Description: 
** stop pulse meter tone
*/
void slic_PulseMeterStop ()
{	
	WriteProSLICDirectRegister(PULSE_OSC,0); /* diasbles timers and oscillator */
}

/*
** Function: PROSLIC_ReadDTMFDigit
**
** Description: 
** Read DTMF digit (would be called after DTMF interrupt to collect digit)
*/
void slic_DTMFReadDigit (uint8 *pDigit)
{
	*pDigit = ReadProSLICDirectRegister(DTMF_DIGIT);
	*pDigit = *pDigit & 0xf;
}

/*
** Function: PROSLIC_PCMSetup
**
** Description: 
** configure pcm
*/


void slic_PCMSetup ( int preset)
{
	uint8 data=0;		
	data |= Si321x_Pcm_Presets [preset].pcmf<<2;
	data |= Si321x_Pcm_Presets [preset].wbe<<6;
	data |= Si321x_Pcm_Presets [preset].tri;
//	WriteProSLICDirectRegister(PCM_MODE, data);
	WriteProSLICDirectRegister(PCM_MODE, 0x28);
}

//----------------------------------
void slic_PCMTimeSlotSetup ( uint16 rxcount, uint16 txcount)
{
/*	WriteProSLICDirectRegister(PCM_XMIT_START_COUNT_LSB,txcount & 0xff);
	WriteProSLICDirectRegister(PCM_XMIT_START_COUNT_MSB,txcount >> 8);

	WriteProSLICDirectRegister(PCM_RCV_START_COUNT_LSB,rxcount & 0xff);
	WriteProSLICDirectRegister(PCM_RCV_START_COUNT_MSB,rxcount >> 8);*/

	WriteProSLICDirectRegister(PCM_XMIT_START_COUNT_LSB,1);
	WriteProSLICDirectRegister(PCM_XMIT_START_COUNT_MSB,0);
	WriteProSLICDirectRegister(PCM_RCV_START_COUNT_LSB,1);
	WriteProSLICDirectRegister(PCM_RCV_START_COUNT_MSB,0);
}

/*
** Function: PROSLIC_AudioGainSetup
**
** Description: 
** configure audio gains
*/

// Si321x_audioGain_Cfg Si321x_AudioGain_Presets [];
/*
void slic_TXAudioGainSetup ( int preset)
{
	uint8 data;
	data = ReadProSLICDirectRegister( AUDIO_GAIN);
	data &= ~(0xC);
	WriteProSLICDirectRegister( AUDIO_GAIN, data|(Si321x_AudioGain_Presets[preset].gain<<2));
	WriteProSLICIndirectRegister( XMIT_DIGITAL_GAIN, Si321x_AudioGain_Presets[preset].digGain);	
}*/

/*
** Function: PROSLIC_AudioGainSetup
**
** Description: 
** configure audio gains
*/
/*
void slic_RXAudioGainSetup ( int preset)
{
	uint8 data;
	data = ReadProSLICDirectRegister( AUDIO_GAIN);
	data &= ~(0x3);
	WriteProSLICDirectRegister( AUDIO_GAIN, data|Si321x_AudioGain_Presets[preset].gain); // AUDIO_GAIN == 9 
	WriteProSLICIndirectRegister( RECV_DIGITAL_GAIN, Si321x_AudioGain_Presets[preset].digGain);
}*/

/*
** Function: PROSLIC_FSKSetup
**
** Description: 
** configure fsk
*/

//extern Si321x_FSK_Cfg Si321x_FSK_Presets [];
void slic_FSKSetup ( int preset)
{
	WriteProSLICIndirectRegister( FSK_X_0, Si321x_FSK_Presets[preset].fsk0); /*fsk frequency 0 location */
	WriteProSLICIndirectRegister(FSK_COEFF_0, Si321x_FSK_Presets[preset].fsk0x); /* fsk amplitude 0 location */

	WriteProSLICIndirectRegister(FSK_X_1, Si321x_FSK_Presets[preset].fsk1); /* fsk frequency 0 location */
	WriteProSLICIndirectRegister( FSK_COEFF_1, Si321x_FSK_Presets[preset].fsk1x); /* fsk amplitude 1 location */

	WriteProSLICIndirectRegister(FSK_X_01,Si321x_FSK_Presets[preset].fsk01);
	WriteProSLICIndirectRegister( FSK_X_10, Si321x_FSK_Presets[preset].fsk10);

	WriteProSLICDirectRegister( OSC1_ON__LO, 19);

	WriteProSLICDirectRegister( OSC1_ON_HI, 0);
}

//---------------------------------
void slic_handshake()
{
	switch (alarms.tone_flg)
	{
		case 0:
		{ // off timer
		//	DBG_1form("HAND 0:%d\n\r",(int)timersDec[MEROtdindex]);
			Si321x_ToneGenSetup(0);
			break;
		}
		case 1:
		{ // 1400 Hz
			DBG_r("HAND 1400\r\n");
			Si321x_ToneGenSetup(1);
			alarms.tone_flg = 2;
			timersDec[MEROtdindex] = 2000;

			break;
		}
		case 2:
		{ // 2300 Hz
		//	DBG_1form("HAND 2300:%d\r\n",(int)timersDec[MEROtdindex]);
			DBG_r("HAND 2300\r\n");
			Si321x_ToneGenSetup(3);
			timersDec[MEROtdindex] = 2000;
			alarms.tone_flg = 0;
			break;
		}	
	}
}

//---------------------------------
void slic_kissoff()
{ 
	if (alarms.tone_flg == 3)
	{
		DBG_r("KISOFF end\r\n");
		Si321x_ToneGenSetup(0);
		alarms.tone_flg = 0;
	
	}
	else
	{
		DBG_r("KISOFF start\r\n");
		Si321x_ToneGenSetup(2);
		alarms.tone_flg = 3;
	}	
}

//---------------------------------
void slic_tone()
{ 
		DBG_r("TONE start\r\n");
		Si321x_ToneGenSetup(4);	
}

//----------------------------------
unsigned char next_dtmf_index()
{
	int i;

	for (i=0;i<MAX_ALARM_NUM;i++)
	{
		if (alarms.dtmf[i][0]  == NONE_ALRM)
		{
			return i ;
		}
	}
	return 255;
}

//----------------------------------
unsigned char slic_chs_check()
{
	unsigned char chs = 0;
	int i;
	for (i=0;i<15;i++)
	{
	 	chs += (alarms_temp.dtmf[i+2] - 0x30);
	}
	chs = 15 - (chs % 15);
	chs  += 0x30; 
	
	if (chs == (unsigned char)alarms_temp.dtmf[17] )
		return 0;
	return 1;
}
//----------------------------------
void slic_onhook(void)
{ // bont

	alarms.tone_flg = 0;
	slic_handshake();  
	alarms.state = 0;
	hkdtmf_num = 0;	
	LED3_OFF
	WriteProSLICDirectRegister(64, 51); 
	WriteProSLICDirectRegister(64, 17);	
	slic_tone();
	DBG_r("ONHOOK\r\n");
}

//----------------------------------
void slic_executor(void)
{
	BYTE  int_res;
//	char  buff[3];
	static int  i = 0;

 	if (!T_INT) 
	{ //INT
	//	DBG_r("I1\r\n");
        // interrupts (should) occur only on hook state changes or DTMF detect
 		int_res = ReadProSLICDirectRegister (INTRPT_STATUS3);
		if (int_res)
		{ // 20
 			WriteProSLICDirectRegister (INTRPT_STATUS3, int_res);      // clears interrupt
			if (isGSM_GPRS_NET == 0)
				goto int_20_exit;
 			if (int_res & 0x01) 
			{	// DTMF event
	        	int_res = ReadProSLICDirectRegister (DTMF_DIGIT);	// get DTMF state,24
				if (alarms.state == 4)
				{	//telefonhivas alatt
					goto int_20_exit;
				}
				if (int_res & 0x10)
				{				
					hkdtmf[0] = (int_res & 0x0f) + 0x30;		// mask into hkdtmf
					hkdtmf[1] = 0;
					DBG_1form("DTMF:%s\r\n",hkdtmf);
					timersDec[GSM1tdindex] = GPRS_ALARM;
					timersDec[GSM_NETWORKtdindex] = GSM_NETWORK_DEFAULT;

					if (next_dtmf_index() == 255)
					{ // full tarolo,var
						hkdtmf_num = 2;	
						alarms.state = 1;
						goto int_20_exit;
					}
					
					if (alarms.wr_counter > 254)
					{ // max a wr szamlalo
						if (send_Alarm_index() != 255)
						{ //var
							hkdtmf_num = 2;	
							alarms.state = 1;
							goto int_20_exit;
						}
						alarms.wr_counter = 0;
					}
				
					if (alarms.state == 1)
					{ //telefon hivas, 4 dtmf
						alarms.telnum[hkdtmf_num]=hkdtmf[0];	
						if (hkdtmf_num >= 3)
						{ //handsake beallitas, majd 500 ms kuldi
							alarms.state = 2;
							timersDec[SLIC_EXEtdindex] = 700;
							hkdtmf_num = 2;	
							next_dtmf_index();	
//TEST  start	
/*					
							if ((alarms.telnum[0] == '1') && (alarms.telnum[1] == '2') && (alarms.telnum[2] == '3') && (alarms.telnum[3] == '4'))
							{	// teszt1				
								WriteProSLICDirectRegister (8, 1); 			// ALM1 loopback
								goto int_20_exit;
							}
							else
							if ((alarms.telnum[0] == '2') && (alarms.telnum[1] == '3') && (alarms.telnum[2] == '4') && (alarms.telnum[3] == '5'))
							{	// teszt2				
								WriteProSLICDirectRegister (8, 4); 			// ALM2 loopback
								goto int_20_exit;
							}
							else
							if ((alarms.telnum[0] == '3') && (alarms.telnum[1] == '4') && (alarms.telnum[2] == '5') && (alarms.telnum[3] == '6'))
							{	// teszt3				
								WriteProSLICDirectRegister (8, 2); 			// DLM loopback
								goto int_20_exit;
							}
*/
//TEST end
						}
						else
							hkdtmf_num++;
					}				
					else
					if (alarms.state == 2)
					{ // 16 byte riasztas dtmf kodok.			
						if (hkdtmf_num == 2)
						{						
							if ((alarms.telnum[0] == '3') && (alarms.telnum[1] == '3') && (alarms.telnum[2] == '3') && (alarms.telnum[3] == '3'))
							{
							//	alarms.dtmf[alarms.wr_index][0] = GPRS_ALRM;	
								alarms_temp.dtmf[0] = GPRS_ALRM;
							}
							else
							if ((alarms.telnum[0] == '5') && (alarms.telnum[1] == '5') && (alarms.telnum[2] == '5') && (alarms.telnum[3] == '5'))
							{
							//	alarms.dtmf[alarms.wr_index][0] = VOICE_ALRM;
								alarms_temp.dtmf[0] = VOICE_ALRM;
							}
							else
							if ((alarms.telnum[0] == '6') && (alarms.telnum[1] == '6') && (alarms.telnum[2] == '6') && (alarms.telnum[3] == '6'))
							{
							//	alarms.dtmf[alarms.wr_index][0] = SMS_ALRM;	
								alarms_temp.dtmf[0] = SMS_ALRM;	
							}
							else
							{
							 	alarms_temp.dtmf[0] = NATIV_VOICE_ALRM;	
								//DBG_r("111!\r\n");
								hkdtmf_num += 3;	
								alarms_temp.dtmf[1] = alarms.telnum[0];
								alarms_temp.dtmf[2] = alarms.telnum[1];
								alarms_temp.dtmf[3] = alarms.telnum[2];
								alarms_temp.dtmf[4] = alarms.telnum[3];
								alarms.tone_flg = 0;
								slic_handshake();
							//	timersDec[SLIC_EXEtdindex] = 3000;	// 3 sec utan el kezd tarcsazni
							}
						}
						
						timersDec[SLIC_EXEtdindex] = 5000;							
						//alarms.dtmf[alarms.wr_index][hkdtmf_num]=hkdtmf[0];	
						alarms_temp.dtmf[hkdtmf_num]=hkdtmf[0];	
						hkdtmf_num++;				
						
						if (alarms_temp.dtmf[0] != NATIV_VOICE_ALRM)
						{	
							if (hkdtmf_num >= 18)
							{
								if (slic_chs_check() == 0)
								{
									alarms.state = 3;
									alarms.wr_index = next_dtmf_index();
									alarms.wr_counter++;
									alarms_temp.dtmf[1] = alarms.wr_counter;	
									for (i=0;i<19;i++)
									{
										alarms.dtmf[alarms.wr_index][i] = alarms_temp.dtmf[i];
									}
									hkdtmf_num = 2;
									alarms.tone_flg = 10;
									slic_kissoff();
								}
								else
								{ //chs hiba
									hkdtmf_num = 2;	
									alarms.state = 1;
									DBG_r("CHS-FAIL!\n\r");
									goto int_20_exit;
								}						
							}
						}
		/*				else
						{ //telefonhivas
						
							if (hkdtmf_num<24)
							{
								alarms_temp.dtmf[hkdtmf_num] = 0;
								alarms.state = 4;
							}
						}*/
					}
								
				}
	    	}
		//	DBG_r("I20\r\n");
		}
int_20_exit:
		int_res = ReadProSLICDirectRegister (INTRPT_STATUS1);
		if (int_res)
		{ // 18
			WriteProSLICDirectRegister (INTRPT_STATUS1, int_res);      // clears interrupt
			if (isGSM_GPRS_NET == 0)
				return;
 		
		//	DBG_1form("int_D18:0x%x\n\r",int_res);
			if ((int_res & 2) && (alarms.state == 2))
			{
				slic_handshake();
			//	slic_kissoff();
			}
			else
			if ((int_res & 1) && (alarms.state == 3))
			{
				slic_kissoff();
				alarms.state = 2;�
				timersDec[SLIC_EXEtdindex] = 2000;
			}
		}
        int_res = ReadProSLICDirectRegister (INTRPT_STATUS2);
		if (int_res)
		{ // 19
 			WriteProSLICDirectRegister (INTRPT_STATUS2, int_res);      // clears interrupt
			if (isGSM_GPRS_NET == 0)
				return;
		//	DBG_1form("int_D19:0x%x\n\r",int_res);
				int_res = ReadProSLICDirectRegister (LOOP_STAT); //68                               		
				if (int_res & 0x04) 
				{	/*ONHOOK: put down the phone*/  		    	
				/*	alarms.tone_flg = 0;
					slic_handshake();  
					alarms.state = 0;
					hkdtmf_num = 0;	
					LED3_OFF
					DBG_r("ONHOOK\r\n");*/
					slic_onhook();
					voice.state = HOOKON_SLIC_VOICE;
				}
				else 
				{ /* OFFHOOK: the phone is being taken up */  		
					alarms.state = 1;
					hkdtmf_num = 0;;
					LED3_ON
					slic_tone();
					DBG_r("OFFHOOK\r\n");				   	
				}             		           		
		}
	}

	if ((timersDec[SLIC_EXEtdindex] == 0) && (alarms.state == 2) )
	{
		timersDec[SLIC_EXEtdindex] =  5000;//SLIC_EXE;

		if (alarms_temp.dtmf[0] == NATIV_VOICE_ALRM)
		{ // telefonhivas
			if (hkdtmf_num>9)
			{ //telefonhivas	
				//	DBG_r("222!\r\n");			
				alarms_temp.dtmf[0] = NONE_ALRM;
					
				if (hkdtmf_num>24)
				{
					hkdtmf_num = 24;								
				}
				alarms_temp.dtmf[hkdtmf_num] = 0;
				for (i=0;i<24;i++)
				{
					voice.telnum[i] = 0;
				}
				for (i=0;i<hkdtmf_num;i++)
				{
					voice.telnum[i] = alarms_temp.dtmf[i+1];
				}
				voice.telnum[i-1] = ';';
				voice.telnum[i] = 0;
				alarms.state = 4;
				// GSM call!
			//	DBG_1form("Voice tel.num:%s\r\n", voice.telnum);
				voice.state = CALL_SLIC_VOICE;
				timersDec[GSM1tdindex] = GSM_VOICE1;
			}
			else
			{// bont
				DBG_r("h222!\r\n");
				slic_onhook();
				voice.state = HOOKON_SLIC_VOICE;
			}
		}
		else
		{
			alarms.tone_flg = 1;
			slic_handshake(); 
		}
	}
}

