//=============================================================================
//=============================================================================
// Filename: MAIN.C
//=============================================================================
#include <p18cxxx.h>
#include <p18f6527.h>
#include "defines.h"
#include "gsm-gprs/gsm-gprs.h"
#include "pc/pc.h"
#include "slic/slic.h"

#define 	DEBUG 0

#ifdef	DEBUG_
/*#pragma config	WDTPS = 32768  	//wathdog
#pragma config	CP0 = OFF	//code protect
#pragma config	DEBUG = ON	
#pragma config	OSC = HS	//HS
// #pragma config	OSC = HSPLL ;PLL osszc.
// #pragma config	OSCS = OFF
 #pragma config	PWRT = OFF
 #pragma config	BOREN = OFF
// #pragma config	BORV = 27
 #pragma config	WDT = OFF	//wathdog
 #pragma config	MCLRE = ON	//reset
 #pragma config	CCP2MX = PORTC
 #pragma config	BBSIZ = BB4K      //   2K words (4 Kbytes) Boot Block size

// #pragma config	STVR = ON
 #pragma config	LVP = OFF
 #pragma config	CP1 = OFF
 #pragma config	CP2 = OFF
// #pragma config	CP3 = ON
 #pragma config	CPB = OFF 	//boot potect
 #pragma config	CPD = OFF 	//eeprom protect
 #pragma config	WRT0 = OFF 	//tabla write
 #pragma config	WRT1 = OFF 
 #pragma config	WRT2 = OFF 
// #pragma config	WRT3 = ON 
 #pragma config	WRTB = OFF 	//tabla boot
 #pragma config	WRTC = OFF	//config regiszter
 #pragma config	WRTD = OFF 	//EEPROM Write
 #pragma config	EBTR0 = OFF	//tabla read
 #pragma config	EBTR1 = OFF
 #pragma config	EBTR2 = OFF
// #pragma config	EBTR3 = ON
 #pragma config	EBTRB = OFF	//tabla boot*/
#else
//NO debug
 #pragma config	OSC = HS	//HS
 #pragma config	FCMEN = OFF 
// #pragma config	OSC = HSPLL //PLL osszc.
// #pragma config	OSCS = OFF
 #pragma config	PWRT = OFF 
 #pragma config	BOREN = OFF
// #pragma config	BORV = 20
 #pragma config	WDT = ON	//wathdog
 #pragma config	WDTPS = 8192  	//wathdog
 #pragma config	MCLRE = ON	//reset
 #pragma config	CCP2MX = PORTC
 #pragma config	BBSIZ = BB4K      //   2K words (4 Kbytes) Boot Block size

// #pragma config	STVR = ON
 #pragma config	LVP = OFF
 #pragma config	CP0 = OFF	//code protect
 #pragma config	CP1 = OFF
 #pragma config	CP2 = OFF
// #pragma config	CP3 = ON
 #pragma config	CPB = OFF 	//boot potect
 #pragma config	CPD = OFF 	//eeprom protect
 #pragma config	WRT0 = OFF 	//tabla write
 #pragma config	WRT1 = OFF 
 #pragma config	WRT2 = OFF 
// #pragma config	WRT3 = ON 
 #pragma config	WRTB = OFF 	//tabla boot
 #pragma config	WRTC = OFF	//config regiszter
 #pragma config	WRTD = OFF 	//EEPROM Write
 #pragma config	EBTR0 = OFF	//tabla read
 #pragma config	EBTR1 = OFF
 #pragma config	EBTR2 = OFF
// #pragma config	EBTR3 = ON
 #pragma config	EBTRB = OFF	//tabla boot
#endif


//----------------------------------------------------------------------------
union
{
  struct
  {
    unsigned Timeout:1;         //flag to indicate a TMR0 timeout
	unsigned Led1:1;
	unsigned Led2:1;
	unsigned Tamper:1;
    unsigned None:4;
  } Bit;
  unsigned char Byte;
} Flags;

volatile unsigned long timersDec[TIMERDEC_NUMtdindex];
unsigned long LED1_timer_num, LED2_timer_num;
unsigned long LED1_timer_count, LED2_timer_count;
int ii_st;
char dmsg[64];

//----------------------------------------------------------------------------
void main (void);
void hi_isr(void);
void InterruptHandlerLow (void);

//----------------------------------------------------------------------------
// High priority interrupt vector
//----------------------------------------------------------------------------
#pragma code InterruptVectorHigh =  0x08
void  InterruptVectorHigh (void)
{
 	_asm
    	goto hi_isr //jump to interrupt routine
  	_endasm
}

//----------------------------------------------------------------------------
// Low priority interrupt vector
//----------------------------------------------------------------------------
#pragma code InterruptVectorLow=0x18
void InterruptVectorLow (void)
{
 	_asm
    	goto InterruptHandlerLow //jump to interrupt routine
  	_endasm
}

//----------------------------------------------------------------------------
// High priority interrupt routine
//----------------------------------------------------------------------------
#pragma code
#pragma interrupt hi_isr

void hi_isr()
{
	InterruptHandlerGSM();
	//USART1IntTasks(); //--- USART1 Int , GSM-GPRS
	USART2IntTasks(); //--- USART2 Int , PC
}
//----------------------------------------------------------------------------
// Low priority interrupt routine
//----------------------------------------------------------------------------
#pragma code
#pragma  interruptlow InterruptHandlerLow

void InterruptHandlerLow()
{
	if(INTCONbits.TMR0IF == (unsigned int)1)
	{	// TIMER0 = 1 ms !
#ifdef TEST_TIMER
//	PORTCbits.RC6 = 1;
#endif
 		for (ii_st=0;ii_st<TIMERDEC_NUMtdindex;ii_st++)
    	{
    		if (timersDec[ii_st])
    	   		--timersDec[ii_st];
   	 	}
		TMR0L = TIMER_1MS;	
    	INTCONbits.TMR0IE = 1; 
		INTCONbits.TMR0IF = 0;    
#ifdef TEST_TIMER
//	PORTCbits.RC6 = 0;
#endif
	}

}

//----------------------------------------------------------------------------
void isReset(void)
{

}
//----------------------------------------------------------------------------
void main_init(void)
{
 ADCON1 |= 0x0F;
	ADCON0 = 0;
//	ADCON1 = 0;
//	ANSELH = 0;
//	ANSEL = 0;
// portok:
/*
 if hadver == 1
	mov#	TRISA,001111b
	mov#	TRISB,00000000b
	mov#	TRISC,10010001b
	mov#	TRISD,00100000b
	mov#	TRISE,00000000b
	mov#	TRISF,00000100b
	mov#	TRISG,001100b
 endif
*/
	

//	TRISA = 0xDF;	
	TRISA = 0b11001111; 
//	LATB = 	0xEC;
	TRISB = 0x08;		//LED1,LED2.LED3 output
//	TRISC = 0xD4;
	TRISC = 0b10010001;
	TRISD = 0b00100000;
//	TRISF = 0xF5;
	TRISF = 0b00000100;
//	TRISG = 0b11001100;
#ifdef SIM300_PC1
	TRISG = 0b11001110;
	TRISC = 0b11010001;
#else
	TRISG = 0b11001110;
//	TRISG = 0b11001100;
	TRISC = 0b11010001;

#endif
	RCONbits.IPEN = 1;
	GSM_PWR = 1;		//Bekapcsolva induljon (kevesebbet v�r
//Timer 0
	INTCON2 = 0x80;              
	T0CON = 0b11000101;  
	INTCON2bits.TMR0IP	= 0; //low priority
	INTCONbits.TMR0IE	= 1;
	INTCONbits.TMR0IF	= 0;
 
	TMR0L = TIMER_1MS;	 	// 16.384 Mhz-es kvarc 1:64 Prescale value   1 ms
	TMR0H = 0;

	T0CONbits.TMR0ON  = 1;	// Timer0 start

	INTCONbits.GIEL = 1;     //low enable interrupts
	INTCONbits.GIEH = 1;   
	
	LED1_OFF
	LED3_OFF

	LED2_ON 	

	LED1_timer_num = 8;
	LED2_timer_num = 0;
}

//----------------------------------------------------------------------------
void main_executor(void)
{
	if (timersDec[LED1tdindex] == 0)
	{		
		if (LED1_timer_count)
		{
			LED1_timer_count--;
			timersDec[LED1tdindex] = 100;
		}
		else
		{
			LED1_timer_count = LED1_timer_num;
			timersDec[LED1tdindex] = 2000;			
			Flags.Bit.Led1 = 0;
		}

		if (Flags.Bit.Led1)
		{
			LED1_ON
		}
		else
		{
			LED1_OFF
		}
		Flags.Bit.Led1 = (Flags.Bit.Led1)?0:1;
	
		
		if (LED2_timer_count)
		{
			LED2_timer_count--;
		}
		else
		{
			LED2_timer_count = LED2_timer_num;			
			Flags.Bit.Led2 = 0;
		}

		if (Flags.Bit.Led2)
		{
			LED2_ON
		}
		else
		{
			LED2_OFF
		}
		Flags.Bit.Led2 = (Flags.Bit.Led2)?0:1;
	}

	if (timersDec[TESTtdindex] == 0)
	{		
		timersDec[TESTtdindex] = 500;
#ifdef GPRS_SEND_TEST
		if (TAMPER == 0)
		{
			if (Flags.Bit.Tamper == 1)
			{
				if (next_dtmf_index() != 255)
				{
					alarms.wr_index = next_dtmf_index();						
					alarms.dtmf[alarms.wr_index][0]=GPRS_ALRM;
					alarms.dtmf[alarms.wr_index][1]=1;
					alarms.dtmf[alarms.wr_index][2]=':';
					alarms.dtmf[alarms.wr_index][3]='5';
					alarms.dtmf[alarms.wr_index][4]='5';
					alarms.dtmf[alarms.wr_index][5]='5';

					alarms.dtmf[alarms.wr_index][6]='1';
					alarms.dtmf[alarms.wr_index][7]='8';

					alarms.dtmf[alarms.wr_index][8]='3';
					alarms.dtmf[alarms.wr_index][9]='1';
					alarms.dtmf[alarms.wr_index][10]='3';
					alarms.dtmf[alarms.wr_index][11]='7';

					alarms.dtmf[alarms.wr_index][12]='9';
					alarms.dtmf[alarms.wr_index][13]='9';

					alarms.dtmf[alarms.wr_index][14]='9';
					alarms.dtmf[alarms.wr_index][15]='9';
					alarms.dtmf[alarms.wr_index][16]='9';

					alarms.dtmf[alarms.wr_index][17]=0x3c;									
				}
				Flags.Bit.Tamper = 0;				
			}
		}
		else
		{
			if (Flags.Bit.Tamper == 0)
			{
				if (next_dtmf_index() != 255)
				{
					alarms.wr_index = next_dtmf_index();									
					alarms.dtmf[alarms.wr_index][0]=GPRS_ALRM;
					alarms.dtmf[alarms.wr_index][1]=2;
					alarms.dtmf[alarms.wr_index][2]=':';
					alarms.dtmf[alarms.wr_index][3]='5';
					alarms.dtmf[alarms.wr_index][4]='5';
					alarms.dtmf[alarms.wr_index][5]='5';

					alarms.dtmf[alarms.wr_index][6]='1';
					alarms.dtmf[alarms.wr_index][7]='8';

					alarms.dtmf[alarms.wr_index][8]='1';
					alarms.dtmf[alarms.wr_index][9]='1';
					alarms.dtmf[alarms.wr_index][10]='3';
					alarms.dtmf[alarms.wr_index][11]='7';

					alarms.dtmf[alarms.wr_index][12]='9';
					alarms.dtmf[alarms.wr_index][13]='9';

					alarms.dtmf[alarms.wr_index][14]='9';
					alarms.dtmf[alarms.wr_index][15]='9';
					alarms.dtmf[alarms.wr_index][16]='9';

					alarms.dtmf[alarms.wr_index][17]=0x3e;									
				}
				Flags.Bit.Tamper = 1;				
			}
		}
#endif
	}
}

//----------------------------------------------------------------------------
// Main routine
//----------------------------------------------------------------------------
void main ()
{
	int  error = 0;
	main_init();
	gsm_gprs_reset();
	LED2_OFF
	pc_init(BPS_9600);

#ifndef SIM300_PC1

	LED3_ON	
	if (slic_init())
	{
		LED1_timer_num = 2;
		LED2_timer_num = 2;		
	}
	LED3_OFF	
#endif
	
#ifndef SIM300_PC1
	LED1_ON	
	if (gsm_gprs_init(BPS_9600))
	{
		LED1_timer_num = 4;
		LED2_timer_num = 4;
		error = 1;
	timersDec[WAIT1tdindex] =  TIME_3_MIN;

		while(1)
		{
			if (timersDec[SLIC_EXEtdindex] == 0)
			{
				_asm
    			reset
  				_endasm
			}
			pc_executor();
		}
	}
	LED2_OFF	

#endif


	timersDec[TESTtdindex] = 500; 	
	timersDec[LED1tdindex] = 500; 

	LED1_timer_count = LED1_timer_num;
	LED2_timer_count = LED2_timer_num;
	Flags.Bit.Led1 = 1;
	Flags.Bit.Led2 = 1;
#ifdef NO_GPRS_FOR_VOICE_TEST
JJ
	isGSM_GPRS_NET = 1;  //KIVENNI !!!!!!
#endif

	while (1)
	{
		isReset();
		CLRWDT
		main_executor();
#ifndef SIM300_PC1
		pc_executor();
		if (error == 1)
			continue;

		slic_executor();
		gsm_gprs_executor();

#endif
	}
}


