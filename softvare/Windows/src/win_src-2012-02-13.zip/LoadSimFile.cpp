#include <vcl.h>
#include <stdio.h>
#include "SerialCom.h"
#include "LoadSimFile.h"

//------------------------
LoadSIM::LoadSIM()
{
    m_atlist1 = new TList();
    m_atlist2 = new TList();
}

//------------------------
LoadSIM::~LoadSIM()
{

    ListClear();
    if (m_atlist1)
    {
        delete m_atlist1;
        m_atlist1 = NULL;
    }
    if (m_atlist1)
    {
        delete m_atlist2;
        m_atlist2 = NULL;
    }
}

//------------------------
bool LoadSIM::Load()
{
    TCHAR       root_dir[MAX_PATH];
    char        fn[MAX_PATH];
    char        buff[MAX_PATH];
    DWORD       ret;
    char*       pChar;

    char key[10];
    int ii;

    ListClear();
    
    DWORD dwRet = GetCurrentDirectory(MAX_PATH, root_dir);

     if( dwRet)
     {
        sprintf(fn,"%s\\%s",root_dir,"SIM300.dat");
     }

    //AT_LIST1.
    for (ii = 0; ii<255; ii++)
    {
        sprintf(key,"%d",ii+1);
        ret = GetPrivateProfileString("AT_LIST1",key,"-",buff,MAX_PATH,fn);
        if (ret == 0)
            continue;

        if (buff[0] == '-')
            continue;

        pChar = new char[ret+1];
        strncpy(pChar,buff,ret);
        pChar[ret] = 0;

        m_atlist1->Add(pChar);
    }
    ret = GetPrivateProfileString("AT_LIST1","GPRS_SEND","-",buff,MAX_PATH,fn);
    if (ret == 0)
        return false;
    ret = (ret<32) ? ret : 32;
    strncpy(m_gprs_data,buff,ret);
    m_gprs_data[ret] = 0;
   // m_gprs_data[ret+1] = 0;
    m_gprs_data[ret+1] = 0x1a;
   // m_gprs_data[ret+1] = 0;
    m_gprs_len = ret + 2 ;
   //m_gprs_len = ret;



     //AT_LIST2.
    for (ii = 0; ii<255; ii++)
    {
        sprintf(key,"%d",ii+1);
        ret = GetPrivateProfileString("AT_LIST2",key,"-",buff,MAX_PATH,fn);
        if (ret == 0)
            return false;

        if (buff[0] == '-')
            break;

        pChar = new char[ret+1];
        strncpy(pChar,buff,ret);
        pChar[ret] = 0;

        m_atlist2->Add(pChar);
    }
      return true;

 }

 //------------------------
bool LoadSIM::print()
{
     int ii;
     char* atemp;

     //AT_LIST1.
     printf("========\n");
     printf("AT_LIST1:\n");
     printf("========\n");
     for (ii=0; ii<m_atlist1->Count; ii++)
     {
         atemp = (char*)m_atlist1->Items[ii];

         printf("%s\n",atemp);
     }

      //AT_LIST2.
     printf("========\n");
     printf("AT_LIST2:\n");
     printf("========\n");
     for (ii=0; ii<m_atlist2->Count; ii++)
     {
         atemp = (char*)m_atlist2->Items[ii];

         printf("%s\n",atemp);
     }
}

//------------------------
void LoadSIM::ListClear()
{
    if ((m_atlist1 == NULL) && (m_atlist2 == NULL))
        return;
     int ii;
     char* atemp;
     
     for (ii=0; ii<m_atlist1->Count; ii++)
     {
         atemp = (char*)m_atlist1->Items[ii];
         if (atemp)
            delete atemp;

     }

     m_atlist1->Clear();

     for (ii=0; ii<m_atlist2->Count; ii++)
     {
         atemp = (char*)m_atlist2->Items[ii];
          if (atemp)
            delete atemp;

     }
      m_atlist2->Clear();
}
