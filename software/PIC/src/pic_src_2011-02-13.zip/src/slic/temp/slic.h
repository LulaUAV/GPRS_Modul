//**********************************
//	Tiszai Istvan,  2011.03
//**********************************
#ifndef _SLIC
#define _SLIC

#include "defines.h"

/*
** Defines structure for configuring ring generator
*/
typedef struct {
	WORD rngx;
	WORD rngy;
	WORD roff;
	WORD rco;
	uint8 talo;
	uint8 tahi;
	uint8 tilo;
	uint8 tihi;
	uint8 ringcon;
	uint8 rtdi;
	uint16 nrtp;
} Si321x_Ring_Cfg;
/*
** Defines structure for configuring pcm
*/
typedef struct {
	uint8 pcmf;
	uint8 wbe;
	uint8 tri;
} Si321x_PCM_Cfg;

/*
** Linefeed states 
*/
enum {
LF_OPEN,
LF_FWD_ACTIVE,
LF_FWD_OHT,
LF_TIP_OPEN,
LF_RINGING,
LF_REV_ACTIVE,
LF_REV_OHT,
LF_RING_OPEN
} ;

/*
** Defines structure for configuring 1 oscillator
*/
typedef struct {
	WORD freq;
	WORD amp;
	WORD phas;
	uint8 talo;
	uint8 tahi;
	uint8 tilo;
	uint8 tihi;
} Oscillator_Cfg;


typedef struct 
{
	Oscillator_Cfg osc1;
	Oscillator_Cfg osc2;
	uint8 omode1;
	uint8 omode2;
} Si321x_Tone_Cfg; 

typedef struct {
	uint8 gain;
	uint16 digGain;
} Si321x_audioGain_Cfg;

/*
** Defines structure for configuring FSK generation
*/
typedef struct {
	WORD fsk01;
	WORD fsk10;
	WORD fsk0x; 
	WORD fsk1x;	
	WORD fsk0; 
	WORD fsk1; 
} Si321x_FSK_Cfg;

/*
** Tone Generator configuration
*/
#define OSC_TOPHONE 0x2
#define OSC_350HZ_MINUS18DBM_8KHZ	0x7b30,0x63,0
#define OSC_350HZ_MINUS18DBM_16KHZ	0x7ed0,0x31,0
#define OSC_NOTIME				0,0
#define OSC_0_5SEC				0xa0,0xf
#define OSC_0_3SEC				0x60,0x9
#define OSC_0_2SEC				0x40,0x6
#define OSC_4SEC				0x0,0x7d
#define	OSC_2SEC				0x80,0x3e
#define OSC_440HZ_MINUS18DBM_8KHZ	0x7870,0x7d,0 
#define OSC_440HZ_MINUS18DBM_16KHZ	0x7e20,0x3d,0 
#define OSC_480HZ_MINUS18DBM_8KHZ	0x7700,0x89,0
#define OSC_480HZ_MINUS18DBM_16KHZ	0x7dc0,0x43,0
#define OSC_620HZ_MINUS18DBM_8KHZ	0x7120,0xb2,0
#define OSC_620HZ_MINUS18DBM_16KHZ	0x7c40,0x57,0


extern void slic_init(void);
extern void slic_executor(void);
extern WORD ReadProSLICIndirectRegister (BYTE reg) ;
extern int WriteProSLICIndirectRegister (BYTE reg, WORD val);
extern BYTE ReadProSLICDirectRegister (BYTE reg);
extern void WriteProSLICDirectRegister (BYTE reg, BYTE val);
void slic_print_reg();
void slic_RingStart ();
void Si321x_ToneGenSetup (int preset);
void slic_PCMSetup ( int preset);
void slic_PCMTimeSlotSetup ( uint16 rxcount, uint16 txcount);
void slic_TXAudioGainSetup ( int preset);
void slic_RXAudioGainSetup ( int preset);

#endif