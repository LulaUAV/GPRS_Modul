
#include "defines.h"
#include "gprs-udp.h"

char sernum = 0;
char udp_package[UDP_END_I];
const rom char* IMEI = UDP_IMEI;

//-------------------------------------------
void clearUdpPackage(UDPMODE mode)
{
	int ii;
	for (ii=0;ii<UDP_END_I;ii++)
		udp_package[ii] = 0;
	udp_package[UDP_SYNC1_I] = UDP_SYNC1;
	udp_package[UDP_SYNC2_I] = UDP_SYNC2;
	if (mode == MESSAGEudp)
	{
		udp_package[UDP_FORMATID_I] 	= UDP_FORMATID1_0;
		udp_package[UDP_FORMATID_I+1] 	= UDP_FORMATID1_1;
	}
	for (ii=0;ii<15;ii++)
		udp_package[UDP_IMEI_I+ii] = IMEI[ii];	
}

//-------------------------------------------
char setUdpPackage_chs()
{
	int ii;
	udp_package[UDP_CHK_I] = 0;
	for (ii=0;ii<(UDP_CHK_I-UDP_FORMATID_I);ii++)
		udp_package[UDP_CHK_I] += udp_package[UDP_FORMATID_I+ii];
}

//-------------------------------------------
char* setUdpPackage_mess(char* account, char* event, char* grp, char* zone_user)
{
	int ii;
	clearUdpPackage(MESSAGEudp);
	udp_package[UDP_SERNUM_I] = sernum++;
	for (ii=0;ii<4;ii++)
		udp_package[UDP_ACCOUNT_I+ii] = account[ii];
	for (ii=0;ii<4;ii++)
		udp_package[UDP_EVENT_I+ii] = event[ii];
	for (ii=0;ii<2;ii++)
		udp_package[UDP_GROUP_I+ii] = grp[ii];
	for (ii=0;ii<2;ii++)
		udp_package[UDP_ZONE_USER_I+ii] = zone_user[ii];
	setUdpPackage_chs();
	return udp_package;
}
