//---------------------------------------------------------------------------

#include <vcl.h>
#pragma hdrstop

#include "WilAlarmMain.h"
#include "walarm.h"
#include "WilAlarmSetting.h"
//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma resource "*.dfm"
TWilAlarmM *WilAlarmM;
INI ini_st;

//---------------------------------------------------------------------------
__fastcall TWilAlarmM::TWilAlarmM(TComponent* Owner)
    : TForm(Owner)
{
    m_alive_counter = 0;
}
//---------------------------------------------------------------------------
void __fastcall TWilAlarmM::TestBtnClick(TObject *Sender)
{
    WalarmForm->Show();
}
//---------------------------------------------------------------------------
void __fastcall TWilAlarmM::ExitBtnClick(TObject *Sender)
{
    WalarmForm->Exit();
    Close();    
}
//---------------------------------------------------------------------------
void __fastcall TWilAlarmM::SettingBtnClick(TObject *Sender)
{
    WASetting->Show(); 
}
//---------------------------------------------------------------------------
void __fastcall TWilAlarmM::FormCreate(TObject *Sender)
{
    ini_st.isSerial = false;
}

//---------------------------------------------------------------------------
void __fastcall TWilAlarmM::FormShow(TObject *Sender)
{
//
  /*  if (ini_st.isSerial)
    {
       setEnable(bool en);
    } */
}

//---------------------------------------------------------------------------
void __fastcall TWilAlarmM::setEnable(bool en)
{
     TestBtn->Enabled = en;
     SettingBtn->Enabled = en;
}

//---------------------------------------------------------------------------
void __fastcall TWilAlarmM::rAlive()
{
    m_alive_counter = 0;
    setEnable(true);
}

//---------------------------------------------------------------------------
void __fastcall TWilAlarmM::Timer1Timer(TObject *Sender)
{
    WalarmForm->SOpen();
    m_alive_counter++;
    WASetting->SAlive();
    if (m_alive_counter > 5)
    {
        setEnable(false);
    }
}
//---------------------------------------------------------------------------

