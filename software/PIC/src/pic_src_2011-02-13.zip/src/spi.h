//**********************************
//	Tiszai Istvan,  2011.03
//**********************************
#ifndef _SPI
#define _SPI

extern void getsSPI1( unsigned char *rdptr, unsigned char length );
extern void putsSPI1( unsigned char *wrptr );
extern unsigned char ReadSPI1( void );
extern unsigned char WriteSPI1( unsigned char data_out );
extern void getsSPI2( unsigned char *rdptr, unsigned char length );
extern void putsSPI2( unsigned char *wrptr );
extern unsigned char ReadSPI2( void );
extern unsigned char WriteSPI2( unsigned char data_out );

#endif