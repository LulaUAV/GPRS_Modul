//**********************************
//	Tiszai Istvan,  2011.03
//**********************************
#ifndef _UTILS
#define _UTILS


//#define SCRATCH 12	//32Bits go up to 4GB + 1 Byte for \0
#define SCRATCH 6	//32Bits go up to 4GB + 1 Byte for \0
#define USE_LONG 	// %lx, %Lu and so on, else only 16 bit integer is allowed
//#define USE_OCTAL	// %o, %O Octal output. Who needs this ?
#define USE_STRING      // %s, %S Strings as parameters
#define USE_CHAR	// %c, %C Chars as parameters
#define USE_INTEGER	// %i, %I Remove this format flag. %d, %D does the same
#define USE_HEX		// %x, %X Hexadezimal output
#define USE_UPPERHEX	// %x, %X outputs A,B,C... else a,b,c...
#ifndef USE_HEX
 #undef USE_UPPERHEX    // ;)
#endif
#define USE_UPPER	// uncommenting this removes %C,%D,%I,%O,%S,%U,%X and %L..
                        // only lowercase format flags are used
#define PADDING         //SPACE and ZERO padding

extern char sdata[64];
extern void hex1toa(char t, char* res);
extern char *myStrcpy_r ( char *s1, const rom char *s2 );
extern char *myStrcpy ( char *s1, const char *s2 );
extern void mStrcat(char *s, const char *t, int max_num);
extern char *myStrcat_r(char *s, const rom char *t);
extern void mysprintf(unsigned char* buffer,const rom char  *format, ...);
extern int myStrlen_rom(const rom char* msg);
extern int myStrlen_ram(const char* msg);
extern int myStrCmp(char* msg, const rom char* cmp);

#endif