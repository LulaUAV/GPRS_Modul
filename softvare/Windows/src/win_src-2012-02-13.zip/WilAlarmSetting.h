//---------------------------------------------------------------------------

#ifndef WilAlarmSettingH
#define WilAlarmSettingH
//---------------------------------------------------------------------------
#include <Classes.hpp>
#include <Controls.hpp>
#include <StdCtrls.hpp>
#include <Forms.hpp>
#include <Buttons.hpp>

#define	DNS_IP_LEN 	17

//---------------------------------------------------------------------------
class TWASetting : public TForm
{
__published:	// IDE-managed Components
    TButton *ExitBtn;
    TGroupBox *GroupBox1;
    TLabel *APN;
    TEdit *APNEdit;
    TEdit *DomainEdit;
    TLabel *Label1;
    TBitBtn *SendAPNBtn;
    TBitBtn *SendDomainBtn;
    TLabel *Label2;
    TButton *ResetBtn;
    TLabel *Label3;
    TLabel *Label4;
    TLabel *Label5;
    TEdit *DNSPriIP1Edit;
    TLabel *Label6;
    TEdit *DNSPriIP2Edit;
    TLabel *Label7;
    TEdit *DNSPriIP3Edit;
    TEdit *DNSSecIP1Edit;
    TLabel *Label8;
    TEdit *DNSSecIP2Edit;
    TLabel *Label9;
    TEdit *DNSSecIP3Edit;
    TBitBtn *SendPriIPBtn;
    TBitBtn *SendSecIPBtn;
    TButton *DSNFactoryBtn;
    TLabel *Label10;
    TEdit *DNSPriIP4Edit;
    TLabel *Label11;
    TEdit *DNSSecIP4Edit;
    TBitBtn *GetAPNDomBtn;
    void __fastcall ExitBtnClick(TObject *Sender);
    void __fastcall SendAPNBtnClick(TObject *Sender);
    void __fastcall SendDomainBtnClick(TObject *Sender);
    void __fastcall FormClose(TObject *Sender, TCloseAction &Action);
    void __fastcall FormShow(TObject *Sender);
    void __fastcall FormCreate(TObject *Sender);
    void __fastcall ResetBtnClick(TObject *Sender);
    void __fastcall SendPriIPBtnClick(TObject *Sender);
    void __fastcall SendSecIPBtnClick(TObject *Sender);
    void __fastcall DSNFactoryBtnClick(TObject *Sender);
    void __fastcall DNSPriIP1EditKeyUp(TObject *Sender, WORD &Key,
          TShiftState Shift);
    void __fastcall DNSPriIP2EditKeyUp(TObject *Sender, WORD &Key,
          TShiftState Shift);
    void __fastcall DNSPriIP3EditKeyUp(TObject *Sender, WORD &Key,
          TShiftState Shift);
    void __fastcall DNSPriIP4EditKeyUp(TObject *Sender, WORD &Key,
          TShiftState Shift);
    void __fastcall DNSSecIP1EditKeyUp(TObject *Sender, WORD &Key,
          TShiftState Shift);
    void __fastcall DNSSecIP2EditKeyUp(TObject *Sender, WORD &Key,
          TShiftState Shift);
    void __fastcall DNSSecIP3EditKeyUp(TObject *Sender, WORD &Key,
          TShiftState Shift);
    void __fastcall DNSSecIP4EditKeyUp(TObject *Sender, WORD &Key,
          TShiftState Shift);
    void __fastcall GetAPNDomBtnClick(TObject *Sender);
private:	// User declarations
    bool  m_start;
public:		// User declarations
    __fastcall TWASetting(TComponent* Owner);
    void __fastcall setting_request(const char* msg_a);
    void __fastcall getDomain();
    void __fastcall getAPN();
    void __fastcall getDNSpri();
    void __fastcall getDNSsec();
    void __fastcall SAlive();
};
//---------------------------------------------------------------------------
extern PACKAGE TWASetting *WASetting;
//---------------------------------------------------------------------------
#endif
