//**********************************
//	Tiszai Istvan,  2011.03
//**********************************
#include <p18cxxx.h>
#include <p18f6527.h>
#include "defines.h"
#include "gsm-gprs.h"
#include "../pc/pc.h"
#include "../slic/slic.h"
#include "utils.h"
#include "eeprom.h"

//217.79.128.40 nem j�.

uint8 usart1char;
int  Rx1Length;
int prev_Rx1Length;
int  Tx1Length;

ERROR_CODE rx1_errcode;
volatile char  Rx1_Buffer[RX1_MAX_DATA_NUM+1];
//volatile char* Rx2_BufferPtr;

//int rx2_time_out;
volatile char rx1test;
volatile char  RxTx1State;

char* Rx1_BufferPtr;
char*  Tx1_BufferPtr;


char  Tx1_Buffer[TX1_MAX_DATA_LEN];


unsigned char proba=0;
int number_retries2=0;
volatile int number_retries=0;
//volatile char rx_buffer[RX_BUFFER_SIZE];
int rx_wr_index=0;
int rx_rd_index=0;
int rx_counter=0;
int rx_counter_prev=0;
// This flag is set on USART Receiver buffer overflow
unsigned char rx_buffer_overflow;

/*Control variables*******************/
unsigned char LFavail=0;//LF symbol find in buffer
int command_state=0x05;	//IDLE state 
int command_type=0;//no command is executed
int flag=0;
char gsmtemp[3];	//string, containing temperature read from GSM module
//BYTE LCDText[16+1];	//form input buffer
//unsigned char  myflag=0;
int nres;

char SIM_IME_num[16];

char isGSM_GPRS_NET;

int alive_min;
//char temper[9]={'+','C','M','T','E',':',' ','1',','};
const rom char ok[2]={'O','K'};
//char tx[32];		//GSM number representative
BYTE number_length=0;//GSM number length
unsigned char SMS_msg[17];

unsigned char MOBIL_tele_num[17];
VOICE_CALL voice;
//-------------------------
void Rx1_clear(void);
void Tx1_Send_r(const rom char* msg_a);
int InitUSART(uint16 usart_baud);
void SendUART2();
int IslNetwork();
int setSIM900_GPRS();
int setSIM900_MAIN();
//int send_to_gprs();
int send_alive_to_gprs();
void send_Alarm_to_gsm();

int waitOK(void);
int wait_OK(unsigned int ms);
void SendUART(const rom char *data);
void flush_buffer(void);
int call_voice_to_gsm();

//----------------------------------
void gsm_gprs_wait(int ms)
{
	timersDec[RX1tdindex] = ms;
	while (timersDec[RX1tdindex])CLRWDT;
}

//----------------------------------
void delay_loop()
{
	int ii = 100;
	while (--ii);
}


//----------------------------------
int gsm_gprs_init(uint16 usart_baud)
{

	int ii;
	int  ecount = 0;

// PROBA IP START
/*
	int res = 0;
	char edata[30];
	char sdata[64];
	char flag = 0;

	myStrcpy_r( Rx1_Buffer, "\n\aOK\n\a+CDNSGIP: 1,\"HAZMESTER.DYNDNS.HU\",\"84.0.127.82\"" );
	//Rx1_Buffer[rx_counter] = 0;

	if (!myStrCmp(Rx1_Buffer, "+CDNSGIP: 1"))
	{ // good
		for (flag=0,res=0;res<RX1_MAX_DATA_NUM;res++)
		{
			if (Rx1_Buffer[res] == ',')
			{
				if (flag == 0)
				{
					flag = 1;
					continue;
				}
				res += 2;
				for (flag=0;res<RX1_MAX_DATA_NUM;res++,flag++)
				{
					if ((Rx1_Buffer[res] == '\"') || (Rx1_Buffer[res] == 0))
					{
						edata[flag] = 0;
						flag = 255;
						break;
					}
					edata[flag] = Rx1_Buffer[res];
				}
			}
			if (flag == 255)
				break;
		}
	}
*/
// PROBA IP END

	isGSM_GPRS_NET = 0;

	for (ii = 0; ii<TX1_MAX_DATA_LEN; ii++)
		Tx1_Buffer[ii] = 0;

	timersDec[GSM1tdindex] = 1000;
	
	ii = InitUSART(usart_baud);
	if (ii)
	{
		DBG_1form("GSM init ERROR:%d!\r\n", ii);
	}
	else
	{
		ii = setSIM900_MAIN();
		if (ii)
		{
			DBG_1form("setSIM900_MAIN ERROR:%d!\r\n", ii);
			return ii;
		}
back:
#ifndef NO_GPRS_FOR_VOICE_TEST
		ii = setSIM900_GPRS();	
		if (ii)
		{
			DBG_1form("setSIM900_GPRS ERROR:%d!\r\n", ii);
			if (ecount>2)
			{
				return ii;
			}	
			pc_executor();
			gsm_gprs_wait(100);	
			SendUART("AT+CIPCLOSE");
			pc_executor();
			wait_OK(1000);
			SendUART("AT+CIPSHUT");
			pc_executor();
			wait_OK(1000);	
			ecount++;	
			pc_executor();		
			goto back;	
		}
		else

#endif
		{
			if (EEP_read(EEADDR_SMSTEL1, EEL_SMSTEL, MOBIL_tele_num, 1) == 0)
			{
				DBG_1form("SMS:MOBIL:%s\r\n",MOBIL_tele_num);
			}
			else
			{
				DBG_r("SMS:NINCS MOBIL SZAM!");
				MOBIL_tele_num[0] = 0;
			}
			
			DBG_r("GSM-GPRS  init READY!\r\n");
			isGSM_GPRS_NET = 1;
			nres = send_alive_to_gprs();
			if (nres)
			{
				DBG_1form("GPRS ALIVE SEND FAIL:%d\r\n",nres);
			}
			else
			{
				DBG_r("GPRS ALIVE SENDED INIT!\r\n");
			}
			timersDec[GSM1tdindex] 		= 5000;
			timersDec[GSMALIVEtdindex] 	= GPRS_ALIVE;
			alive_min = 30;
		}
	}	

	return ii;
//	return 1;
}

//----------------------------------
void gsm_gprs_reset()
{
	GSM_PWRKEY = 1;
	gsm_gprs_wait(3000);
	GSM_PWRKEY = 0;
	gsm_gprs_wait(1000);
	GSM_PWRKEY = 1;
}

/********************************************************************
 *  Interrupt
 ********************************************************************/
void USART1IntTasks(void) 
{

} //USART1IntTasks()

//-------------------------------------------------------------
// vetel kezelese 
/*
static int Rx1_handler(void)
{
//	DBG_r("USART1 receive...!\r\n");
}*/

//-------------------------------------------------------------
// A bejovo uzenet ellenorzese (kezdo karakter, lezaro karakter, 
// hossz, checksum)
char Rx1CheckMsg(int size)
{
	return NOERR_SUCCESS;
}

/**********************************************************
 * rx1 torles fg.
 **********************************************************/
void Rx1_clear(void)
{
	prev_Rx1Length = 	Rx1Length;
	Rx1Length = 0;
	Rx1_BufferPtr = Rx1_Buffer;
//	to_count = rxtest;
	rx1test = 0;
}


/*
AT
OK
AT+CMGF=1
OK
AT+CMGW="+85291234567"
> A simple demo of SMS text messaging.
+CMGW: 1
u
OK
AT+CMSS=1
+CMSS: 20

OK
*/


//-------------------------------------
// USART Receiver buffer


//----------------------------
char BusyUSART(void)
{
	return !TXSTA1bits.TRMT;
}

char DataRdyUSART(void)
	{
		if(RCSTAbits.OERR)
		{
			RCSTAbits.CREN = 0;
			RCSTAbits.CREN = 1;
		}
	  return PIR1bits.RCIF;
	}

	char ReadUSART(void)
	{
	  return RCREG;                     // Return the received data
	}
	
	char ReadUSART_INT(void)
	{
	  return RCREG;                     // Return the received data
	}

	void WriteUSART(char data)
	{
	  TXREG = data;      // Write the data byte to the USART
	}
	
	void getsUSART(char *buffer, unsigned char len)
	{
	  char i;    // Length counter
	  unsigned char data;
	
	  for(i=0;i<len;i++)  // Only retrieve len characters
	  {
	    while(!DataRdyUSART());// Wait for data to be received
	
	    data = getcUART();    // Get a character from the USART
	                           // and save in the string
	    *buffer = data;
	    buffer++;              // Increment the string pointer
	  }
	}

//===================================================================================
void putrsUSART(const rom char *data)
	{
	  do
	  {  // Transmit a byte
	    while(BusyUSART());
	   // putcUART(*data);
		TXREG = *data;
	  } while( *data++ );
	}

//===================================================================================
int InitUSART(uint16 usart_baud)
{
	int k = 0;
	int e = 0;
	TXSTA1 = 0;           // Reset USART registers to POR state
  	RCSTA1 = 0;
	BAUDCON1 	= 0; 
 	BAUDCON1bits.BRG16 = 1;
 //	RCSTA2bits.CREN = 1;
  	TXSTAbits.BRGH = 1;
  
	RCSTA1		= 0b10010110; //soros port en., vetel eng.
	TXSTA1		= 0b00100110; //8bit, adas eng. aszink.mod
	SPBRG = usart_baud;       // Write baudrate to SPBRG1
  	SPBRGH = usart_baud >> 8; // For 16-bit baud rate generation

//	SPBRG = (INSTR_FREQ+2*BAUD_RATE)/BAUD_RATE/4 - 1;

//	TXSTAbits.BRGH = 1;
//	#else	// Use the low baud rate setting
//	kk	SPBRG = (INSTR_FREQ+8*BAUD_RATE)/BAUD_RATE/16 - 1;
//	#endif	
	
	/* Enable interrupt priority */
  	RCONbits.IPEN = 1;

  	/* Make receive interrupt high priority */
  	IPR1bits.RCIP = 1;

  	/* Enable all high priority interrupts */
  	INTCONbits.GIEH = 1;

	/*Enable USART Receive interrupt*/
	PIE1bits.RC1IE=1;

//	myflag=0;
//	k=0;
	number_retries=0;


//	gsm_gprs_reset();

//	timersDec[GSM1tdindex] = 60000;
	
	DBG_r("GSM init start\r\n");

	timersDec[GSM1tdindex] = 4000;
	while (GSM_STATUS == 0)
	{
		k++;
		gsm_gprs_wait(200);
		DBG_1form("GSM STATUS:%d\r\n",k);		
		k++;
		if (k>30)
			return 1;
	}

//	SendUART("AT");
//	gsm_gprs_wait(50);


	SendUART("ATE0");	
/*	if (wait_respond(1000))
	{
		Rx1_Buffer[rx_counter] = 0;
		if (myStrCmp(Rx1_Buffer, "ATE0"))
		{
			return 2;
		}
	}
	else
	{
		return 2;
	}*/

//	gsm_gprs_wait(50);

//	gsm_gprs_wait(100);
	


	gsm_gprs_wait(100);

/*	SendUART("AT+CMEE=2");
	if (!wait_OK(1000))
		return 4;*/
	
	k = 0;
	e = 0;
	while(1)
	{
		gsm_gprs_wait(800);
		SendUART("AT+CREG?");
		if (wait_respond(1000) == 0)
		{
			DBG_1form("GSM WAITING_1:%d\r\n",k);
			k++;
			if (k>20)
				return 5;
		}
		if (!myStrCmp(Rx1_Buffer, "0,1"))
			break;

		DBG_1form("GSM WAITING_2:%d\r\n",e);
		e++;
		if (e>20)
			return 5;
	}


	gsm_gprs_wait(20);
	k=0;
	while(1)
	{
		gsm_gprs_wait(50);
		SendUART("AT+CPIN?");	
		if (wait_OK(1000))
			break;
		k++;
		if (k>5)	
			return 3;
	}
	return (0);
} 



//===================================================================================
#define WAIT_REC_ONE	10

int wait_respond(unsigned int ms)
{
	unsigned int flg = 0;
	rx_counter_prev = 0;

	while(rx_counter==0)
	{
		gsm_gprs_wait(2);
		if (flg > ms)
			return 0;
		flg++;
	}

wait_start:
	flg = 0;
	do
	{
		if (flg > WAIT_REC_ONE)
			break;
		gsm_gprs_wait(2);
		flg++;
	}
	while (rx_counter_prev == rx_counter);
	

	if (flg >= WAIT_REC_ONE)
		return 1;
	else
	{
		rx_counter_prev = rx_counter;
		goto wait_start;
	}
	return 0;
}

//----------------------------------------------------------------------------------
int wait_OK(unsigned int ms)
{
	if (wait_respond(ms) == 0)
		return 0;
	Rx1_Buffer[rx_counter] = 0;
	return (!myStrCmp(Rx1_Buffer, "OK"));
}

//===================================================================================
void  SIM_send_wait()
{
		SendUART2();
		if (wait_respond(1000) == 0)
			return;	
		Rx1_Buffer[rx_counter] = 0;
	//	DBG_m(Rx1_Buffer);
}

//===================================================================================
void InterruptHandlerGSM (void)
{
	unsigned char c;
	char status,data;
	if(PIR1bits.RC1IF)
	{
	  	data = RCREG;//_INT
	  	status=RCSTA;	
		if ((status & (FRAMING_ERROR  | DATA_OVERRUN))==0)		//| PARITY_ERROR
		{
			Rx1_Buffer[rx_wr_index]=data;
		   	if (++rx_wr_index == RX1_MAX_DATA_NUM) 
				rx_wr_index=0;
		   	if (++rx_counter == RX1_MAX_DATA_NUM)
		   	{
		      	rx_counter=0;
		      	rx_buffer_overflow=1;
		     };
		 };	
	//	/ Clear the interrupt flag /
	    PIR1bits.RC1IF = 0;
	}

}
/**
Search for LF character in UART receive buffer
*/
/*
int LFfind(void)
{
	int i=0;
	for(i=0;i<RX1_MAX_DATA_NUM;i++)
		if (Rx1_Buffer[i]==10)
			LFavail++;
	if(LFavail)
		return 1;
	else return 0;
}*/

/**
Flush buffer contents
*/
void flush_buffer(void)
{
	int i=0;
	for(i=0;i<RX1_MAX_DATA_NUM;i++)
		Rx1_Buffer[i]=0;

	rx_counter=0;
	rx_counter_prev=0;
	rx_wr_index=0;
	rx_rd_index=0;
}


unsigned char getchar_UART(unsigned long timeout_ms)
{
	char data;
	//wait given timeout
//	while (rx_counter==0)
//		gsm_gprs_wait(1);
//	if (rx_counter==0)
//		return 0;

	data=Rx1_Buffer[rx_rd_index];
	if (rx_counter>0)
	{
		if (++rx_rd_index == RX1_MAX_DATA_NUM) 
			rx_rd_index=0;
	}
	//check this	else flush_buffer();

	/* Disable all high priority interrupts */
  	INTCONbits.GIEH = 0;

	if(rx_counter>0)	
		--rx_counter;

	/* Enable all high priority interrupts */
  	INTCONbits.GIEH = 1;

	return data;
}

//----------------------------------------------
void SendUARTLF()
{	
	TXREG = 10;	//LF
	while(BusyUSART());
	TXREG = 0;	//0
	while(BusyUSART());	
}

//----------------------------------------------
void SendUARTCONST(const rom char *data)
{
	int ii;
	for(ii=0;ii<TX1_MAX_DATA_LEN;ii++)
		Tx1_Buffer[ii]=0;
	for (ii=0;data[ii];ii++)
	{
		Tx1_Buffer[ii] = data[ii];
	}
	Tx1_Buffer[ii] = 13;
	Tx1_Buffer[++ii] = 0;
 	SendUART2();

//	TXREG = 13;
//	while(BusyUSART());
}

//----------------------------------------------
void SendUARTCONST_ram(char *data)
{
	int ii;
	for(ii=0;ii<TX1_MAX_DATA_LEN;ii++)
		Tx1_Buffer[ii]=0;
	for (ii=0;data[ii];ii++)
	{
		Tx1_Buffer[ii] = data[ii];
	}
	Tx1_Buffer[ii] = 13;
	Tx1_Buffer[++ii] = 0;
 	SendUART2();

//	TXREG = 13;
//	while(BusyUSART());
}

//----------------------------------------------
void SendUART(const rom char *data)
{
	SendUARTCONST(data);
//	TXREG = 10;	//LF
//	while(BusyUSART());
//	SendUARTLF();
}

//----------------------------------------------
void SendUART_ram(char *data)
{
	SendUARTCONST_ram(data);
}

//----------------------------------------------
void SendUART2()
{
	int ee = 0;
	flush_buffer();	
	 while( Tx1_Buffer[ee]  )
  	{   
		while(BusyUSART());
	
		TXREG = Tx1_Buffer[ee];
		ee++;

  	} 
	while(BusyUSART());
//	TXREG = 0;
//	while(BusyUSART());

		return;
}

//----------------------------------------------
/*
void SendUART3(const rom char *data)
{
	flush_buffer();	
	do
  	{   
		while(BusyUSART());
		TXREG = *data;
  	} while( *data++ );

 	while(BusyUSART());
	TXREG = 26;	//<CTRL-Z>
	while(BusyUSART());
	TXREG = 13;	//<CTRL-Z>
	while(BusyUSART());
	TXREG = 10;	//<CTRL-Z>
}*/

//----------------------------------------------
int IslNetwork()
{
	int k = -1;
	while (k<3)
	{
		k++;
		SendUART("AT+CREG?");
		if (wait_respond(2000) == 0)
			continue;
		if (!myStrCmp(Rx1_Buffer, "0,1"))
			break;
	}
	if (k>=3)
	{
		isGSM_GPRS_NET = 0;
	//	LED2_OFF
		return 1;
	}
	k = -1;
	while (k<3)
	{
		k++;
		SendUART("AT+CIPSTATUS");
		if (wait_respond(2000) == 0)
		{
			continue;
		}
		else
		{
			Rx1_Buffer[rx_counter] = 0;
			if (myStrCmp(Rx1_Buffer, "CONNECT OK"))
			{
				continue;
			}
			else
				break;
		}
	}
	if (k>=3)
	{
		isGSM_GPRS_NET = 0;
		LED2_OFF
		return 2;
	}
	isGSM_GPRS_NET = 1;
//	LED2_ON	
	return 0;
}

//===================================================================================
int setSIM900_MAIN()
{
	int res = 0;

	SendUART("AT+SIDET=0,0");	
	if (!wait_OK(3000))
	{
		res = 1;
		goto smerror;
	}

	SendUART("AT+GSN");	
	if (!wait_OK(4000))
	{
		wait_OK(250);
		SendUART("AT+GSN");	
		if (!wait_OK(4000))
		{
			res = 1;
			goto smerror;
		}
	}
	Rx1_Buffer[rx_counter] = 0;
	for (res=0, nres=0; ((nres < 15) && Rx1_Buffer[res]) ;res++)
	{
		if ((Rx1_Buffer[res] >= 0x30) && (Rx1_Buffer[res] <= 0x39))
		{
			SIM_IME_num[nres] = Rx1_Buffer[res];
			nres++;
		}
	}
	
	if (nres<15)
	{
		res = 2;
		goto smerror;
	}	
	SIM_IME_num[nres] = 0;	
	DBG_m(SIM_IME_num);

	SendUART("ATX2");	
	wait_OK(1000);
	return 0;

smerror:
	return res;

}

//===================================================================================
int setSIM900_GPRS()
{
	int res = 0;
	int ii = 0;
	char edata[30];

/*
AT+CGDCONT=1,"IP","REDFRED.GR.HU"
AT+CSTT="REDFRED.GR.HU"
AT+CIICR
;AT+CIFSR
AT+CLPORT="UDP","3030"
AT+CIPSTART="UDP","195.56.111.193","53500"  
AT+CIPSTATUS
*/

	EEP_read_null_end(EEADDR_DNS_PRI, edata, 0);
	if ((edata[0] < '0') || (edata[0] > '9'))
	{
		myStrcpy_r ( edata, GPRS_DNS_PRI_IP ); 
		EEP_write((unsigned int)EEADDR_DNS_PRI, GPRS_DNS_IP_LEN, edata,1);
	}
	EEP_read_null_end(EEADDR_DNS_SEC, edata, 0);
	if ((edata[0] < '0') || (edata[0] > '9'))
	{
		myStrcpy_r ( edata, GPRS_DNS_SEC_IP ); 
		EEP_write((unsigned int)EEADDR_DNS_SEC, GPRS_DNS_IP_LEN, edata,1);
	}
	
	

flush_buffer();

#ifdef GPRS_FROM_EEPROM	
	myStrcpy_r( sdata, "AT+CGDCONT=1,\"IP\",\"" );
	EEP_read_null_end(EEADDR_APN, edata, 0);
	for (res=0;res<32;res++)
	{
 		sdata[res+19] = edata[res];
		if (edata[res] == 0)
		{
			sdata[res+19] = '"';
			sdata[res+20] = 0;    
			break;
		}	
	}
	SendUART_ram(sdata);
	DBG_1form("SET1:%s\r\n",sdata);

#else
#ifdef GPRS_HAZMESTER
//	SendUART("AT+CGDCONT=1,\"IP\",\"internet.vodafone.net\"");
	SendUART("AT+CGDCONT=1,\"IP\",\"internet\"");//t-mobile
#else
	SendUART("AT+CGDCONT=1,\"IP\",\"REDFRED.GR.HU\"");	
#endif
#endif
	if (!wait_OK(4000))
	{
		res = 3;
		goto serror;
	}

	SendUART("AT+CMGF=1");	
	if (!wait_OK(3000))
	{
		res = 12;
		goto serror;
	}

	res=0;
//	while(1)
//	{
//		gsm_gprs_wait(200);

#ifdef GPRS_FROM_EEPROM	
	myStrcpy_r( sdata, "AT+CSTT=\"" );
	EEP_read_null_end(EEADDR_APN, edata, 0);
	for (res=0;res<32;res++)
	{
 		sdata[res+9] = edata[res];
		if (edata[res] == 0)
		{
			sdata[res+9] = '"';
			sdata[res+10] = 0;    
			break;
		}	
	}
	DBG_1form("SET2:%s\r\n",sdata);
	res = 0;
	while(1)
	{
		gsm_gprs_wait(200);
		SendUART_ram(sdata);
#else
#ifdef GPRS_HAZMESTER
		SendUART("AT+CSTT=\"internet\""); //t-mobile
	//	SendUART("AT+CSTT=\"internet.vodafone.net\"");
#else
		SendUART("AT+CSTT=\"REDFRED.GR.HU\"");
#endif
#endif
		if (wait_OK(7000))
			break;
		if (res>3)
		{	
			res = 4;
			goto serror;
		}
	//	DBG_1form("GPRS WAITING:%d\r\n",res);
		res++;
		gsm_gprs_wait(1000);
	}
	res = 0;

	SendUART("AT+CIICR");	
	if (!wait_OK(3000))
	{
		res = 5;
		goto serror;
	}

	SendUART("AT+CIPSTATUS");
	if (wait_respond(3000))
	{
		Rx1_Buffer[rx_counter] = 0;
		if (myStrCmp(Rx1_Buffer, "STATE: IP GPRSACT"))
		{
			res = 6;
			goto serror;
		}
	}
	else
	{
		res = 6;
		goto serror;
	}

	SendUART("AT+CIFSR");
	if (wait_respond(3000))
	{
		Rx1_Buffer[rx_counter] = 0;
		DBG_m(Rx1_Buffer);
	}
	else
	{
		res = 7;
		goto serror;
	}

	SendUART("AT+CLPORT=\"UDP\",\"3030\"");	
	if (!wait_OK(1000))
	{
		res = 8;
		goto serror;
	}

/*	SendUART("AT+CDNSCFG=\"211.136.18.71\"");
	if (!wait_OK(2000))
	{
		res = 15;
		goto serror;
	}*/	

/*	SendUART("AT+CDNSORIP=1");
	if (!wait_OK(2000))
	{
		res = 16;
		goto serror;
	}
*/
#ifdef GPRS_FROM_EEPROM	

	EEP_read_null_end(EEADDR_SZERVIP, edata, 0);
	res = 0;
	while (edata[res])
    {
		if (((edata[res] >= '0') && (edata[res] <= '9')) || (edata[res] == '.'))
		{
			res++;
			continue; 	// IP cim.
		}
		res = 0xff; 		// DNS
		break;
    }
	
	if (res == 0xff)
	{ // DNS 
		myStrcpy_r( sdata, "AT+CDNSCFG=\"" );
		EEP_read_null_end(EEADDR_DNS_PRI, edata, 0);
		if ((edata[0] >= '0') && (edata[0] <= '9'))
		{
			for (res=0;(res<GPRS_DNS_IP_LEN && edata[res]);res++)
			{
				sdata[res+12] = edata[res];
			}
			sdata[res+12] = '"'; 
			EEP_read_null_end(EEADDR_DNS_SEC, edata, 0);
			if ((edata[0] >= '0') && (edata[0] <= '9'))
			{
				sdata[res+13] = ','; 
				sdata[res+14] = '"'; 
				for (ii=0;(ii<GPRS_DNS_IP_LEN && edata[ii]);ii++)
				{
					sdata[res+ii+15] = edata[ii];
				}
				sdata[res+ii+15] = '"'; 
				sdata[res+ii+16] = 0; 
			}
		}

		// Telenor DNS: "217.79.128.40","217.79.128.45"
	//	SendUART("AT+CDNSCFG=\"211.136.18.71\"");
	//	SendUART("AT+CDNSCFG=\"217.79.128.40\",\"217.79.128.45\"");
		DBG_1form("DNS server: %s\r\n",sdata);
		SendUART_ram(sdata);
		if (!wait_OK(3000))
		{
			res = 15;
			DBG_r("DNS server:ERROR\r\n");
			goto serror;
		}
	
		//DBG_r("DNS server:211.136.18.71\n\r");
		//DBG_r("DNS server:217.79.128.40, 217.79.128.45\n\r");

		myStrcpy_r( sdata, "AT+CDNSGIP=\"" );
		EEP_read_null_end(EEADDR_SZERVIP, edata, 0);
		for (res=0;res<24;res++)
		{
 			sdata[res+12] = edata[res];
			if (edata[res] == 0)
			{
				sdata[res+12] = '"';
				sdata[res+13] = 0;
				sdata[res+14] = 0;
				break;
			}
		}
		DBG_1form("SET_DNS:%s\r\n",sdata);
		SendUART_ram(sdata);

		if (wait_OK(3000))
		{
			flush_buffer();	
			if (!wait_respond(5000))
			{
				res = 13;
				goto serror;
			}
		}
		else
		{
			res = 13;
			goto serror;
		}
		Rx1_Buffer[rx_counter] = 0;
		DBG_m(Rx1_Buffer);
		if (!myStrCmp(Rx1_Buffer, "+CDNSGIP: 1"))
		{ // good
			for (flag=0,res=0;res<RX1_MAX_DATA_NUM;res++)
			{
				if (Rx1_Buffer[res] == ',')
				{
					if (flag == 0)
					{
						flag = 1;
						continue;
					}
					res += 2;
					for (flag=0;res<RX1_MAX_DATA_NUM;res++,flag++)
					{
						if ((Rx1_Buffer[res] == '\"') || (Rx1_Buffer[res] == 0))
						{
							edata[flag] = 0;
							flag = 255;
							break;
						}
						edata[flag] = Rx1_Buffer[res];
					}
				}
				if (flag == 255)
					break;
				}
		}
		else
		{
			res = 14;
			goto serror;
		}
	}
	else
	{
		DBG_1form("SET_IP:%s\r\n",edata);
	}



// DNS->IP
	//	myStrcpy_r( Rx1_Buffer, "\n\aOK\n\a+CDNSGIP: 1,\"HAZMESTER.DYNDNS.HU\",\"84.0.127.82\"" );
	//Rx1_Buffer[rx_counter] = 0;
/*
	if (!myStrCmp(Rx1_Buffer, "+CDNSGIP: 1"))
	{ // good
		for (flag=0,res=0;res<RX1_MAX_DATA_NUM;res++)
		{
			if (Rx1_Buffer[res] == ',')
			{
				if (flag == 0)
				{
					flag = 1;
					continue;
				}
				res += 2;
				for (flag=0;res<RX1_MAX_DATA_NUM;res++,flag++)
				{
					if ((Rx1_Buffer[res] == '\"') || (Rx1_Buffer[res] == 0))
					{
						edata[flag] = 0;
						flag = 255;
						break;
					}
					edata[flag] = Rx1_Buffer[res];
				}
			}
			if (flag == 255)
				break;
		}
	}
	else
	{
		res = 14;
		goto serror;
	}
*/



	myStrcpy_r( sdata, "AT+CIPSTART=\"UDP\",\"" );
	for (res=0;res<24;res++)
	{
 		sdata[res+19] = edata[res];
		if (edata[res] == 0)
		{
			sdata[res+19] = '"';
			sdata[res+20] = ',';
			sdata[res+21] = '"';
			sdata[res+22] = '5';   
			sdata[res+23] = '3';
			sdata[res+24] = '5';
			sdata[res+25] = '0'; 
			sdata[res+26] = '0'; 
			sdata[res+27] = '"'; 
			sdata[res+28] = 0; 
			break;
		}	
	}
	DBG_1form("SET3:%s\r\n",sdata);
	SendUART_ram(sdata);

	if (!wait_OK(3000))
	{
		res = 11;
		goto serror;
	}
#else

#ifdef GPRS_HAZMESTER
	SendUART("AT+CIPSTART=\"UDP\",\"hazmester.dyndns.org\",\"53500\"");
#else
	SendUART("AT+CIPSTART=\"UDP\",\"195.56.111.193\",\"53500\"");
#endif	
#endif
	if (wait_respond(3000))
	{
		Rx1_Buffer[rx_counter] = 0;
		if (myStrCmp(Rx1_Buffer, "CONNECT OK"))
		{
			res = 9;
			goto serror;
		}
	}
	else
	{
		res = 9;
		goto serror;
	}

	SendUART("AT+CIPSTATUS");
	if (wait_respond(3000))
	{
		Rx1_Buffer[rx_counter] = 0;
		if (myStrCmp(Rx1_Buffer, "CONNECT OK"))
		{
			res = 10;
			goto serror;
		}
	}
	else
	{
		res = 10;
		goto serror;
	}

	return 0;
serror:
	//	DBG_1form("setSIM300 ERROR:%d\r\n",res);
/*
	1=AT+CIPCLOSE
	2=AT+CIPSHUT
*/
	gsm_gprs_wait(200);
	SendUART("AT+CIPCLOSE");
	gsm_gprs_wait(200);
	SendUART("AT+CIPSHUT");
	gsm_gprs_wait(200);
	return res;
}


//----------------------------------------------
int send_to_gprs(char cmd, char* mess, int mess_len)
{
	int ii;
	SendUARTCONST("AT+CIPSEND");
	if (wait_respond(1000))
	{
		Rx1_Buffer[rx_counter] = 0;
		if (myStrCmp(Rx1_Buffer, ">"))
		{
			TXREG = 26;	//<CTRL-Z>
			while(BusyUSART());
			return 2;
		}
		gsm_gprs_wait(500);
		for (ii=0;ii<15;ii++)
		{
			Tx1_Buffer[ii] = SIM_IME_num[ii];
		}
		Tx1_Buffer[ii] 		= '9';
		Tx1_Buffer[++ii] 	= cmd;
		if (mess && mess_len)
		{
			ii++;
			for (nres=0; nres<mess_len; ii++,nres++)
			{
				Tx1_Buffer[ii] = mess[nres];
			}
		}
		Tx1_Buffer[++ii] 	= 0;
		SendUART2();
		TXREG = 26;	//<CTRL-Z>
		while(BusyUSART());
		if (wait_respond(1000) == 0)
		{
			TXREG = 26;	//<CTRL-Z>
			while(BusyUSART());
			return 3;
		}
		Rx1_Buffer[rx_counter] = 0;
		if (myStrCmp(Rx1_Buffer, "SEND OK"))
		{
			TXREG = 26;	//<CTRL-Z>
			while(BusyUSART());
			return 4;
		}
	}
	else
		return 1;
	return 0;
}

//----------------------------------------------
int send_INIT_to_gprs(char* init)
{
	if (isGSM_GPRS_NET == 0)
		return 10;
	
	nres = send_to_gprs('1', init, 8);
	if (nres)
	{
		DBG_1form("INIT sended ERROR:%d!\r\n", nres);	
	}
	else
	{
		DBG_r("INIT sended");
	}
	return 	nres;
}

//----------------------------------------------
int send_alive_to_gprs()
{
	if (isGSM_GPRS_NET == 0)
		return 10;
	return send_to_gprs('0', NULL, 0);
}

//----------------------------------------------
int send_alarm_to_gprs(char cmd, char* alarm, int alarm_len)
{
	if (isGSM_GPRS_NET == 0)
		return 10;
	LED2_ON	
	nres = send_to_gprs(cmd, alarm, alarm_len);
	if (nres == 0)
	{
	//	DBG_1form("ALARM sended:'%s'\r\n",alarm);
	}
	LED2_OFF	
	return 	nres;	
}

//----------------------------------
unsigned char send_Alarm_index()
{
	unsigned char i, cvalue  = 255;
	unsigned char    iindex = 255;
/* // teszt
	alarms.dtmf[1][0] = GPRS_ALRM;
	alarms.dtmf[1][1] = 5;
	alarms.dtmf[MAX_ALARM_NUM-1][0] = GPRS_ALRM;
	alarms.dtmf[MAX_ALARM_NUM-1][1] = 255;
*/
	for (i=0;i<MAX_ALARM_NUM;i++)
	{
		if (alarms.dtmf[i][0]  != NONE_ALRM)
		{
			if (iindex == 255)
				iindex = i;
			if ((unsigned char)alarms.dtmf[i][1] < cvalue)
			{
				cvalue = (unsigned char)alarms.dtmf[i][1];
				iindex = i;
			}
		}
	}
	return iindex;
}

//----------------------------------
void send_Alarm_to_gsm()
{
	nres = (int)send_Alarm_index();
	if (nres != 255)
	{
		alarms.rd_index = nres;
		if (alarms.dtmf[alarms.rd_index][0] == GPRS_ALRM)
		{ //GPRS
			nres = send_alarm_to_gprs(55, &alarms.dtmf[alarms.rd_index][2] ,16);
			if (nres)
			{ //bad
				DBG_1form("GPRS_ALRM ERROR:%d!\r\n", nres);
				return;		
			}
			else
			{ //good
				DBG_1form("GPRS_ALRM:'%s'\r\n",&alarms.dtmf[alarms.rd_index][2]);		
			}
		}
		else
		if (alarms.dtmf[alarms.rd_index][0] == SMS_ALRM) 
		{ //SMS	
			if (MOBIL_tele_num[0])
			{
				nres = EEP_read_table(&alarms.dtmf[alarms.rd_index][7], SMS_msg);
				if (nres)
				{ //bad
					DBG_1form("SMS_ALRM1 ERROR:%d!\r\n", nres);
				}
				else
				{ //good		
					nres = send_sms(MOBIL_tele_num, SMS_msg, 2000);
					if (nres)
					{ //bad
						DBG_1form("SMS_ALRM2 ERROR:%d!\r\n", nres);
					}
					else
					{
						DBG_1form("SMS:'%s'\r\n",SMS_msg);
					}
				}
			}	
		}
		else
		if (alarms.dtmf[alarms.rd_index][0] == VOICE_ALRM)
		{ //VOICE
			alarms.dtmf[alarms.rd_index][0]  = NONE_ALRM;
		}
		alarms.dtmf[alarms.rd_index][0]  = NONE_ALRM;
		alarms.dtmf[alarms.rd_index][1]  = 0;
	}	
/*	if  (alarms.rd_index < MAX_ALARM_NUM)
	{
		if (alarms.dtmf[alarms.rd_index][0] == GPRS_ALRM)
		{ //GPRS
			nres = send_alarm_to_gprs(55, &alarms.dtmf[alarms.rd_index][1] ,16);
			if (nres)
			{ //bad
				DBG_1form("GPRS_ALRM ERROR:%d!\r\n", nres);
				return;		
			}
			else
			{ //good
				DBG_1form("GPRS_ALRM:'%s'\r\n",&alarms.dtmf[alarms.rd_index][1]);
			//	alarms.dtmf[alarms.rd_index][16] = 0;
				alarms.dtmf[alarms.rd_index][1]  = 0;
				alarms.dtmf[alarms.rd_index][0]  = NONE_ALRM;
			}
		}
		else
		if (alarms.dtmf[alarms.rd_index][0] == SMS_ALRM) 
		{ //SMS			
			if (MOBIL_tele_num[0])
			{
				nres = EEP_read_table(&alarms.dtmf[alarms.rd_index][6], SMS_msg);
				if (nres)
				{ //bad
					DBG_1form("SMS_ALRM1 ERROR:%d!\r\n", nres);
				}
				else
				{ //good		
					nres = send_sms(MOBIL_tele_num, SMS_msg, 2000);
					if (nres)
					{ //bad
						DBG_1form("SMS_ALRM2 ERROR:%d!\r\n", nres);
					}
					else
					{
						DBG_1form("SMS:'%s'\r\n",SMS_msg);
					}
				}
			}
			alarms.dtmf[alarms.rd_index][1]  = 0;
			alarms.dtmf[alarms.rd_index][0]  = NONE_ALRM;
		}
		else
		if (alarms.dtmf[alarms.rd_index][0] == VOICE_ALRM)
		{ //VOICE
			alarms.dtmf[alarms.rd_index][0]  = NONE_ALRM;
		}

		for (;alarms.rd_index < MAX_ALARM_NUM;alarms.rd_index++)
		{
			//if (alarms.dtmf[alarms.rd_index][15])
			if (alarms.dtmf[alarms.rd_index][0] != NONE_ALRM)
				break;
		}
		if (alarms.rd_index == MAX_ALARM_NUM)
			alarms.rd_index =  0;		
	}	*/
}

//----------------------------------------------
int send_CID_to_gprs(char* cid)
{
	if (isGSM_GPRS_NET == 0)
		return 10;
	nres = send_to_gprs('7', cid, 4);
	if (nres)
	{
		DBG_1form("CID sended ERROR:%d!\r\n", nres);	
	}
	else
	{
		DBG_r("CID sended");
	}
	return 	nres;
}

//----------------------------------------------
/*
int send_GPRS_to_gprs(char cmd)
{
}*/

//----------------------------------------------
/**********************************************
 VOICE hivas resz
***********************************************/
/*AT+CLCC  N�zz�k a h�v�s st�tusz�t...
;ha a 3. szam = 2, akkor prob�lja h�vni. 
;AT+CLCC
;+CLCC: 1,0,2,0,0,"06304155970",129,"Balu"
;
;ha a 3. szam = 3, akkor kics�r�g.
;AT+CLCC
;+CLCC: 1,0,3,0,0,"06304155970",129,"Balu"
;
;
;ha a 3. szam =0, akkor felv�ve a sz�m �s akt�v.
;OK
;AT+CLCC
;+CLCC: 1,0,0,0,0,"06304155970",129,"Balu"
;
;
;ha nincs folyamatban h�v�s
;AT+CLCC
;OK
*/

//--------------------
int call_voice_to_gsm()
{ // ATD

	for (nres = 0; nres<32; nres++)
	{
		if (nres < 24)
		{
			if (voice.telnum[nres] == ':')
				voice.telnum[nres] = '0';
		}	
		sdata[nres] = 0;
	
	}
//	DBG_1form("Voice telenum:%s\r\n", voice.telnum);
	myStrcpy_r( sdata, "ATD" );
	mStrcat(sdata,voice.telnum,24);
	DBG_1form("Voice telenum:%s\r\n", sdata);
	nres = 0;
	SendUART_ram(sdata);
	if (!wait_respond(10000))
		nres = 1;	
	Rx1_Buffer[rx_counter] = 0;
	DBG_m(Rx1_Buffer);
	return nres;
}

//--------------------
void gsm_onhook()
{ //ATH
	SendUART("ATH");	
	wait_OK(1000);
}

//--------------------
int gs_voice_state_ask()
{ // CLCC
	SendUART("AT+CLCC");
	if (wait_OK(2000))
	{
		if (!wait_respond(1000))
		{
			return 1;
		}	
		if (rx_counter == 0)
			return 1;
		Rx1_Buffer[rx_counter] = 0;
		DBG_m(Rx1_Buffer);
		if (myStrCmp(Rx1_Buffer, "+CLCC"))
			return 1;	
	}
	else
		return 1;
	return 0;
}

/**
Send SMS message to number entered in HTML page
*/
int send_sms(unsigned  char* number, unsigned char* message, unsigned int timeout)
{
	int ii;
//	int tmt=timeout;
	Tx1_Buffer[0]='A';
	Tx1_Buffer[1]='T';
	Tx1_Buffer[2]='+';
	Tx1_Buffer[3]='C';
	Tx1_Buffer[4]='M';
	Tx1_Buffer[5]='G';
	Tx1_Buffer[6]='S';
	Tx1_Buffer[7]='=';
	Tx1_Buffer[8]='"';
	Tx1_Buffer[9]='+';
	for (ii=0;*number;ii++,number++)
	{
		Tx1_Buffer[ii+10] = *number;
	}

	Tx1_Buffer[ii+10]='"';
	Tx1_Buffer[ii+11]=13;
	Tx1_Buffer[ii+12]=10;
	Tx1_Buffer[ii+13]='\0';
	SendUART2();

	if (wait_respond(timeout) == 0)
		return 1;

	if (myStrCmp(Rx1_Buffer, ">"))
	{
	//	gsm_gprs_wait(2000);
		TXREG = 26;	//<CTRL-Z>
		while(BusyUSART());
		return 2;
	}
	ii=0;
	Tx1_Buffer[ii++] = 'W';
	Tx1_Buffer[ii++] = 'I';
	Tx1_Buffer[ii++] = 'L';
	Tx1_Buffer[ii++] = 'A';
	Tx1_Buffer[ii++] = 'L';
	Tx1_Buffer[ii++] = 'A';
	Tx1_Buffer[ii++] = 'R';
	Tx1_Buffer[ii++] = 'M';
	Tx1_Buffer[ii++] = ':';
	Tx1_Buffer[ii++] = 0xd;

	for (;*message;ii++,message++)
	{
		Tx1_Buffer[ii] = *message;
	}

	Tx1_Buffer[ii] 	= 0;
	SendUART2();
	TXREG = 26;	//<CTRL-Z>
	while(BusyUSART());

//	SendUART3(message);

	if (!wait_OK(timeout))
//	if (wait_respond(timeout) == 0)
	{
		TXREG = 26;	//<CTRL-Z>
		while(BusyUSART());
		return 3;
	}

/*	Rx1_Buffer[rx_counter] = 0;
	if (myStrCmp(Rx1_Buffer, "SEND OK"))
	{
		TXREG = 26;	//<CTRL-Z>
		while(BusyUSART());
		return 4;
	}*/

	return 0;
}

//----------------------------------
//  GSM EXEcutor
//----------------------------------
void gsm_gprs_executor(void)
{
	static int error_count = 0;

	if (timersDec[GSM1tdindex] == 0)
	{
		if (voice.state != NONE_VOICE)
		{ // telefon hivas resz
		//	DBG_r("G_V1!\r\n");
			timersDec[GSM1tdindex] = GSM_VOICE2;
			if (voice.state == CALL_SLIC_VOICE)
			{
			//	DBG_r("G_V2!\r\n");
				nres = call_voice_to_gsm();
				if (nres)
				{
					DBG_1form("VOICE FAIL:%d\r\n",nres);
onhook:
	DBG_r("H111!\r\n");
					slic_onhook();
					gsm_onhook();
					voice.state = NONE_VOICE;
					timersDec[GSM1tdindex] = GPRS_ALARM;			
					return;		
				}
				voice.state = ACTIVE_VOICE;
			}
			else
			if (voice.state == ACTIVE_VOICE)
			{
				if (gs_voice_state_ask())
				{
					 goto onhook;
				}
			}
			else
			if (voice.state == HOOKON_SLIC_VOICE)
			{
				gsm_onhook();
				voice.state = NONE_VOICE;
				timersDec[GSM1tdindex] = GPRS_ALARM;
			}
			return;
		}
		else
		{ // alarm kuldes resz
			send_Alarm_to_gsm();				
			timersDec[GSM1tdindex] = GPRS_ALARM;
		}
	}

	return;

	if (timersDec[GSM_NETWORKtdindex] == 0)
	{
		timersDec[GSM_NETWORKtdindex] = GSM_NETWORK_DEFAULT;
		nres=IslNetwork();
		error_count++;
		if ((nres == 1) || (nres == 2))
		{
			gsm_gprs_wait(200);
			SendUART("AT+CIPCLOSE");
			gsm_gprs_wait(200);
			SendUART("AT+CIPSHUT");
			gsm_gprs_wait(200);
		}
		switch (nres)
		{
			case 1:
			{			
				gsm_gprs_reset();
				nres = gsm_gprs_init(BPS_9600);
				if (nres)
				{				
					DBG_1form("GSM FAIL:%d\r\n",nres);
					timersDec[GSM_NETWORKtdindex] = GSM_NETWORK_ERROR;
					if (error_count>4)
					{
						 _asm
    						goto 0 //soft reset
  						_endasm
					}
					return;
				}
				break;
			}
			case 2:
			{
				nres = setSIM900_GPRS();
				if (nres)
				{				
					DBG_1form("GPRS FAIL:%d\r\n",nres);
					timersDec[GSM_NETWORKtdindex] = GSM_NETWORK_ERROR;
					if (error_count>4)
					{
						 _asm
    						goto 0 //soft reset
  						_endasm
					}
					return;
				}
				break;
			}
		/*	default:
			{
				error count = 0;
				break;
			}*/
		}
		error_count = 0;		
	}

	if (timersDec[GSMALIVEtdindex] == 0)
	{
		alive_min++;
		timersDec[GSMALIVEtdindex] = GPRS_ALIVE;
	}

	if (alive_min >= 60)
	{
		nres = send_alive_to_gprs();
		if (nres)
		{
			DBG_1form("GPRS ALIVE SEND FAIL:%d\r\n",nres);
			alive_min = 59; 
			
		}
		else
		{
			DBG_r("GPRS ALIVE SENDED!");
			alive_min = 0; 
		}
	}	
}