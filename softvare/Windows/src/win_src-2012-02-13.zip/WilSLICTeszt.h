//---------------------------------------------------------------------------

#ifndef WilSLICTesztH
#define WilSLICTesztH
//---------------------------------------------------------------------------
#include <Classes.hpp>
#include <Controls.hpp>
#include <StdCtrls.hpp>
#include <Forms.hpp>
#include <Buttons.hpp>
//---------------------------------------------------------------------------
class TFormSLIC : public TForm
{
__published:	// IDE-managed Components
    TMemo *Info;
    TButton *ExitBtn;
    TGroupBox *GroupBox1;
    TLabel *Label1;
    TEdit *DRWrAddrEdit;
    TLabel *Label2;
    TEdit *DRWrDataEdit;
    TLabel *Label3;
    TLabel *Label4;
    TEdit *DRRdAddrEdit;
    TLabel *Label5;
    TBitBtn *DRWrSendBtn;
    TBitBtn *DRRdSendBtn;
    TGroupBox *GroupBox2;
    TLabel *Label6;
    TLabel *Label7;
    TLabel *Label8;
    TLabel *Label9;
    TLabel *Label10;
    TEdit *IDRWrAddrEdit;
    TEdit *IDRWrDataEdit;
    TEdit *IDRRdAddrEdit;
    TBitBtn *IDRWrSendBtn;
    TBitBtn *IDRRdSendBtn;
    void __fastcall ExitBtnClick(TObject *Sender);
    void __fastcall DRWrSendBtnClick(TObject *Sender);
    void __fastcall DRRdSendBtnClick(TObject *Sender);
    void __fastcall IDRWrSendBtnClick(TObject *Sender);
    void __fastcall IDRRdSendBtnClick(TObject *Sender);
private:	// User declarations
    void __fastcall WriteProSLICDirectRegister (char reg, char val);
    char __fastcall  ReadProSLICDirectRegister (char reg);
    short __fastcall  ReadProSLICIndirectRegister (char reg);
    void __fastcall WriteProSLICIndirectRegister (char reg, short val);
public:		// User declarations
    __fastcall TFormSLIC(TComponent* Owner);
};
//---------------------------------------------------------------------------
extern PACKAGE TFormSLIC *FormSLIC;
//---------------------------------------------------------------------------
#endif
