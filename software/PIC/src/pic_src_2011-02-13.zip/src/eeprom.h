//**********************************
//	Tiszai Istvan,  2011.06
//**********************************
#ifndef _EEPROM
#define _EEPROM

//EEPROM kiosztas
/*megnevezes, 		cim
verzio				0     	// l=3
eszkoz azonosito	3 		// l=3		
Eletjel 			6		// l=3	masodpercben , minimum 600 sec.
SMS tel.szam 1		9		// l=12
SMS tel.szam 2		21		// l=12
SMS tel.szam akzive	33		// 0= 1 aktiv, 1= 2 aktiv
Szerver Ip/domain	35		// l=25
APN					60		// l=32
DNS primary			92		// l=18
DNS secundary		110		// l=18

alarm tabla			256
alarm num			256		// l=3, max. 32 db
alarm 1. cid		259		// l=5
alarm 1. msg		264		// l=17	

alarm 2. cid		281		// l=5
alarm 2. msg		286		// l=17	

*/

#define 	EEADDR_VERZIO	0
#define 	EEADDR_AZON		EEADDR_VERZIO + 3
#define 	EEADDR_ELETJEL	EEADDR_AZON + 3
#define 	EEADDR_SMSTEL1	EEADDR_ELETJEL + 3
#define 	EEADDR_SMSTEL2	EEADDR_SMSTEL1 + 12
#define 	EEADDR_SMSTELA	EEADDR_SMSTEL2 + 12
#define 	EEADDR_SZERVIP	EEADDR_SMSTELA + 2
#define 	EEADDR_APN		EEADDR_SZERVIP + 25
#define 	EEADDR_DNS_PRI	EEADDR_APN + 32
#define 	EEADDR_DNS_SEC	EEADDR_DNS_PRI + 18

#define 	EEADDR_ALR_TNUM	256
#define 	EEADDR_ALR_TCID 259
#define 	EEADDR_ALR_TMSG 264


// len chs nelkul
#define EEL_VERZIO		2
#define EEL_AZON		2
#define EEL_ELETJEL		2
#define EEL_SMSTEL		12	
#define EEL_SZERVIP		18		

#define EEL_TABLE_NUM		2	
#define EEL_TABLE_CID		4
#define EEL_TABLE_MSG		16


#define EEL_TABLE_OFFSET	22		//chs benne van.

extern int EEP_read(unsigned int e_add, unsigned int e_len, unsigned char* data, char chs_mode);
extern int EEP_read_null_end(unsigned int e_add, unsigned char* data, char chs_mode);
extern int EEP_read_table(unsigned char* cid, unsigned char* ddata);
extern int EEP_write(unsigned int e_add, unsigned char e_len, unsigned char* sdata, char chs_mode);

#endif