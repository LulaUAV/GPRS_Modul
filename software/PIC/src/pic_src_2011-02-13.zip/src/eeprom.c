#include <p18cxxx.h>
#include <p18f6527.h>
#include "eeprom.h"

/*************************************************************
 * EEPROM write. 
 *************************************************************/
void EEP_write_b( unsigned int badd,unsigned char bdata )
{
int ii=0;
	EEADRH = (badd >> 8) & 0x03;
	EEADR = (badd & 0x0ff);
	EEDATA = bdata;
  	EECON1bits.EEPGD = 0;
	EECON1bits.CFGS = 0;
	EECON1bits.WREN = 1;
	INTCONbits.GIE = 0;
	EECON2 = 0x55;
	EECON2 = 0xAA;
	EECON1bits.WR = 1;
	while(EECON1bits.WR);		
	INTCONbits.GIE = 1;
	EECON1bits.WREN = 0;
	while(ii>20)
	{
		ii++;
	}
}

/*************************************************************
 * EEPROM read. 
 *************************************************************/
unsigned char EEP_read_b( unsigned int badd )
{
	EEADRH = (badd >> 8) & 0x03;
	EEADR = (badd & 0x0ff);
  	EECON1bits.CFGS = 0;
	EECON1bits.EEPGD = 0;
	EECON1bits.RD = 1;
	return ( EEDATA );             
}

/*************************************************************
 * EEPROM read in init. 
 *************************************************************/
void EEP_read_init()
{
}


/*************************************************************
 * EEPROM read data. 
 *************************************************************/
int EEP_read(unsigned int e_add, unsigned int e_len, unsigned char* data, char chs_mode)
{ // e_len hossza chs nelkul!
	unsigned int ii;
	unsigned char chs = 0, temp;
	if (data && e_len)
	{
		for (ii=0; ii<e_len; ii++, data++)
		{
			*data = EEP_read_b( e_add + ii );
			temp = *data;
			if (chs_mode)
				chs += *data;
		}
		if (chs_mode)
		{
			if (chs == EEP_read_b( e_add + ii ))
				return 0;
		}
		else
			return 0;
	}
	return 1;
}

/*************************************************************
 * EEPROM read data. 
 *************************************************************/
int EEP_read_null_end(unsigned int e_add, unsigned char* data, char chs_mode)
{ // e_len hossza chs nelkul!
	unsigned int ii;
	unsigned char chs = 0, temp;
    int res = 1;
	if (data)
	{
		INTCONbits.GIEL = 0;     
		INTCONbits.GIEH = 0; 
	//	*data = 0x30;
		for (ii=0; ii<24; ii++)
		{
			data[ii] = EEP_read_b( e_add + ii );
			temp = data[ii];
			if (chs_mode)
				chs += data[ii];
		}
		if (chs_mode)
		{
			if (chs == EEP_read_b( e_add + ii ))
				res = 0;
		}
		else
			res = 0;
		INTCONbits.GIEL = 1;     
		INTCONbits.GIEH = 1; 
	}
	return res;
}

/*************************************************************
 * EEPROM write data. 
 *************************************************************/
int EEP_write(unsigned int e_add, unsigned char e_len, unsigned char* sdata, char chs_mode)
{ // e_len hossza chs nelkul!
	unsigned int ii;
	unsigned char chs = 0;
	unsigned char* psTemp = sdata;
	int res = 0;
	
	if (sdata && e_len)
	{
		INTCONbits.GIEL = 0;     
		INTCONbits.GIEH = 0; 
		for (ii=0; ii<e_len; ii++)
		{
			EEP_write_b( e_add + ii, sdata[ii] );
			if (chs_mode)
				chs += sdata[ii];
		}
		if (chs_mode)
		{
			EEP_write_b( e_add + ii, chs );
			res = 1; 				
		}
		else
			res = 1;
		INTCONbits.GIEL = 1;     
		INTCONbits.GIEH = 1;
	}
	return res;
}

/*************************************************************
 * EEPROM reas data from sms table
 *************************************************************/
int EEP_read_table(unsigned char* cid, unsigned char* ddata)
{ 
	unsigned int  len;
	unsigned char dtemp[5],ii,max;
	
	if (ddata == 0)
	{
		return 1;
	}

	if (EEP_read(EEADDR_ALR_TNUM, EEL_TABLE_NUM, dtemp, 1))
		return 2;

	if (dtemp[0] == 0)
		return 3;
	
	max = dtemp[0];
	for (ii=0; ii<max; ii++)
	{ // cid kereses
		if (EEP_read(EEADDR_ALR_TCID+ii*EEL_TABLE_OFFSET, EEL_TABLE_CID, dtemp, 1))
			continue;
		if ((cid[0] == dtemp[0]) && (cid[1] == dtemp[1])  && (cid[2] == dtemp[2])  && (cid[3] == dtemp[3]))
		//megvan a cid
			break;
	}
	if (ii == max)
		return 4;
	
	if (EEP_read(EEADDR_ALR_TMSG+ii*EEL_TABLE_OFFSET, EEL_TABLE_MSG, ddata, 0))
		return 5;
	return 0;
}