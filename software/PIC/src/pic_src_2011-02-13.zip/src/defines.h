

#include  <ctype.h>	
#include  <stdio.h>

#define VER = 5	//szoftver verzi�
//#define SIM300_PC1 1 //SIM PC1  atkotve J1-re, SIM300 RS232 vezerelheto
#define SIM900	1
#define GPRS_SEND_TEST	1
//#define GPRS_HAZMESTER	1
#define GPRS_FROM_EEPROM	1
//#define NO_GPRS_FOR_VOICE_TEST	1

// Timer0
// osc : 16.384 Mhz
#define TIMER_1MS	191 // 1ms
//#define TIMER_1MS	223 // 5ms
//#define TIMER_5MS	95 // 5ms

// USART 
//-- Baudrate setting for Fcy=16.384 MHz, BRGH=1, BRG16=1

#define BPS_9600	425
#define BPS_19200	213
#define BPS_38400	106
#define BPS_57600	70	
#define BPS_115200	35

//-- Baudrate setting for Fcy=20 MHz, BRGH=1, BRG16=1
/*
#define BPS_300		16666
#define BPS_600		8332
#define BPS_1200	4166
#define BPS_2400	2082
#define BPS_4800	1041
//#define BPS_9600	520
#define BPS_9600	415
#define BPS_19200	259
#define BPS_38400	129
#define BPS_57600	86
#define BPS_115200	42
#define BPS_230400	21
#define BPS_250000	19
#define BPS_460800	10
#define BPS_500000	9
#define BPS_614400	7*/

//--------------------
// USART TX-RX-2, PC
//--------------------
#define RX2_MAX_DATA_NUM		48
#define TX2_MAX_DATA_LEN		48

// status bits
#define TX_INT		(char)0x1
#define RX_INT		(char)0x2
#define RX_READY	(char)0x4
#define RX_ERROR	(char)0x8


//#define TX1_ON 

#define TX2_ON 	PIE3bits.TX2IE = 1; \
				PIR3bits.TX2IF = 0;

#define TX2_OFF PIE3bits.TX2IE = 0; \
				PIR3bits.TX2IF = 0;

#define RX2_ON 	RCSTA2bits.CREN = 1; \
				PIE3bits.RC2IE = 1; \
				PIR3bits.RC2IF = 0;

#define RX2_OFF RCSTA2bits.CREN = 0; \
				PIE3bits.RC2IE = 0; \
				PIR3bits.RC2IF = 0; \
				CLR_SER2_STATUS(RX_INT)


#define CLR_SER2_STATUS(x)		RxTx2State &= (~x);
#define SET_SER2_STATUS(x)		RxTx2State |= (x);
#define CHK_SER2_STATUS(x)		(RxTx2State & (x))

#define	RX_TIMEOUT			5		// 50 ms
#define RX_ERROR_TIMEOUT	50		// 50 ms


#define	SER2_CMD_DEFAULT 'D' // alap, default.
#define SER2_CMD_ERROR 	'E' //error

//--------------------
// USART TX-RX-1, GSM-GPRS
//--------------------
#define RX1_MAX_DATA_NUM		64
#define TX1_MAX_DATA_LEN		48

#define TX1_ON 	PIE1bits.TX1IE = 1; \
				PIR1bits.TX1IF = 0;

#define TX1_OFF PIE1bits.TX1IE = 0; \
				PIR1bits.TX1IF = 0;

#define RX1_ON 	RCSTA1bits.CREN = 1; \
				PIE1bits.RC1IE = 1; \
				PIR1bits.RC1IF = 0;

#define RX1_OFF RCSTA1bits.CREN = 0; \
				PIE1bits.RC1IE = 0; \
				PIR1bits.RC1IF = 0; \
				CLR_SER1_STATUS(RX_INT)

#define CLR_SER1_STATUS(x)		RxTx1State &= (~x);
#define SET_SER1_STATUS(x)		RxTx1State |= (x);
#define CHK_SER1_STATUS(x)		(RxTx1State & (x))

// Error 
typedef enum
{
	NOERR_SUCCESS = 0,
	ERR_BEGCH,
	ERR_ENDCH,
	ERR_LEN,
	ERR_CHS,
	ERR_USART, //5
	ERR_LEN_NULL,
	EE_INEE_WR,
	EE_INEE_RD,	// 10
	EE_VER,
	EE_CHS,

	NOERR_NOSETTING = 100
} ERROR_CODE;	


// main externs

//--------------------
// Timerek
//--------------------
// 0.86; 1 sec = 1000*0.86 = 860
#define TESTtdindex  0
#define RX1tdindex  1
#define RX2tdindex  2
#define DEBUGtdindex  3
#define SLICtdindex  4
#define GSM1tdindex  5
#define SLIC_EXEtdindex 6
#define GSMALIVEtdindex 7
#define MEROtdindex  8
#define GSM_NETWORKtdindex 9
#define LED1tdindex  10
#define WAIT1tdindex  11
#define TIMERDEC_NUMtdindex 13
//--------------------
// SLIC:Si3210
//--------------------
#define T_INT	(PORTFbits.RF2)	
#define	T_RESET	(PORTFbits.RF1)		// Aktiv: Low (all register reset)
#define	CS3210	(PORTFbits.RF3)		// Chip select SPI 3210 vonalszimulatornak
#define	TAMPER  (PORTGbits.RG3)		// Tamper

#define SLIC_EXE  2000

#define	INIT_IR0		0x55C2	/* DTMF_ROW_0_PEAK	*/
#define	INIT_IR1		0x51E6  /*	DTMF_ROW_1_PEAK,*/	
#define	INIT_IR2		0x4B85	/*	DTMF_ROW2_PEAK,	*/	
#define	INIT_IR3		0x4937	/*	DTMF_ROW3_PEAK,	*/
#define	INIT_IR4		0x3333	/*	DTMF_COL1_PEAK,	*/
#define	INIT_IR5		0x0202	/*	DTMF_FWD_TWIST,*/
#define	INIT_IR6		0x0202	/*	DTMF_RVS_TWIST,	*/
#define	INIT_IR7		0x0198	/*	DTMF_ROW_RATIO,	*/
#define	INIT_IR8		0x0198	/*	DTMF_COL_RATIO,	*/	
#define	INIT_IR9		0x0611	/*	DTMF_ROW_2ND_ARM,*/
#define	INIT_IR10		0x0202	/*	DTMF_COL_2ND_ARM,*/	
#define	INIT_IR11		0x00E5	/*	DTMF_PWR_MIN_,	*/
#define	INIT_IR12		0x0A1C	/*	DTMF_OT_LIM_TRES,*/		
#define	INIT_IR13		0x7b30	/*	OSC1_COEF,	*/
#define	INIT_IR14		0x0063	/*	OSC1X,	*/
#define	INIT_IR15		0x0000	/*	OSC1Y,	*/
#define	INIT_IR16		0x7870	/*	OSC2_COEF,*/	
#define	INIT_IR17		0x007d	/*	OSC2X,	*/
#define	INIT_IR18		0x0000	/*	OSC2Y,	*/
#define	INIT_IR19		0x0000	/*	RING_V_OFF*/
#define	INIT_IR20		0x7EF0	/*	RING_OSC,	*/	
#define	INIT_IR21		0x0160	/*	RING_X,	*/
#define	INIT_IR22		0x0000	/*	RING_Y,	*/
#define	INIT_IR23		0x2000	/*	PULSE_ENVEL,*/	
#define	INIT_IR24		0x2000	/*	PULSE_X,*/
#define	INIT_IR25		0x0000	/*	PULSE_Y,*/	
//#define	INIT_IR26		0x4000	//	RECV_DIGITAL_GAIN
//#define	INIT_IR27		0x4000	//	XMIT_DIGITAL_GAIN
//*************** EEPROM-b�l fel�lbir�lva *****************
#define	INIT_IR26		10000	//	RECV_DIGITAL_GAIN,
#define	INIT_IR27		10000	//	XMIT_DIGITAL_GAIN
//*********************************************************

#define	INIT_IR28		0x1000	/*	LOOP_CLOSE_TRES,	*/
#define	INIT_IR29		0x3600	/*	RING_TRIP_TRES,	*/
#define	INIT_IR30		0x1000	/*	COMMON_MIN_TRES,*/	
#define	INIT_IR31		0x080	/*	COMMON_MAX_TRES,*/
#define	INIT_IR30_HV		0x900	/*	COMMON_MIN_TRES,*/	
#define	INIT_IR31_HV		0x080	/*	COMMON_MAX_TRES,*/	
#define	INIT_IR32		0x7c0  	/*	PWR_ALARM_Q1Q2, */		
#define	INIT_IR33		0x376F	/*	PWR_ALARM_Q3Q4, */
#define	INIT_IR34		0x1B80	/*	PWR_ALARM_Q5Q6,	 */
#define	INIT_IR35		0x8000	/*	LOOP_CLSRE_FlTER,*/
#define	INIT_IR36		0x0320	/*	RING_TRIP_FILTER,*/	
#define	INIT_IR37		0x008c	/*	TERM_LP_POLE_Q1Q2, */	
#define	INIT_IR38		0x008C	/*	TERM_LP_POLE_Q3Q4,	 */
#define	INIT_IR39		0x0010	/*	TERM_LP_POLE_Q5Q6, */	
#define	INIT_IR40		0x0200  	/*	CM_BIAS_RINGING,*/	
#define	INIT_IR41		0x0C00	/*	DCDC_MIN_V,	*/
#define	INIT_IR40_HV		0x200  	/*	CM_BIAS_RINGING,*/	
#define	INIT_IR41_HV		0x600	/*	DCDC_MIN_V,	*/
#define	INIT_IR42		0x0	    
#define	INIT_IR43		0xE00	/*	"LOOP_CLOSE_TRES Low*/

#define	INIT_IR98		0x0000	// NINCS SEHOL, DE VALAMI KELL!!!
#define	INIT_IR99		0x00DA	/* FSK 0 FREQ PARAM */
#define	INIT_IR100		0x6B60	/* FSK 0 AMPL PARAM */
#define	INIT_IR101		0x0074	/* FSK 1 FREQ PARAM */
#define	INIT_IR102		0x79C0	/* FSK 1 AMPl PARAM */
#define	INIT_IR103		0x1120	/* FSK 0to1 SCALER */
#define	INIT_IR104		0x3BE0	/* FSK 1to0 SCALER */

#define	INIT_IR35_OP	0x8000	// OPerate (legv�g�n irand�)
#define	INIT_IR36_OP	0x8000	// OPerate (legv�g�n irand�)
#define	INIT_IR37_OP	0x8000	// OPerate (legv�g�n irand�)
#define	INIT_IR38_OP	0x8000	// OPerate (legv�g�n irand�)
#define	INIT_IR39_OP	0x8000	// OPerate (legv�g�n irand�)


//#define INIT_SI3210M_DR92 0x60  /*  92 0x60 Initialization DC-DC Converter PWM Period (61.035 ns/LSB) */
//#define INIT_SI3210M_DR93 0x38  /*  92 0x60 Initialization DC-DC Converter PWM Period (61.035 ns/LSB) */
#define INIT_SI3210M_DR92 0x67  
#define INIT_SI3210M_DR93 0x16 
#define	INIT_DR92	0x7f	/*	92 0x5C  7F Initialization DC-DC Converter PWM Period (61.035 ns/LSB) */
#define	INIT_DR93	0x14	/*	93 0x5D 0x14 0x19 Initialization DC-DC Converter Min. Off Time (61.035 ns/LSB) */

#define	INIT_DR71	0X01	/*	71 0x47 0x00 0x01 Initialization Off-Hook Loop Current Limit (20 mA + 3 mA/LSB) */
#define	INIT_DR65	0X60	/*	65 0x41 0x61 Initialization External Bipolar Transistor Settings  */

#define	SPI_MODE	0
#define	PCM_MODE	1
#define	PCM_XMIT_START_COUNT_LSB	2
#define	PCM_XMIT_START_COUNT_MSB	3
#define	PCM_RCV_START_COUNT_LSB	4
#define	PCM_RCV_START_COUNT_MSB	5
#define	DIO	6

#define	AUDIO_LOOPBACK	8
#define	AUDIO_GAIN	9
#define	LINE_IMPEDANCE	10
#define	HYBRID	11
#define	RESERVED12	12
#define	RESERVED13	13
#define	PWR_DOWN1	14
#define	PWR_DOWN2	15
#define	RESERVED16	16
#define	RESERVED17	17
#define	INTRPT_STATUS1	18
#define	INTRPT_STATUS2	19
#define	INTRPT_STATUS3	20
#define	INTRPT_MASK1	21
#define	INTRPT_MASK2	22
#define	INTRPT_MASK3	23
#define	DTMF_DIGIT	24
#define	RESERVED25	25
#define	RESERVED26	26
#define	RESERVED27	27
#define	I_DATA_LOW	28
#define	I_DATA_HIGH	29
#define	I_ADDRESS	30
#define	I_STATUS	31
#define	OSC1	32
#define	OSC2	33
#define	RING_OSC_CTL	34
#define	PULSE_OSC	35
#define	OSC1_ON__LO	36
#define	OSC1_ON_HI	37
#define	OSC1_OFF_LO	38
#define	OSC1_OFF_HI	39
#define	OSC2_ON__LO	40
#define	OSC2_ON_HI	41
#define	OSC2_OFF_LO	42
#define	OSC2_OFF_HI	43
#define	PULSE_ON__LO	44
#define	PULSE_ON_HI	45
#define	PULSE_OFF_LO	46
#define	PULSE_OFF_HI	47
#define	RING_ON__LO	48
#define	RING_ON_HI	49
#define	RING_OFF_LO	50
#define	RING_OFF_HI	51
#define	FSK_DATA	52	/*		0								fsk_data	*/
#define	RESERVED53	53
#define	RESERVED54	54
#define	RESERVED55	55
#define	RESERVED56	56
#define	RESERVED57	57
#define	RESERVED58	58
#define	RESERVED59	59
#define	RESERVED60	60
#define	RESERVED61	61
#define	RESERVED62	62
#define	RESERVED63	63
#define	LINE_STATE	64
#define			ACTIVATE_LINE 0x11
#define			RING_LINE     0x44
#define	BIAS_SQUELCH	65
#define	BAT_FEED	66
#define	AUTO_STATE	67
#define	LOOP_STAT	68
#define	LOOP_DEBOUCE	69
#define	RT_DEBOUCE	70
#define	LOOP_I_LIMIT	71
#define	ON_HOOK_V	72
#define	COMMON_V	73
#define	BAT_V_HI	74
#define	BAT_V_LO	75
#define	PWR_STAT_DEV	76
#define	PWR_STAT	77
#define	LOOP_V_SENSE	78
#define	LOOP_I_SENSE	79
#define	TIP_V_SENSE	80
#define	RING_V_SENSE	81
#define	BAT_V_HI_SENSE	82
#define	BAT_V_LO_SENSE	83
#define	IQ1	84
#define	IQ2	85
#define	IQ3	86
#define	IQ4	87
#define	IQ5	88
#define	IQ6	89
#define	RESERVED90	90
#define	RESERVED91	91
#define	DCDC_PWM_OFF	92
#define	DCDC	93
#define	DCDC_PW_OFF	94
#define	RESERVED95	95
#define	CALIBR1	96
#define CALIBRATE_LINE 0x78
#define NORMAL_CALIBRATION_COMPLETE 0x20
#define	CALIBR2	97
#define	RING_GAIN_CAL	98
#define	TIP_GAIN_CAL	99
#define	DIFF_I_CAL	100
#define	COMMON_I_CAL	101
#define	I_LIMIT_GAIN_CAL	102
#define	ADC_OFFSET_CAL	103
#define	DAC_ADC_OFFSET	104
#define	DAC_OFFSET_CAL	105
#define	COMMON_BAL_CAL	106
#define	DC_PEAK_CAL	107

/* Indirect Register (decimal) */
#define	DTMF_ROW_0_PEAK	0
#define	DTMF_ROW_1_PEAK	1
#define	DTMF_ROW2_PEAK	2
#define	DTMF_ROW3_PEAK	3
#define	DTMF_COL1_PEAK	4
#define	DTMF_FWD_TWIST	5
#define	DTMF_RVS_TWIST	6
#define	DTMF_ROW_RATIO_THRESH	7
#define	DTMF_COL_RATIO_THRESH	8
#define	DTMF_ROW_2ND_HARM	9
#define	DTMF_COL_2ND_HARM	10
#define	DTMF_PWR_MIN_THRESH	11
#define	DTMF_HOT_LIM_THRESH	12
#define	OSC1_COEF	13
#define	OSC1X	14
#define	OSC1Y	15
#define	OSC2_COEF	16
#define	OSC2X	17
#define	OSC2Y	18
#define	RING_V_OFF	19
#define	RING_OSC_COEF	20
#define	RING_X	21
#define	RING_Y	22
#define	PULSE_ENVEL	23
#define	PULSE_X	24
#define	PULSE_Y	25
#define	RECV_DIGITAL_GAIN	26
#define	XMIT_DIGITAL_GAIN	27
#define	LOOP_CLOSE_THRESH	28
#define	RING_TRIP_THRESH	29
#define	COMMON_MIN_THRESH	30
#define	COMMON_MAX_THRESH	31
#define	PWR_ALARM_Q1Q2	32
#define	PWR_ALARM_Q3Q4	33
#define	PWR_ALARM_Q5Q6	34
#define	LOOP_CLOSURE_FILTER	35
#define	RING_TRIP_FILTER	36
#define	THERM_LP_POLE_Q1Q2	37
#define	THERM_LP_POLE_Q3Q4	38
#define	THERM_LP_POLE_Q5Q6	39
#define	CM_BIAS_RINGING	40
#define	DCDC_MIN_V	41
#define	DCDC_XTRA	42
#define ALL_CHIPS 0x09
#define NO_CHIPS 0
#define	REVC	108	   
#define	FSK_X_0		99	
#define	FSK_COEFF_0	100	
#define	FSK_X_1		101	
#define	FSK_COEFF_1	102	
#define	FSK_X_01	103	
#define	FSK_X_10	104		


//--------------------
//CODEC IC PCM
//--------------------
#define PCM_IN		(PORTCbits.RC0)		// PCM BEMNETI JELE... (PROSILC-T�L.)
#define CODEC_m	    (PORTAbits.RA5)		// Codec mode l�b
//#define	CODEC_m	PORTA,5		; Codec mode l�b
#define	CODEC_p		(PORTCbits.RC1)		// Codec power controll PWRCTL

//--------------------
// GSM
//--------------------
#define	GSM_PWR	(PORTBbits.RB2)	//GSM TAP lab
#define	GSM_RES	(PORTFbits.RF5)	//GSM Reset lab
#define	GSM_PWRKEY	(PORTCbits.RC2)	//GSM PWRKEY lab
#define	GSM_STATUS	(PORTBbits.RB3)	//GSM STATUS lab

//--------------------
// GPRS
//--------------------
#define	GPRS_SERVER_IP		"195.56.111.193"
#define	GPRS_DNS_PRI_IP 	"217.79.128.40"
#define	GPRS_DNS_SEC_IP 	"217.79.128.45"
#define	GPRS_DNS_IP_LEN 	17
#define	GPRS_SERVER_PORT	"53500"
#define GPRS_DEVICE_PORT	"2800"

#define GPRS_ALIVE  51700 // 1 perc 
#define GPRS_ALARM  3200
#define GSM_NETWORK_DEFAULT 15000 // 15 sec
#define GSM_NETWORK_ERROR 3000 // 3 sec

#define TIME_3_MIN  155100 // 3 perc 
#define TIME_5_MIN  285500 // 5 perc 

//telefon call idok
#define GSM_VOICE1	100	// 100 ms
#define GSM_VOICE2	1000 // 100 ms

//--------------------
// LED
//--------------------
/*#define	LEDZ	(PORTBbits.RB1)	//Z�ld LED <panelmar�s fel�li>    //ACTIVITY
#define	LEDP	(PORTBbits.RB0) //Piros LED <GSM antenna meletti> //network
#define	LED_PH	(PORTBbits.RB4) //LED Phone (z�d) //PHONE
#define	Flash	(PORTEbits.RE4) //LED	//SMD LED s�rga <panel sz�le fel� es�>
#define	FlashP	(PORTEbits.RE5) //LED	//SMD LED piros <aku csati meletti> */

#define		LED1_ON	 	{LATBbits.LATB0 = 1;}  // ACTIVITY
#define		LED1_OFF	{LATBbits.LATB0 = 0;}
#define		LED2_ON	 	{LATBbits.LATB1 = 1;}  
#define		LED2_OFF	{LATBbits.LATB1 = 0;}
#define		LED3_ON	 	{LATBbits.LATB4 = 1;}  //
#define		LED3_OFF	{LATBbits.LATB4 = 0;}


//--------------------
//Taamper gomb
//--------------------
#define	SZABP	(PORTGbits.RB3)		//tamper nyomogomb


/*  V�ltoz�t�pusok �s uni�k defini�l�sa ******************************/
typedef unsigned char       uint8;   // 8 bites, el�jel n�lk�li sz�m
typedef unsigned int        uint16;  //16 bites, el�jel n�lk�li sz�m
typedef unsigned long       uint32;  //32 bites, el�jel n�lk�li sz�m
typedef signed char         int8;    // 8 bites, el�jeles sz�m
typedef signed int          int16;   //16 bites, el�jeles sz�m
typedef signed long         int32;   //32 bites, el�jeles sz�m

typedef unsigned char		BYTE;
typedef signed short 		WORD;

///Uni� t�pus sz� �s b�jt el�r�ssel 16 bites adatokhoz
typedef union _union16 { 
  uint16 word;
  struct {
    uint8 lo_byte;
    uint8 hi_byte;
  };
} union16;

///Uni� t�pus duplasz�, sz� �s b�jt el�r�ssel 32 bites adatokhoz
typedef union _union32 {
  uint32 dword;
  struct {
    uint16 lo_word;
    uint16 hi_word;
  };
  uint8 byte[4];
} union32;

//--------------------
//makrok
//--------------------

#define DBG_r(m) {Tx2_Debug_r(m);}
#define DBG() {Tx2_Debug(dmsg);}
#define DBG_m(m) {Tx2_Debug(m);}
#define DBG_1form(m,d) {mysprintf(dmsg,m,d);Tx2_Debug(dmsg);}


#define CLRWDT { _asm clrwdt _endasm }
#define RESET  { _asm reset _endasm }


extern volatile unsigned long timersDec[TIMERDEC_NUMtdindex];
extern char dmsg[64];
