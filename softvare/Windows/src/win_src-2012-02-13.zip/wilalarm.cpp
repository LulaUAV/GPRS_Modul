//---------------------------------------------------------------------------

#include <vcl.h>
#pragma hdrstop
//---------------------------------------------------------------------------
USEFORM("walarm.cpp", WalarmForm);
USEFORM("WilGsmGprsTeszt.cpp", FormSIM300);
USEFORM("WilSLICTeszt.cpp", FormSLIC);
USEFORM("WilAlarmMain.cpp", WilAlarmM);
USEFORM("WilAlarmSetting.cpp", WASetting);
//---------------------------------------------------------------------------
WINAPI WinMain(HINSTANCE, HINSTANCE, LPSTR, int)
{
    try
    {
         Application->Initialize();
         Application->CreateForm(__classid(TWilAlarmM), &WilAlarmM);
         Application->CreateForm(__classid(TWalarmForm), &WalarmForm);
         Application->CreateForm(__classid(TFormSIM300), &FormSIM300);
         Application->CreateForm(__classid(TFormSLIC), &FormSLIC);
         Application->CreateForm(__classid(TWASetting), &WASetting);
         Application->Run();
    }
    catch (Exception &exception)
    {
         Application->ShowException(&exception);
    }
    catch (...)
    {
         try
         {
             throw Exception("");
         }
         catch (Exception &exception)
         {
             Application->ShowException(&exception);
         }
    }
    return 0;
}
//---------------------------------------------------------------------------
