//---------------------------------------------------------------------------

#include <vcl.h>
#include <stdio.h>
#pragma hdrstop

#include "WilSLICTeszt.h"
#include "SerialCom.h"
//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma resource "*.dfm"
TFormSLIC *FormSLIC;

extern DWORD Send(char* msg, int len, VIEW callback);
extern void Error_Message(char* msg);
//---------------------------------------------------------------------------
__fastcall TFormSLIC::TFormSLIC(TComponent* Owner)
    : TForm(Owner)
{
}
//---------------------------------------------------------------------------
void __fastcall TFormSLIC::ExitBtnClick(TObject *Sender)
{
    Close();    
}


//---------------------------------------------------------------------------
void _fastcall TFormSLIC::WriteProSLICDirectRegister (char reg, char val)
{
   char msg[32];

    msg[0] = 'S';
    msg[1] =  0;
    msg[2] =  reg;
    msg[3] =  val;
    if (Send(msg, 4, NULL) == 0)
        printf("serial sending error\n");
}

//---------------------------------------------------------------------------
char __fastcall  TFormSLIC::ReadProSLICDirectRegister (char reg)
{
    char msg[32];

    msg[0] = 'S';
    msg[1] =  1;
    msg[2] =  reg;
    if (Send(msg, 3, NULL) == 0)
        printf("serial sending error\n");
}

//---------------------------------------------------------------------------
short  __fastcall  TFormSLIC::ReadProSLICIndirectRegister (char reg)
{
    char msg[32];

    msg[0] = 'S';
    msg[1] =  3;
    msg[2] =  reg;
    if (Send(msg, 3, NULL) == 0)
        printf("serial sending error\n");
}

//---------------------------------------------------------------------------
void __fastcall TFormSLIC::WriteProSLICIndirectRegister (char reg, short val)
{
    char msg[32];

    msg[0] = 'S';
    msg[1] =  2;
    msg[2] =  reg;
    msg[3] =  (char)(val % 256);
    msg[4] =  (char)(val / 256);
    if (Send(msg, 5, NULL) == 0)
        printf("serial sending error\n");
}


//---------------------------------------------------------------------------
//  Sender part
//---------------------------------------------------------------------------
void __fastcall TFormSLIC::DRWrSendBtnClick(TObject *Sender)
{
    int address,data;
    try
    {
        address = DRWrAddrEdit->Text.ToInt();
    }
    catch(...)
    {
        Error_Message("Direct Write address nem sz�m");
        return;
    }

    try
    {
        data = DRWrDataEdit->Text.ToInt();
    }
    catch(...)
    {
        Error_Message("Direct Write data nem sz�m");
        return;
    }
    WriteProSLICDirectRegister ((char)address, (char)data);
    Info->Lines->Add("Direct Regiszter Write Send: " + DRWrAddrEdit->Text + "," + DRWrDataEdit->Text);
    
}

//---------------------------------------------------------------------------
void __fastcall TFormSLIC::DRRdSendBtnClick(TObject *Sender)
{
    int address;
    try
    {
        address = DRRdAddrEdit->Text.ToInt();
    }
    catch(...)
    {
        Error_Message("Direct Read address nem sz�m");
        return;
    }
    ReadProSLICDirectRegister ((char)address);
    Info->Lines->Add("Direct Regiszter Read Send: " + DRRdAddrEdit->Text);
}

//---------------------------------------------------------------------------
void __fastcall TFormSLIC::IDRWrSendBtnClick(TObject *Sender)
{
    int address,data;
    try
    {
        address = IDRWrAddrEdit->Text.ToInt();
    }
    catch(...)
    {
        Error_Message("Indirect Write address nem sz�m");
        return;
    }

    try
    {
        data = IDRWrDataEdit->Text.ToInt();
    }
    catch(...)
    {
        Error_Message("Indirect Write data nem sz�m");
        return;
    }
    WriteProSLICIndirectRegister ((char)address, data);
    Info->Lines->Add("Indirect Regiszter Write Send: " + IDRWrAddrEdit->Text + "," + IDRWrDataEdit->Text);
}

//---------------------------------------------------------------------------
void __fastcall TFormSLIC::IDRRdSendBtnClick(TObject *Sender)
{
    int address;
    try
    {
        address = IDRRdAddrEdit->Text.ToInt();
    }
    catch(...)
    {
        Error_Message("Indirect Read address nem sz�m");
        return;
    }
    ReadProSLICIndirectRegister ((char)address);
    Info->Lines->Add("Indirect Regiszter Read Send: " + IDRRdAddrEdit->Text);
}
//---------------------------------------------------------------------------

