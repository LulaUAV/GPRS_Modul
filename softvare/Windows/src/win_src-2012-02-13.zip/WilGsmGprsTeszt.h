//---------------------------------------------------------------------------

#ifndef WilGsmGprsTesztH
#define WilGsmGprsTesztH
//---------------------------------------------------------------------------
#include <Classes.hpp>
#include <Controls.hpp>
#include <StdCtrls.hpp>
#include <Forms.hpp>

#include "LoadSimFile.h"
//---------------------------------------------------------------------------
class TFormSIM300 : public TForm
{
__published:	// IDE-managed Components
    TGroupBox *GroupBox1;
    TButton *First1Btn;
    TButton *Next1Btn;
    TButton *Curr1Btn;
    TGroupBox *GroupBox2;
    TButton *First2Btn;
    TButton *Next2Btn;
    TButton *Curr2Btn;
    TButton *SendBtn;
    TEdit *CmdEdit;
    TButton *GPSRSendData;
    TCheckBox *EnterCbx;
    TCheckBox *CTRLZCbx;
    TButton *LoadBtn;
    TMemo *Info;
    TButton *ExitBtn;
    void __fastcall ExitBtnClick(TObject *Sender);
    void __fastcall LoadBtnClick(TObject *Sender);
    void __fastcall SendBtnClick(TObject *Sender);
    void __fastcall EnterCbxClick(TObject *Sender);
    void __fastcall First1BtnClick(TObject *Sender);
    void __fastcall Next1BtnClick(TObject *Sender);
    void __fastcall Curr1BtnClick(TObject *Sender);
    void __fastcall First2BtnClick(TObject *Sender);
    void __fastcall Next2BtnClick(TObject *Sender);
    void __fastcall Curr2BtnClick(TObject *Sender);
    void __fastcall GPSRSendDataClick(TObject *Sender);
    void __fastcall FormCreate(TObject *Sender);
private:	// User declarations
    LoadSIM* m_loadsim;
    int m_sim1_index, m_sim2_index;
private:	// User declarations
    void __fastcall sendItem_atlist1();
    void __fastcall sendItem_atlist2();
public:		// User declarations
    __fastcall TFormSIM300(TComponent* Owner);
};
//---------------------------------------------------------------------------
extern PACKAGE TFormSIM300 *FormSIM300;
//---------------------------------------------------------------------------
#endif
